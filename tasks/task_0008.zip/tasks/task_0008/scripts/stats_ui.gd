extends HBoxContainer

func update_stats(_stats: Stats) -> void:
	pass
