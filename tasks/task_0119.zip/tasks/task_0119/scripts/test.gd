extends Node

func _ready():
	run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func run_validation():
	var main_node = get_node_or_null("Main")
	if not main_node:
		fail("Main scene is missing")
		return

	var trap = main_node.get_node_or_null("Trap")
	if not trap or not trap is Node2D:
		fail("Trap node must exist as a Node2D child of Main")
		return

	var spawn_holder = trap.get_node_or_null("SpawningPoints")
	if not spawn_holder or not spawn_holder is Node2D:
		fail("Add a Node2D named SpawningPoints under Trap")
		return

	var spawn_left = spawn_holder.get_node_or_null("SpawnLeft")
	if not spawn_left or not spawn_left is Marker2D:
		fail("SpawningPoints needs a Marker2D child named SpawnLeft")
		return

	var spawn_right = spawn_holder.get_node_or_null("SpawnRight")
	if not spawn_right or not spawn_right is Marker2D:
		fail("SpawningPoints needs a Marker2D child named SpawnRight")
		return

	if spawn_left.position.distance_to(Vector2(-15, 0)) > 8.5:
		fail("SpawnLeft must sit 15px above Trap (Vector2(-15, 0))")
		return

	if spawn_right.position.distance_to(Vector2(15, 0)) > 8.5:
		fail("SpawnRight must sit 15px below Trap (Vector2(15, 0))")
		return

	if spawn_right.z_index != 1:
		fail("SpawnRight should render above Trap by setting z_index to 1")
		return

	print("VALIDATION_PASSED: Spawning markers configured for the trap")
	get_tree().quit(0)
