extends MarginContainer

# TODO: implement minimap marker logic, zoom control, and removal handling
