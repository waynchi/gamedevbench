extends Node

func _ready() -> void:
	await run_validation()

func run_validation() -> void:
	var main_node := get_node_or_null("Main")
	if main_node == null:
		print("VALIDATION_FAILED: Main node not found")
		get_tree().quit(1)
		return

	var player := main_node.get_node_or_null("Player")
	if player == null:
		print("VALIDATION_FAILED: Player node not found")
		get_tree().quit(1)
		return

	var animation_player_upper: AnimationPlayer = player.get_node_or_null("AnimationPlayerUpper")
	var animation_player_lower: AnimationPlayer = player.get_node_or_null("AnimationPlayerLower")
	if animation_player_upper == null or animation_player_lower == null:
		print("VALIDATION_FAILED: Missing AnimationPlayerUpper or AnimationPlayerLower")
		get_tree().quit(1)
		return

	if not animation_player_upper.has_animation("attack"):
		print("VALIDATION_FAILED: AnimationPlayerUpper missing attack animation")
		get_tree().quit(1)
		return

	if not animation_player_lower.has_animation("run"):
		print("VALIDATION_FAILED: AnimationPlayerLower missing run animation")
		get_tree().quit(1)
		return

	animation_player_upper.play("stand")
	animation_player_lower.play("run")
	if animation_player_upper.current_animation != "run":
		print("VALIDATION_FAILED: Upper animation did not sync to lower animation changes")
		get_tree().quit(1)
		return

	animation_player_upper.play("attack")
	animation_player_lower.play("stand")
	if animation_player_upper.current_animation != "attack":
		print("VALIDATION_FAILED: Upper attack animation should not be overridden")
		get_tree().quit(1)
		return

	animation_player_lower.play("run")
	# Wait for the attack animation to actually finish
	await animation_player_upper.animation_finished

	# After attack finishes, upper should sync to lower's current animation
	if animation_player_upper.current_animation != "run":
		print("VALIDATION_FAILED: Upper animation did not resync after attack finished")
		get_tree().quit(1)
		return

	# Allow small tolerance since animations run in real-time
	var position_delta: float = abs(animation_player_upper.current_animation_position - animation_player_lower.current_animation_position)
	if position_delta > 0.05:
		print("VALIDATION_FAILED: Upper animation position did not sync to lower animation position (delta: " + str(position_delta) + ")")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)
