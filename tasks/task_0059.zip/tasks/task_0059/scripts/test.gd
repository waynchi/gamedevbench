extends Node

func _ready():
	# Allow Control sizes to propagate before validation.
	await get_tree().process_frame
	run_validation()

func load_image(path: String) -> Image:
	var data = FileAccess.get_file_as_bytes(path)
	var img := Image.new()
	if img.load_png_from_buffer(data) != OK:
		return null
	return img

func textures_match(tex: Texture2D, reference_path: String) -> bool:
	if tex == null:
		return false
	var tex_image := tex.get_image()
	var reference_image := load_image(reference_path)
	if reference_image == null:
		return false
	return tex_image.get_size() == reference_image.get_size() and tex_image.get_data() == reference_image.get_data()

func assert_or_fail(condition: bool, message: String) -> void:
	if not condition:
		print("VALIDATION_FAILED: %s" % message)
		get_tree().quit(1)

func run_validation():
	var main = get_node_or_null("Main")
	assert_or_fail(main != null, "Main node not found")

	var canvas_layer = main.get_node_or_null("CanvasLayer")
	assert_or_fail(canvas_layer != null, "CanvasLayer missing under Main")

	var minimap = canvas_layer.get_node_or_null("Minimap")
	assert_or_fail(minimap != null and minimap is MarginContainer, "Minimap must be a MarginContainer under CanvasLayer")

	var size_ok = abs(minimap.size.x - 200.0) < 0.5 and abs(minimap.size.y - 200.0) < 0.5
	assert_or_fail(size_ok, "Minimap size should be 200x200")

	var margins = [
		minimap.get_theme_constant("margin_left", "MarginContainer"),
		minimap.get_theme_constant("margin_top", "MarginContainer"),
		minimap.get_theme_constant("margin_right", "MarginContainer"),
		minimap.get_theme_constant("margin_bottom", "MarginContainer"),
	]
	assert_or_fail(margins == [5, 5, 5, 5], "Minimap margins must all be 5")

	var frame = minimap.get_node_or_null("Frame")
	assert_or_fail(frame != null and frame is NinePatchRect, "Frame NinePatchRect not found")
	assert_or_fail(textures_match(frame.texture, "res://assets/panel_woodDetail_blank.png"), "Frame texture must match panel_woodDetail_blank.png")
	var patches_ok = frame.patch_margin_left == 64 and frame.patch_margin_top == 64 and frame.patch_margin_right == 64 and frame.patch_margin_bottom == 64
	assert_or_fail(patches_ok, "Frame patch margins must be 64 on all sides")

	var content = minimap.get_node_or_null("Content")
	assert_or_fail(content != null and content is MarginContainer, "Content MarginContainer missing")
	var inner_margins = [
		content.get_theme_constant("margin_left", "MarginContainer"),
		content.get_theme_constant("margin_top", "MarginContainer"),
		content.get_theme_constant("margin_right", "MarginContainer"),
		content.get_theme_constant("margin_bottom", "MarginContainer"),
	]
	assert_or_fail(inner_margins == [20, 20, 20, 20], "Content margins must all be 20")

	var grid = content.get_node_or_null("Grid")
	assert_or_fail(grid != null and grid is TextureRect, "Grid TextureRect missing")
	assert_or_fail(textures_match(grid.texture, "res://assets/pattern_blueprintPaper.png"), "Grid texture must match pattern_blueprintPaper.png")
	assert_or_fail(grid.stretch_mode == TextureRect.STRETCH_TILE, "Grid stretch_mode must be Tile")

	var player_marker = grid.get_node_or_null("PlayerMarker")
	assert_or_fail(player_marker != null and player_marker is Sprite2D, "PlayerMarker Sprite2D missing")
	assert_or_fail(textures_match(player_marker.texture, "res://assets/minimapIcon_arrowA.png"), "PlayerMarker texture must use minimapIcon_arrowA.png")
	var expected_center = grid.size / 2.0
	var center_delta = player_marker.position - expected_center
	assert_or_fail(center_delta.length() <= 1.0, "PlayerMarker must be centered on Grid")

	var mob_marker = grid.get_node_or_null("MobMarker")
	assert_or_fail(mob_marker != null and mob_marker is Sprite2D, "MobMarker Sprite2D missing")
	assert_or_fail(textures_match(mob_marker.texture, "res://assets/minimapIcon_jewelRed.png"), "MobMarker texture must use minimapIcon_jewelRed.png")
	assert_or_fail(not mob_marker.visible, "MobMarker should be hidden by default")

	var alert_marker = grid.get_node_or_null("AlertMarker")
	assert_or_fail(alert_marker != null and alert_marker is Sprite2D, "AlertMarker Sprite2D missing")
	assert_or_fail(textures_match(alert_marker.texture, "res://assets/minimapIcon_exclamationYellow.png"), "AlertMarker texture must use minimapIcon_exclamationYellow.png")
	assert_or_fail(not alert_marker.visible, "AlertMarker should be hidden by default")

	print("VALIDATION_PASSED: Minimap UI frame and markers are correctly set up")
	get_tree().quit()
