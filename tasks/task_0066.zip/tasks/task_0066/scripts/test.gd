extends Node

func _ready() -> void:
	run_validation()

func fail(reason: String) -> void:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)

func run_validation() -> void:
	var main: Node = get_node_or_null("Main")
	if not main:
		fail("Main scene root missing")
		return

	var platform: Node2D
	for child in main.get_children():
		if child is Node2D and child.get_script() != null:
			platform = child
			break
	
	if platform == null:
		fail("Platform Node2D with a script not found under Main")
		return

	var platform_script: Script = platform.get_script()
	if platform_script == null or not platform_script.is_tool():
		fail("Platform script must exist and be marked @tool")
		return

	var template_sprite: Node2D = platform.get_node_or_null("Templates/Sprite2D")
	var template_shape: CollisionShape2D = platform.get_node_or_null("Templates/CollisionShape2D")
	if template_sprite == null or template_shape == null:
		fail("Hidden template Sprite2D/CollisionShape2D not found under Templates")
		return

	if template_sprite.texture == null or not template_sprite.texture.resource_path.ends_with("tile_0108.tres"):
		fail("Template sprite must use the provided tile_0108 texture resource")
		return
	
	await get_tree().process_frame

	var segment_container: Area2D
	for child in platform.get_children():
		if child is Area2D:
			segment_container = child
			break
	
	if segment_container == null:
		fail("Area2D node for segments missing on the platform")
		return
	
	var initial_sprites: Array = segment_container.get_children().filter(func(c): return c is Sprite2D)
	var initial_length = initial_sprites.size()
	if initial_length == 0:
		fail("Platform generated no sprites initially.")
		return

	var length_property: StringName
	for prop in platform_script.get_script_property_list():
		if prop.type == TYPE_INT and prop.usage & PROPERTY_USAGE_EDITOR:
			length_property = prop.name
			break

	if length_property.is_empty():
		fail("No exported integer property found on the platform script to control length.")
		return
		
	var new_length = initial_length + 1
	platform.set(length_property, new_length)
	
	await get_tree().process_frame
	
	var final_sprites: Array = segment_container.get_children().filter(func(c): return c is Sprite2D)
	if final_sprites.size() != new_length:
		fail("Changing length property did not result in the correct number of sprites.")
		return

	final_sprites.sort_custom(func(a,b): return a.position.x < b.position.x)

	if new_length > 1:
		var offset = final_sprites[1].position - final_sprites[0].position
		if offset.is_zero_approx():
			fail("Sprites are not being offset from each other.")
			return
		for i in range(1, new_length):
			var expected_pos = final_sprites[0].position + offset * i
			if not final_sprites[i].position.is_equal_approx(expected_pos):
				fail("Sprite %d is not at the correct offseted position." % i)
				return

	var final_shapes: Array = segment_container.get_children().filter(func(c): return c is CollisionShape2D)
	if final_shapes.size() != new_length:
		fail("Changing length property did not result in the correct number of collision shapes.")
		return

	var mover_node: Node
	for child in platform.get_children():
		if child is Node2D and child.name.to_lower().contains("mover"):
			mover_node = child
			break
	
	if mover_node == null:
		fail("Could not find a candidate for the mover node on the platform.")
		return
		
	var detector_node: Node
	for child in mover_node.get_children():
		# The detector is the node that has the collision shapes
		var shapes_in_child = child.get_children().filter(func(c): return c is CollisionShape2D)
		if shapes_in_child.size() > 0:
			detector_node = child
			break
	
	if detector_node == null:
		# Fallback to checking the mover node itself
		var shapes_in_mover = mover_node.get_children().filter(func(c): return c is CollisionShape2D)
		if shapes_in_mover.size() > 0:
			detector_node = mover_node
		else:
			fail("Could not find a detector node with collision shapes under the mover node.")
			return

	var detector_shapes = detector_node.get_children().filter(func(c): return c is CollisionShape2D)
	if detector_shapes.size() != new_length:
		fail("The number of collision shapes in the detector (%d) does not match the platform length (%d)." % [detector_shapes.size(), new_length])
		return

	print("VALIDATION_PASSED: Safe platform duplicates sprite and collision templates with mover support")
	get_tree().quit()
