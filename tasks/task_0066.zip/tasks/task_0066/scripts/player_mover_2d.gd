@tool
extends Node2D
class_name PlayerMover2D

var player: Node2D = null

func _on_player_detector_area_entered(area: Area2D) -> void:
	player = area

func _on_player_detector_area_exited(_area: Area2D) -> void:
	player = null

func move_player(movement_amount: Vector2) -> void:
	if player:
		player.position += movement_amount

# TODO: expose helpers so the platform script can rebuild the detector's collision shapes.
