extends VisibleOnScreenNotifier2D
class_name VisibilityOffset2D

@export var target: Node2D
@export var offset_amount: Vector2 = Vector2.ZERO

func _ready() -> void:
	screen_exited.connect(_on_screen_exited)

func _on_screen_exited() -> void:
	if target:
		target.position += offset_amount
