extends Node2D

@export var speed: Vector2 = Vector2(32, 0)
@export var rotation_offset: Vector2 = Vector2(256, 0)
@export_range(1, 5) var length: int = 1

func _ready() -> void:
	$AutoMover2D.speed = speed
	$VisibilityOffset2D.offset_amount = rotation_offset
	# Currently only duplicates whatever static children live inside Area2D.
	# The adjustable multi-tile behavior + editor preview still need to be implemented.
