extends Node
class_name AutoMover2D

@export var target: Node2D
@export var speed: Vector2

signal moved(movement_amount: Vector2)

func _process(delta: float) -> void:
	if target == null:
		return
	var moved_amount := speed * delta
	target.position += moved_amount
	moved.emit(moved_amount)
