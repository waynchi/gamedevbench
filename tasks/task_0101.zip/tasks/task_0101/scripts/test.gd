extends Node

func _ready():
	run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)

func run_validation() -> void:
	var main_node = get_node_or_null("Main")
	if main_node == null:
		fail("Main node not found")
		return

	var enemy = main_node.get_node_or_null("Enemy")
	if enemy == null:
		fail("Enemy node not found")
		return
	if not enemy is CharacterBody2D:
		fail("Enemy must be CharacterBody2D")
		return
	if enemy.collision_layer != 2:
		fail("Enemy collision_layer must be 2")
		return
	if enemy.motion_mode != CharacterBody2D.MOTION_MODE_FLOATING:
		fail("Enemy motion_mode must be Floating")
		return
	if not is_equal_approx(enemy.wall_min_slide_angle, 0.0):
		fail("Enemy wall_min_slide_angle must be 0")
		return

	var sprite = enemy.get_node_or_null("Sprite2D")
	if sprite == null or not sprite is Sprite2D:
		fail("Enemy Sprite2D missing")
		return
	if sprite.texture == null or sprite.texture.resource_path != "res://assets/sprites/towerDefense_tile245.png":
		fail("Enemy Sprite2D texture must be towerDefense_tile245.png")
		return

	var collision_shape = enemy.get_node_or_null("CollisionShape2D")
	if collision_shape == null or not collision_shape is CollisionShape2D:
		fail("Enemy CollisionShape2D missing")
		return
	if collision_shape.shape == null or not collision_shape.shape is CircleShape2D:
		fail("Enemy collision shape must be CircleShape2D")
		return
	if not is_equal_approx(collision_shape.shape.radius, 12.0):
		fail("Enemy CircleShape2D radius must be 12")
		return

	var navigation = enemy.get_node_or_null("Navigation")
	if navigation == null or not navigation is Node2D:
		fail("Navigation Node2D missing")
		return

	var agent = navigation.get_node_or_null("NavigationAgent2D")
	if agent == null or not agent is NavigationAgent2D:
		fail("NavigationAgent2D missing")
		return
	if agent.debug_enabled != true:
		fail("NavigationAgent2D debug_enabled must be true")
		return
	if agent.path_postprocessing != 1:
		fail("NavigationAgent2D path_postprocessing must be 1")
		return

	var timer = navigation.get_node_or_null("Timer")
	if timer == null or not timer is Timer:
		fail("Timer missing")
		return
	if not is_equal_approx(timer.wait_time, 0.1):
		fail("Timer wait_time must be 0.1")
		return
	if timer.autostart != true and timer.is_stopped():
		fail("Timer autostart must be true")
		return

	print("VALIDATION_PASSED: Enemy navigation setup is correct")
	get_tree().quit(1)
