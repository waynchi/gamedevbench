# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Ran `uv run gamedevbench validate task_0053` → Result: FAILED with message "Add a Sprite2D child named Sprite2D". This is the expected failure since the starting point car.tscn only contains an empty CharacterBody2D node.
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Ran `uv run gamedevbench --gt validate task_0053` → Result: PASSED with message "Car scene hierarchy matches tutorial setup". Exit code 0.
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence:
    - `tasks/task_0053/scenes/main.tscn` exists and instances car.tscn
    - `tasks/task_0053/scenes/test.tscn` exists with TestRunner node that loads test.gd and instances main.tscn
    - Structure matches task_0001 pattern (TestRunner > Main instance)
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction: "keep the CharacterBody2D named Car as the root"
    - Transcript (lines 27-30): "CharacterBody2D\n     Sprite2D\n     CollisionShape2D\n     Camera2D"
  - Instruction: "add a Sprite2D child that uses res://assets/sprites/spritesheet_vehicles.png"
    - Transcript (line 37): "Add whatever sprite texture you like. For this demo, we'll use art from Kenney's Racing Pack."
  - Instruction: "enable region_rect so it crops Rect2(291, 0, 70, 133)"
    - Transcript does not specify exact region coordinates, but repo/car.tscn shows region_rect = Rect2(291, 0, 70, 133)
  - Instruction: "rotate the sprite 90° so the car faces forward"
    - Repo/car.tscn line 12 shows rotation = 1.5708 (90 degrees in radians)
  - Instruction: "Add a CollisionShape2D sibling that uses a CapsuleShape2D with radius 34 and height 138"
    - Transcript (line 37): "CapsuleShape2D is a good choice for the collision"
    - Repo/car.tscn lines 6-7 show exact dimensions: radius = 34.0, height = 138.0
  - Instruction: "also rotated 90° to match the sprite"
    - Repo/car.tscn line 18 shows rotation = 1.5708
  - Instruction: "add a Camera2D child of Car whose zoom is exactly (0.5, 0.5)"
    - Repo/car.tscn line 22 shows zoom = Vector2(0.5, 0.5)
  - Instructions Missing from Transcript: The exact sprite region coordinates (291, 0, 70, 133) and exact capsule dimensions (radius 34, height 138) are derived from the GitHub repository, not explicitly stated in the transcript. However, this is acceptable since the task is based on the "Scene setup" section which references using the repo's implementation.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The ground truth `tasks_gt/task_0053/scenes/car.tscn` is directly derived from `anna/data/kidscancode/car_steering/Car steering/repo/car.tscn`:
    - Lines 11-15 (GT) match lines 13-17 (repo): Sprite2D with rotation 1.5708, texture, region_enabled, region_rect
    - Lines 17-19 (GT) match lines 19-21 (repo): CollisionShape2D with rotation and CapsuleShape2D
    - Lines 21-22 (GT) match lines 23-24 (repo): Camera2D with zoom Vector2(0.5, 0.5)
    - Only differences: GT removes the script attachment (car.gd) since this task focuses only on scene assembly
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction in task_config.json is self-contained. It specifies:
    - Exact file path: "In scenes/car.tscn"
    - Root node requirement: "keep the CharacterBody2D named Car as the root"
    - Complete node hierarchy with all properties
    - Exact values for all parameters (texture path, region rect, rotation angles, capsule dimensions, camera zoom)
    - No references to "the tutorial", "the video", or other external resources
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 22-25): Check Car root is CharacterBody2D named "Car" / Instruction: "keep the CharacterBody2D named Car as the root"
  - Test 2 (lines 27-39): Check Sprite2D exists, has texture with spritesheet_vehicles.png, region enabled, region_rect = Rect2(291, 0, 70, 133), rotation = 90° / Instruction: "add a Sprite2D child that uses res://assets/sprites/spritesheet_vehicles.png, enable region_rect so it crops Rect2(291, 0, 70, 133), and rotate the sprite 90°"
  - Test 3 (lines 41-52): Check CollisionShape2D exists, uses CapsuleShape2D, radius = 34, height = 138, rotation = 90° / Instruction: "Add a CollisionShape2D sibling that uses a CapsuleShape2D with radius 34 and height 138, also rotated 90°"
  - Test 4 (lines 54-58): Check Camera2D exists with zoom = Vector2(0.5, 0.5) / Instruction: "add a Camera2D child of Car whose zoom is exactly (0.5, 0.5)"
  - Missing Coverage: None. All instruction elements are tested and all tests correspond to instruction elements.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1 Assertions:
    - [Check root is CharacterBody2D] → Instruction: "CharacterBody2D named Car as the root"
    - [Check root name == "Car"] → Instruction: "CharacterBody2D named Car"
  - Test 2 Assertions:
    - [Check Sprite2D child exists] → Instruction: "add a Sprite2D child"
    - [Check texture is not null] → Instruction: "that uses res://assets/sprites/spritesheet_vehicles.png"
    - [Check "spritesheet_vehicles.png" in texture path] → Instruction: "uses res://assets/sprites/spritesheet_vehicles.png"
    - [Check region_enabled == true] → Instruction: "enable region_rect"
    - [Check region_rect == Rect2(291, 0, 70, 133)] → Instruction: "crops Rect2(291, 0, 70, 133)"
    - [Check rotation ≈ PI/2 (90°)] → Instruction: "rotate the sprite 90°"
  - Test 3 Assertions:
    - [Check CollisionShape2D child exists] → Instruction: "Add a CollisionShape2D sibling"
    - [Check shape is CapsuleShape2D] → Instruction: "uses a CapsuleShape2D"
    - [Check capsule.radius ≈ 34] → Instruction: "radius 34"
    - [Check capsule.height ≈ 138] → Instruction: "height 138"
    - [Check rotation ≈ PI/2 (90°)] → Instruction: "rotated 90°"
  - Test 4 Assertions:
    - [Check Camera2D child exists] → Instruction: "add a Camera2D child of Car"
    - [Check zoom.distance_to(Vector2(0.5, 0.5)) < tolerance] → Instruction: "zoom is exactly (0.5, 0.5)"
  - **CRITICAL AMBIGUITY CHECKS**:
    - [x] String formatting: N/A - no string formatting required
    - [x] Exact string values/names: "Car", "Sprite2D", "CollisionShape2D", "Camera2D" all specified in instruction
    - [x] Number formats: All numbers specified exactly (291, 0, 70, 133, 34, 138, 90, 0.5)
    - [x] Comparison operators: All use equality/tolerance checks matching instruction ("exactly" for zoom, specific values for dimensions)
    - [x] Node names, paths, types: All specified ("CharacterBody2D named Car", "Sprite2D child", etc.)
    - [x] Property values: All exact values in instruction (Rect2(291, 0, 70, 133), radius 34, height 138, zoom (0.5, 0.5), rotation 90°)
  - Ambiguous Tests: None. Every test assertion has a corresponding exact specification in the instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: There is only one solution to this problem. The instruction specifies:
    - Exact node types and names
    - Exact texture path and region
    - Exact numerical values for all properties
    - The tests use small tolerances (ROT_TOL = 0.01, FLOAT_TOL = 0.25) for floating-point comparisons, which is appropriate flexibility for numeric precision without allowing alternative solutions.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence:
    - Folder structure: `tasks/task_0053/{scenes,scripts,assets}/` matches task_0001 pattern
    - File names: `project.godot`, `scenes/main.tscn`, `scenes/test.tscn`, `scenes/car.tscn`, `scripts/test.gd` follow naming conventions
    - Asset organization: `assets/spritesheet_vehicles.png` correctly referenced in instruction
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.
  - **RESOLUTION**: Fixed the instruction path from "res://assets/sprites/spritesheet_vehicles.png" to "res://assets/spritesheet_vehicles.png" to match the actual file structure.
  - All validation criteria pass:
    - Starting point correctly fails: ✅ "Add a Sprite2D child named Sprite2D"
    - Ground truth correctly passes: ✅ "Car scene hierarchy matches tutorial setup"
    - Instruction matches tutorial and repository
    - Tests comprehensively cover all instruction requirements
    - No ambiguous test assertions
    - Task is self-contained and multimodal


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The entire task is focused on node hierarchy and inspector properties: creating Sprite2D, CollisionShape2D, Camera2D nodes and setting their properties (texture, region_rect, rotation, shape parameters, zoom) via the inspector.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Setting the sprite region_rect to Rect2(291, 0, 70, 133) requires visual understanding of the spritesheet to select the correct car sprite from the texture atlas. The 90° rotation requirement also involves understanding the visual orientation of the car sprite.
- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: The instruction references the spritesheet texture asset (spritesheet_vehicles.png), and solvers must visually inspect this image to understand what region coordinates crop the desired car sprite. The task metadata in task_config.json lists "multimodal" as a tag.

# Notes

## Validation Test Results
- Starting point validation: ✅ Correctly fails with "Add a Sprite2D child named Sprite2D"
- Ground truth validation: ✅ Passes with "Car scene hierarchy matches tutorial setup"

## Tutorial Alignment
The task is well-aligned with the "Scene setup" section of the Car Steering tutorial (transcript lines 23-40). The tutorial describes the basic node hierarchy needed before implementing the physics code.

## Asset Path (RESOLVED)
Previously there was a minor inconsistency where the instruction referenced "res://assets/sprites/spritesheet_vehicles.png" but the actual file was at "res://assets/spritesheet_vehicles.png". This has been corrected in the task_config.json instruction to match the actual file structure.

## Test Coverage
The test.gd file provides comprehensive coverage:
- Node type and name verification
- Texture assignment and path checking
- Region rect exact match
- Rotation tolerance checking (within 0.01 radians)
- Capsule shape dimension checking (within 0.25 tolerance)
- Camera zoom vector distance checking

## Multimodal Aspects
This task requires visual inspection of the spritesheet to understand:
1. Which region contains the car sprite (coordinates 291, 0, 70, 133)
2. The original orientation of the sprite (requires 90° rotation)
3. Verification that the capsule collider matches the visual car body

## Repository Derivation
The ground truth scene is a simplified version of the tutorial repo's car.tscn:
- Removes the car.gd script (physics implementation is covered in task_0713)
- Keeps only the visual/structural elements (Sprite2D, CollisionShape2D, Camera2D)
- Uses identical property values from the repo

# Examples

## Matching task instruction to transcript

- "keep the CharacterBody2D named Car as the root"
    - Transcript lines 27-35: "Here's the car scene setup:\n\nCharacterBody2D\n     Sprite2D\n     CollisionShape2D\n     Camera2D"
- "add a Sprite2D child that uses res://assets/spritesheet_vehicles.png"
    - Transcript line 37: "Add whatever sprite texture you like. For this demo, we'll use art from Kenney's Racing Pack."
- "Add a CollisionShape2D sibling that uses a CapsuleShape2D"
    - Transcript line 37: "CapsuleShape2D is a good choice for the collision, so that the car won't have sharp corners to get caught on obstacles."
- "add a Camera2D child of Car"
    - Transcript lines 27-35: Shows Camera2D as part of the scene hierarchy

## Matching Test to Instruction

- Test 1 / Instruction 1 – "keep the CharacterBody2D named Car as the root"
    - Code: tasks/task_0053/scripts/test.gd:22-25 checks that car scene root is CharacterBody2D type and named "Car"
- Test 2 / Instruction 2 – "add a Sprite2D child that uses res://assets/spritesheet_vehicles.png, enable region_rect so it crops Rect2(291, 0, 70, 133), and rotate the sprite 90°"
    - Code: tasks/task_0053/scripts/test.gd:27-39 verifies Sprite2D exists, has texture containing "spritesheet_vehicles.png", region_enabled is true, region_rect equals Rect2(291, 0, 70, 133), and rotation is approximately PI/2 (90 degrees)
- Test 3 / Instruction 3 – "Add a CollisionShape2D sibling that uses a CapsuleShape2D with radius 34 and height 138, also rotated 90°"
    - Code: tasks/task_0053/scripts/test.gd:41-52 checks CollisionShape2D exists, shape is CapsuleShape2D type, radius is approximately 34, height is approximately 138, and rotation is approximately PI/2
- Test 4 / Instruction 4 – "add a Camera2D child of Car whose zoom is exactly (0.5, 0.5)"
    - Code: tasks/task_0053/scripts/test.gd:54-58 ensures Camera2D exists and zoom vector is within tolerance of Vector2(0.5, 0.5)
