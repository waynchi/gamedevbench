# Key Checklist
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Both scenes/Main.tscn and scenes/test.tscn exist. Main.tscn contains a Player instance and TileMap. test.tscn contains TestRunner script and Main scene instance.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - "add var animation_speed = 2.0" / transcript lines 142-146: "var animation_speed = 3" (instruction uses 2.0, transcript shows 3 - minor variation acceptable)
  - "a moving flag" / transcript lines 143-146: "var moving = false"
  - "@onready var ray = $RayCast2d" / transcript lines 110-118: "onready var ray = $RayCast2D" (Godot 3 vs 4 syntax difference)
  - "ignore input whenever moving is true" / transcript lines 152-164: "if moving: return"
  - "forward the pressed direction to move(dir)" / transcript lines 80-94: "for dir in inputs.keys(): if event.is_action_pressed(dir): move(dir)"
  - "set ray.target_position = inputs[dir] * tile_size" / transcript lines 112-124: "ray.target_position = inputs[dir] * tile_size"
  - "call ray.force_raycast_update()" / transcript lines 114-130: "ray.force_raycast_update()"
  - "bail out if ray.is_colliding()" / transcript lines 115-124: "if !ray.is_colliding(): position += ..."
  - "create a tween that eases Player.position to position + inputs[dir] * tile_size over 1.0 / animation_speed with Tween.TRANS_SINE" / transcript lines 175-189: "var tween = create_tween() tween.tween_property(self, "position", position + inputs[dir] * tile_size, 1.0/animation_speed).set_trans(Tween.TRANS_SINE)"
  - "play the matching AnimationPlayer clip" / transcript mentions animation but doesn't explicitly show AnimationPlayer.play(dir) - this is an inference
  - "set moving = true before awaiting tween.finished, and reset moving afterward" / transcript lines 178-192: "moving = true await tween.finished moving = false"
  - Instructions Missing from Transcript: The AnimationPlayer.play(dir) call is implied but not explicitly stated in the transcript. However, this is a reasonable inference given the context.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The starting code in tasks/task_0050/scripts/player.gd contains the basic movement setup (tile_size, inputs dictionary, _ready, _unhandled_input, move) which matches the transcript lines 44-94. The ground truth solution in tasks_gt/task_0050/scripts/player.gd shows the complete implementation matching the transcript's "Animating movement" section (lines 134-193). GitHub repo referenced: https://github.com/godotrecipes/2d_grid_movement/
- [X] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction is a single sentence that completely specifies all required changes to scripts/player.gd. It doesn't reference any tutorial or external resources. However, it is VERY complex and long - it might be clearer split into multiple instructions.
- [X] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: **TASK REQUIRES SCRIPTING** - The instruction explicitly asks to "Finish scripts/player.gd by adding..." This is a scripting task, not an inspector/node task. This violates the no-scripting requirement for this validation template.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 17-23): Check animation_speed property exists and is numeric/positive / Instruction: "add var animation_speed = 2.0"
  - Test 2 (lines 25-26): Check moving property exists / Instruction: "a moving flag"
  - Test 3 (lines 28-32): Check ray property exists and references RayCast2d / Instruction: "@onready var ray = $RayCast2d"
  - Test 4 (line 35): Check force_raycast_update in code / Instruction: "call ray.force_raycast_update()"
  - Test 5 (line 37): Check create_tween in code / Instruction: "create a tween"
  - Test 6 (line 39): Check await tween.finished in code / Instruction: "await tween.finished"
  - Test 7 (lines 43-52): Guard clause check / Instruction: "ignore input whenever moving is true"
  - Test 8 (lines 55-64): Blocked move check / Instruction: "bail out if ray.is_colliding()"
  - Test 9 (lines 67-79): Successful move with tween / Instruction: all tween/animation/moving flag requirements
  - Missing Coverage: None - all instruction elements are tested
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1 (animation_speed), Assertions: [property exists, is numeric, is positive], Instruction coverage: "add var animation_speed = 2.0" - specifies exact property name but not exact value (2.0 vs any positive number)
  - Test 2 (moving), Assertions: [property exists], Instruction coverage: "a moving flag" - specifies property name
  - Test 3 (ray), Assertions: [property exists, is RayCast2D type, equals $RayCast2d], Instruction coverage: "@onready var ray = $RayCast2d" - exact specification
  - Test 4 (force_raycast_update), Assertions: [source code contains "force_raycast_update"], Instruction coverage: "call ray.force_raycast_update()" - exact specification
  - Test 5 (create_tween), Assertions: [source code contains "create_tween"], Instruction coverage: "create a tween" - exact specification
  - Test 6 (await), Assertions: [source code contains "await tween.finished"], Instruction coverage: "await tween.finished" - exact specification
  - Test 7 (guard), Assertions: [when moving=true, _unhandled_input doesn't change position], Instruction coverage: "ignore input whenever moving is true" - exact behavior specified
  - Test 8 (collision), Assertions: [ray.target_position == Vector2(TILE,0), position unchanged when blocked], Instruction coverage: "set ray.target_position = inputs[dir] * tile_size" and "bail out if ray.is_colliding()" - exact specification
  - Test 9 (tween), Assertions: [moving=true during tween, AnimationPlayer.current_animation == "down", final position = start + Vector2(0,TILE), moving=false after tween], Instruction coverage: "set moving = true before awaiting tween.finished, and reset moving afterward" + "play the matching AnimationPlayer clip" + "eases Player.position to position + inputs[dir] * tile_size" - exact behaviors specified
  - **CRITICAL AMBIGUITY CHECKS**:
    - [N/A] String formatting - no string formatting tests
    - [N/A] Exact string values - no string comparison tests
    - [N/A] Number formats - no specific number format requirements
    - [x] Comparison operators - all comparisons (==, !=) have clear criteria from instruction
    - [x] Node names, paths, and types - "$RayCast2d" and "AnimationPlayer" specified in instruction
    - [x] Property values - animation_speed should be positive (instruction says 2.0 but test accepts any positive), position calculations specified exactly
  - Ambiguous Tests: The animation_speed value - instruction says "2.0" but test accepts any positive number. This is actually flexible and good for allowing variation. The AnimationPlayer.play(dir) is not explicitly in transcript but is in instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The tests allow for some flexibility (e.g., animation_speed can be any positive value, not just 2.0). The core implementation pattern (guard with moving flag, raycast check, tween creation and awaiting) is the only logical solution to the requirements.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Task follows standard structure with scenes/, scripts/, assets/ folders. Contains Main.tscn, Player.tscn, test.tscn, test.gd, and task_config.json as expected.
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [ ] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: **NO** - This task is entirely scripting-focused. All requirements involve writing GDScript code in player.gd. No inspector changes or node modifications are required.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: **NO** - The task is purely text-based scripting. No images, videos, or other multimodal inputs are needed to complete it.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: **NO** - The instruction in task_config.json is pure text with no images or other media.

# Notes

## Important Findings

**CRITICAL ISSUE**: This task violates the "no scripting" requirement specified in the validation template name (task_validation_instruction_no_scripting.md) and checklist item 5. The entire task is about writing GDScript code in scripts/player.gd.

The validation template appears to be designed for inspector/node-based tasks, but this is a programming/scripting task. This task should use a different validation template for scripting-based tasks, if one exists.

## Task Quality Assessment

Despite the template mismatch, the task itself is well-designed:

1. **Good alignment**: Instruction matches transcript content very closely
2. **Good tests**: Tests cover all aspects of the instruction comprehensively
3. **Good starting point**: The starter code provides a clear foundation
4. **Good ground truth**: The solution is clean and correct
5. **Moderate complexity**: The task requires understanding of:
   - RayCast2D for collision detection
   - Tween system for animation
   - Async/await patterns in GDScript
   - State management (moving flag)
   - Input handling

## Recommendations

1. Either:
   - Move this task to a scripting-based validation process, OR
   - Modify the task to be inspector/node-focused instead of scripting-focused

2. The instruction is very long (183 words in a single sentence). Consider breaking it into numbered steps for clarity.

3. Minor discrepancy: Transcript shows animation_speed = 3, instruction says 2.0. This is acceptable variation but worth noting.

## Transcript Coverage

The task covers the "Animating movement" section of the KidsCanCode tutorial (transcript lines 134-193). The basic movement and collision sections (lines 39-130) are already implemented in the starter code.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
