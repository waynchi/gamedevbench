# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Running `uv run gamedevbench validate task_0015` outputs "Validation result: FAILED" with message "Linear fog must be enabled"
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Running `uv run gamedevbench --gt validate task_0015` outputs "Validation result: PASSED" with message "Fog and LUT configuration complete"
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: `scenes/main.tscn` contains the Main node with WorldEnvironment as expected. `scenes/test.tscn` instantiates main.tscn and adds the test.gd script to TestRunner node.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Enable linear fog in the shared WorldEnvironment
    - "The next two options are kind of interconnected the first one is f and that pretty much does what it says on the tin it just creates linear fog that fills up the background"
  - Tint fog to Color(0.5176, 0.5529, 0.6196)
    - "I always tend to tone down a bit and then I always tend to tint it a little bit towards the atmospheric colors so a little bit Bluer"
  - Density 0.001 and sky affect 0.147
    - "and I also tend to tone down the sky effect" (specific values shown in GrittyEnvironment example)
  - Enable volumetric fog with albedo Color(0.8706, 0.7961, 0.7726)
    - "in addition to this we have volumetric fog now volumetric fog kind of works the same way but it's a lot more realistic"
  - Turn on Adjustments so the color correction slot uses ExtremeLUT.png Texture3D
    - "last but not least we have the adjustments tab... if we select the world environment and just drag that in as the color correction"
    - "it defaults to texture 2D but we want it on texture 3D"
  - Instructions Missing from Transcript: The specific numeric values (fog density 0.001, sky affect 0.147, exact color values) are demonstrated visually in the GrittyEnvironment example but not spoken in the transcript. However, these values are directly taken from the repository's GrittyEnvironment.tres file, making them part of the tutorial content.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The ground truth Environment settings in `tasks_gt/task_0015/scenes/main.tscn` lines 28-35 match exactly with the GrittyEnvironment.tres from the tutorial repository at `scripts/youtube_data_codex_2/Bonkahe/Basic Post Processing in Godot 4/repo/GrittyEnvironment.tres` lines 34-41:
    - fog_enabled = true
    - fog_light_color = Color(0.517647, 0.552941, 0.619608, 1)
    - fog_density = 0.001
    - fog_sky_affect = 0.147
    - volumetric_fog_enabled = true
    - volumetric_fog_albedo = Color(0.870588, 0.796078, 0.772549, 1)
    - adjustment_enabled = true
    - adjustment_color_correction uses ExtremeLUT.png
  - The starting point has these same properties but with fog_enabled=false, volumetric_fog_enabled=false, and adjustment_enabled=false (lines 28-35 in tasks/task_0015/scenes/main.tscn)
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction provides complete details: node path (WorldEnvironment), exact property names (fog_enabled, fog_light_color, fog_density, fog_sky_affect, volumetric_fog_enabled, volumetric_fog_albedo, adjustment_enabled, adjustment_color_correction), exact values (Color(0.5176, 0.5529, 0.6196), 0.001, 0.147, Color(0.8706, 0.7961, 0.7726)), and the specific asset to use (ExtremeLUT.png). The instruction also specifies the import type (Texture3D). No references to tutorial or other tasks.
- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: Task only requires enabling properties and setting values in the WorldEnvironment's Environment resource through the Godot inspector. No scripting mentioned in instructions. The test.gd file is pre-written and should not be modified by the solver.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 34-36): Check fog_enabled is true → Instruction: "Enable linear fog"
  - Test 2 (lines 37-39): Check fog_light_color matches Color(0.517647, 0.552941, 0.619608) → Instruction: "tint it to Color(0.5176, 0.5529, 0.6196)"
  - Test 3 (lines 40-42): Check fog_density is 0.001 → Instruction: "with density 0.001"
  - Test 4 (lines 43-45): Check fog_sky_affect is 0.147 → Instruction: "and sky affect 0.147"
  - Test 5 (lines 47-49): Check volumetric_fog_enabled is true → Instruction: "enable volumetric fog"
  - Test 6 (lines 50-52): Check volumetric_fog_albedo matches Color(0.870588, 0.796078, 0.772549) → Instruction: "with albedo Color(0.8706, 0.7961, 0.7726)"
  - Test 7 (lines 54-56): Check adjustment_enabled is true → Instruction: "turn on Adjustments"
  - Test 8 (lines 57-66): Check adjustment_color_correction is assigned, is Texture3D, and uses ExtremeLUT.png → Instruction: "so the color correction slot uses the provided ExtremeLUT.png Texture3D as its lookup table"
  - Missing Coverage: None. All instruction components are tested, and all tests correspond to instruction requirements.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1, Assertions: [fog_enabled == true], Instruction coverage: "Enable linear fog" - unambiguous boolean property
  - Test 2, Assertions: [fog_light_color matches Color(0.517647, 0.552941, 0.619608, 1) within tolerance 0.02], Instruction coverage: "tint it to Color(0.5176, 0.5529, 0.6196)" - exact color specified (note: instruction uses 4 decimal places, matching the precision needed)
  - Test 3, Assertions: [fog_density == 0.001 within tolerance 0.0002], Instruction coverage: "with density 0.001" - exact numeric value specified
  - Test 4, Assertions: [fog_sky_affect == 0.147 within tolerance 0.01], Instruction coverage: "and sky affect 0.147" - exact numeric value specified
  - Test 5, Assertions: [volumetric_fog_enabled == true], Instruction coverage: "enable volumetric fog" - unambiguous boolean property
  - Test 6, Assertions: [volumetric_fog_albedo matches Color(0.870588, 0.796078, 0.772549, 1) within tolerance 0.02], Instruction coverage: "with albedo Color(0.8706, 0.7961, 0.7726)" - exact color specified
  - Test 7, Assertions: [adjustment_enabled == true], Instruction coverage: "turn on Adjustments" - unambiguous boolean property
  - Test 8, Assertions: [adjustment_color_correction != null, is Texture3D type, resource_path ends_with "ExtremeLUT.png"], Instruction coverage: "so the color correction slot uses the provided ExtremeLUT.png Texture3D as its lookup table" - specifies the asset name (ExtremeLUT.png) and required type (Texture3D)
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - N/A, no string formatting required
    - [x] Exact string values/names are in instruction (not just "format text") - Yes: "ExtremeLUT.png", "WorldEnvironment"
    - [x] Number formats (zero-padding, decimal places) are specified - Yes: 0.001, 0.147, color components to 4 decimal places
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - Yes: exact values for booleans and numbers, ends_with for file path
    - [x] Node names, paths, and types match instruction exactly - Yes: "WorldEnvironment" (shared/under Main), Texture3D type
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - Yes: all values explicitly specified
  - Ambiguous Tests: None. All test conditions are explicitly and unambiguously defined in the instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: There is only one solution - enabling specific properties with exact values in the WorldEnvironment's Environment resource. The solution is clearly decipherable from the instructions. The tests use appropriate tolerances for floating-point comparisons (0.02 for colors, 0.0002 for fog_density, 0.01 for fog_sky_affect) and use ends_with for the file path check to allow for different resource path prefixes.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Task follows standard structure with `scenes/main.tscn`, `scenes/test.tscn`, `scripts/test.gd`, and `task_config.json`. Assets are in the root (ExtremeLUT.png) and assets/ folder. Structure matches expected layout.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Task is entirely inspector-focused, requiring the solver to configure Environment resource properties through the WorldEnvironment node inspector in Godot. Properties include fog settings, volumetric fog settings, and adjustment settings with a LUT texture.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Task requires understanding the visual effect of LUT (lookup table) color grading and fog effects. The ExtremeLUT.png is a visual asset that affects the final rendering. Understanding what "Texture3D" means for LUT import settings requires visual/spatial reasoning.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: The instruction references ExtremeLUT.png which is a multimodal asset, but the instruction itself is text-only. The image is an asset to be used, not an input in the instruction itself.

# Notes

## Validation Summary
Task task_0015 has been successfully validated. All key checklist items pass.

## Key Observations

### Tutorial Derivation
The task is directly derived from the "Basic Post Processing in Godot 4" tutorial by Bonkahe. Specifically, it recreates the "GrittyEnvironment" preset demonstrated in the tutorial. The tutorial walks through various post-processing effects including fog, volumetric fog, and LUT-based color correction.

### Instruction Clarity
The instruction is very clear and unambiguous, specifying:
- Exact node path (WorldEnvironment under Main)
- Exact property names (fog_enabled, fog_light_color, fog_density, etc.)
- Exact numeric values with appropriate precision
- Exact color values in RGBA format
- Specific asset name (ExtremeLUT.png)
- Required import type (Texture3D)

### Test Coverage
The test.gd file comprehensively covers all instruction requirements with appropriate tolerances:
- Boolean checks for enabled flags (fog_enabled, volumetric_fog_enabled, adjustment_enabled)
- Floating-point comparisons with reasonable tolerances (0.02 for colors, 0.0002 for density, 0.01 for sky affect)
- Type checking for the LUT (Texture3D)
- Path validation using ends_with for flexibility

### Multimodal Aspects
The task involves visual understanding of:
1. LUT (Lookup Table) color grading - understanding how a 3D texture affects final color output
2. Fog effects - understanding atmospheric rendering
3. The difference between linear fog and volumetric fog
4. The Texture3D import requirement for LUTs in Godot

### Transcript Alignment
While the general concepts (fog, volumetric fog, adjustments, LUT) are clearly discussed in the transcript, specific numeric values are demonstrated visually in the tutorial rather than spoken. However, these values are taken directly from the GrittyEnvironment.tres file in the tutorial repository, making them part of the official tutorial content.

## Testing Results
- Starting point test: FAILED as expected (fog disabled)
- Ground truth test: PASSED as expected (all properties configured correctly)

## No Issues Found
The task is well-structured, unambiguous, and suitable for inclusion in GameDevBench.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
