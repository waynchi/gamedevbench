extends PanelContainer

@onready var grid_container: GridContainer = $MarginContainer/GridContainer
@export var item_array: Array[Item] = []

func add_item_resource() -> void:
	pass

func clear_all_inventory_items() -> void:
	pass
