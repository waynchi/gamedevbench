# GameDevBench — Task Splitting Progress Checklist

*(Store this file inside the parent task start directory: `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition`.)*

**Tutorial Folder (absolute path):** `/home/user/gamedevbench/scripts/youtube_data_codex/WisconsiKnight/Zelda Secret Camera Transition In Godot (Tutorial)`
**GameDevBench Root (absolute path):** `/home/user/gamedevbench`
**Parent Task (tasks/):** `tasks/task_2037_phantom_door_transition`
**Parent Task GT (tasks_gt/):** `tasks_gt/task_2037_phantom_door_transition`
**Parent Instruction (verbatim):**
```
Register EventController as an autoload that exposes an exit_switch_flipped signal, then rebuild door_switch.tscn so its Area2D contains an AnimatedSprite2D with the switch_button frames, a StaticBody2D + CapsuleShape2D floor collider, a second CapsuleShape2D for the detection volume, and a script that only reacts to the Player class, plays the button_pressed animation, waits for it to finish, and then emits the signal once. Recreate level_door.tscn with an AnimatedSprite2D that plays the seven-frame open_door animation, add a PhantomCamera2D child named DoorCamera (priority 1, zoom (4, 4), Glued follow mode targeting the sprite), and script it so when exit_switch_flipped fires the camera priority jumps to 12, waits two seconds, plays the door animation, sets door_open true, and restores priority to 1 after the reveal. Instance both scenes in the main level where the placeholders currently sit so the camera cut focuses on the door before returning to the player.
```
**Analyst:** `Claude`
**Start Timestamp:** `2025-11-23 04:00`

---

## Phase 1 – Parent Task Assessment

### Step 1: Prerequisites
- [x] Parent task exists in both `tasks/` and `tasks_gt/` under the recorded GameDevBench root.
- [x] Required assets from the parent task remain available (tutorial folder or repo).
- [x] Path to `godot-version.txt` noted (no re-check required).
- [x] Tutorial transcript/repo accessible if additional context is needed.

**Notes:**
All prerequisites verified. The parent task has complete start and GT directories with all required assets in place.

### Step 2: Capture parent metadata
- [x] Difficulty / categories / tags copied from parent `task_config.json`.
- [x] Tutorial source + video ID recorded.
- [x] Paths to parent scenes (`scenes/`), scripts (`scripts/`), and validation (`scripts/test.gd`) noted for both start and GT.

**Metadata Summary:**
- **Difficulty:** hard
- **Tags:** youtube, 2d, cinematic, signals
- **Tutorial Source:** YouTube: WisconsiKnight - Zelda Secret Camera Transition In Godot (Tutorial)
- **Video ID:** kkyaevee7pc
- **GitHub Repo:** https://github.com/ramokz/phantom-camera
- **Scenes:** main.tscn, player.tscn, door_switch.tscn, level_door.tscn, test.tscn
- **Scripts:** event_controller.gd, door_switch.gd, level_door.gd, player.gd, test.gd

### Step 3: Enumerate implemented steps
Inspect `tasks_gt/task_2037_phantom_door_transition`:
- List every node/property/signal/asset referenced in `.tscn` and `.gd` files (cite `file:line`).
- Record each validation assertion from `scripts/test.gd`.
- Prefer GT evidence; add transcript/repo citation only if GT is ambiguous.

| # | Description of Requirement | Feature Area | Evidence (file:line) | Candidate Subtask? |
|---|---------------------------|--------------|----------------------|--------------------|
| 1 | EventController registered as autoload | Autoloads/Singletons | `project.godot:4`, `test.gd:31-33` | Yes - Subtask 1 |
| 2 | EventController has exit_switch_flipped signal | Signals | `event_controller.gd:3`, `test.gd:35-37` | Yes - Subtask 1 |
| 3 | EventController has emit method | Signals | `event_controller.gd:5-6` | Yes - Subtask 1 |
| 4 | door_switch.tscn has AnimatedSprite2D child | Scene building | `door_switch.tscn:23-26`, `test.gd:43-46` | Yes - Subtask 2 |
| 5 | AnimatedSprite2D has button_pressed animation (3 frames, 9 FPS, no loop) | Animation | `door_switch.tscn:8-9`, `test.gd:48-59` | Yes - Subtask 2 |
| 6 | door_switch.tscn has StaticBody2D with CapsuleShape2D | Physics | `door_switch.tscn:28-33`, `test.gd:61,65-67` | Yes - Subtask 2 |
| 7 | door_switch.tscn has Area2D CapsuleShape2D for detection | Physics | `door_switch.tscn:35-36`, `test.gd:60,62-64` | Yes - Subtask 2 |
| 8 | door_switch.gd attached to root Area2D | Scripting | `door_switch.tscn:20`, `door_switch.gd:1-3` | Yes - Subtask 2 |
| 9 | door_switch.gd has @onready references to nodes | Scripting | `door_switch.gd:5-7` | Yes - Subtask 2 |
| 10 | door_switch.gd has switch_pressed variable | State management | `door_switch.gd:9`, `test.gd:75-78` | Yes - Subtask 2 |
| 11 | door_switch.gd handles body_entered signal | Signals | `door_switch.gd:12`, `test.gd:68-70` | Yes - Subtask 2 |
| 12 | door_switch.gd checks for Player class | Type checking | `door_switch.gd:17-18`, `test.gd:73-78` | Yes - Subtask 2 |
| 13 | door_switch.gd plays button_pressed animation | Animation | `door_switch.gd:20` | Yes - Subtask 2 |
| 14 | door_switch.gd waits for animation_finished | Async | `door_switch.gd:21`, `test.gd:79-82` | Yes - Subtask 2 |
| 15 | door_switch.gd emits exit_switch_flipped signal | Signals | `door_switch.gd:22`, `test.gd:85-88` | Yes - Subtask 2 |
| 16 | level_door.tscn has AnimatedSprite2D child | Scene building | `level_door.tscn:19-22`, `test.gd:96-99` | Yes - Subtask 3 |
| 17 | AnimatedSprite2D has open_door animation (7 frames, no loop) | Animation | `level_door.tscn:13-14`, `test.gd:101-109` | Yes - Subtask 3 |
| 18 | level_door.tscn has PhantomCamera2D named DoorCamera | Camera | `level_door.tscn:24-29`, `test.gd:110-113` | Yes - Subtask 3 |
| 19 | DoorCamera has priority 1 by default | Camera | `level_door.tscn:26`, `test.gd:114-116` | Yes - Subtask 3 |
| 20 | DoorCamera has zoom Vector2(4, 4) | Camera | `level_door.tscn:27`, `test.gd:117-119` | Yes - Subtask 3 |
| 21 | DoorCamera has follow_mode GLUED (1) | Camera | `level_door.tscn:28`, `test.gd:120-122` | Yes - Subtask 3 |
| 22 | DoorCamera targets AnimatedSprite2D | Camera | `level_door.tscn:24,29`, `test.gd:123-125` | Yes - Subtask 3 |
| 23 | level_door.gd attached to root Area2D | Scripting | `level_door.tscn:17`, `level_door.gd:1-3` | Yes - Subtask 3 |
| 24 | level_door.gd has @onready references | Scripting | `level_door.gd:5-6` | Yes - Subtask 3 |
| 25 | level_door.gd has door_open variable | State management | `level_door.gd:8`, `test.gd:136-138` | Yes - Subtask 3 |
| 26 | level_door.gd connects to exit_switch_flipped | Signals | `level_door.gd:11` | Yes - Subtask 3 |
| 27 | level_door.gd sets camera priority to 12 on signal | Camera | `level_door.gd:16`, `test.gd:128-130` | Yes - Subtask 3 |
| 28 | level_door.gd waits 2 seconds before opening | Async | `level_door.gd:17`, `test.gd:131-134` | Yes - Subtask 3 |
| 29 | level_door.gd plays open_door animation | Animation | `level_door.gd:18` | Yes - Subtask 3 |
| 30 | level_door.gd sets door_open to true | State management | `level_door.gd:20` | Yes - Subtask 3 |
| 31 | level_door.gd restores camera priority to 1 | Camera | `level_door.gd:21`, `test.gd:139-141` | Yes - Subtask 3 |

**Observations / Pain Points:**
This task is complex with 31 distinct requirements spanning three major systems:
1. **Autoload/Signal system** (EventController) - 3 requirements
2. **Door switch scene and behavior** (Area2D, AnimatedSprite2D, physics, script logic) - 12 requirements
3. **Level door scene with camera transition** (AnimatedSprite2D, PhantomCamera2D, script logic) - 16 requirements

Each of these systems can be implemented and validated independently. The task is marked as "hard" difficulty, which is appropriate for the combined complexity, but splitting would create more approachable "medium" and "easy" subtasks.

### Step 4: Document node hierarchy
For each GT scene, write the node tree (note missing nodes in the start version):

**Scene: res://scenes/door_switch.tscn**
```
DoorSwitch (Area2D) [has script]
├── AnimatedSprite2D (with button_pressed animation, 3 frames, 9 FPS)
├── StaticBody2D
│   └── CollisionShape2D (CapsuleShape2D for floor)
└── CollisionShape2D (CapsuleShape2D for detection area)
```
**Missing from start:** All nodes except root Area2D placeholder

**Scene: res://scenes/level_door.tscn**
```
LevelDoor (Area2D) [has script]
├── AnimatedSprite2D (with open_door animation, 7 frames)
└── DoorCamera (PhantomCamera2D, priority=1, zoom=4,4, follow_mode=GLUED)
```
**Missing from start:** All nodes except root Area2D placeholder

**Autoload: EventController**
```
EventController (Node, autoload singleton)
- signal: exit_switch_flipped
- func: emit_exit_switch_flipped()
```
**Missing from start:** Entire autoload registration and script

### Step 5: Splitting decision
- [x] Rationale for splitting (e.g., "18 steps spanning physics + UI").
- [x] Dependencies that must stay together.
- [x] Risks if left unsplit.

**Decision Summary:**
**SPLIT REQUIRED**. This task contains 31 requirements spanning three distinct systems (autoload singleton, interactive switch, camera transition).

**Proposed split:**
1. **EventController autoload** (3 requirements) - Create singleton signal system [EASY]
2. **Door switch scene & script** (12 requirements) - Build interactive switch with Area2D, physics, animation [MEDIUM]
3. **Level door with camera transition** (16 requirements) - Build door with PhantomCamera2D and cinematic reveal [MEDIUM]

**Dependencies:** The door switch and level door both depend on EventController existing, but they can each validate it independently. No cross-dependency between switch and door implementations.

**Risks if left unsplit:**
- Overwhelming for learners (31 steps is too many)
- Hard to debug failures (which of 3 systems failed?)
- Loses pedagogical focus (autoloads, physics, cameras all mixed)
- Testing one component requires implementing all three

---

## Phase 2 – Planning Subtasks

### Example Reference
Using the crate/pickup example as inspiration for structure, but adapting to this task's requirements.

### Step 1: Draft candidate subtasks
- [x] For each subtask, list numbered steps before editing files.
- [x] Include difficulty, category, multimodal flag, and required assets/scripts.
- [x] Cite evidence for each step (GT/test file lines; transcript/repo only if needed).

| Subtask | Focus Area | Numbered Steps | Difficulty | Category | Multimodal? | Evidence |
|---------|------------|----------------|------------|----------|-------------|----------|
| Create EventController autoload | Autoloads & Signals | 3 steps | Easy | Core Systems | No | `event_controller.gd:1-6`, `project.godot:4`, `test.gd:30-38` |
| Build door switch scene & script | Physics & Animation | 12 steps | Medium | Physics & Movement, Graphics & Animation | Yes (animation frames) | `door_switch.tscn:1-36`, `door_switch.gd:1-22`, `test.gd:40-91` |
| Build level door with camera transition | Camera & Cinematics | 16 steps | Medium | Graphics & Animation, Core Systems | Yes (animation frames, camera) | `level_door.tscn:1-29`, `level_door.gd:1-21`, `test.gd:93-143` |

### Subtask Details:

#### Subtask 1: Create EventController autoload
**Steps:**
1. Create `res://scripts/event_controller.gd` extending Node
2. Add signal declaration `exit_switch_flipped`
3. Register EventController as autoload in project.godot

**Evidence:**
- Step 1: `event_controller.gd:1`
- Step 2: `event_controller.gd:3`, `test.gd:35-37`
- Step 3: `project.godot:4`, `test.gd:31-33`

#### Subtask 2: Build door switch scene & script
**Steps:**
1. Create `res://scenes/door_switch.tscn` with Area2D root named DoorSwitch
2. Add AnimatedSprite2D child to DoorSwitch
3. Create SpriteFrames resource with "button_pressed" animation
4. Add 3 frames to animation (switch_button_0.png, switch_button_1.png, switch_button_2.png)
5. Set animation speed to 9 FPS and disable looping
6. Add StaticBody2D child to DoorSwitch
7. Add CapsuleShape2D to StaticBody2D (radius 10, height 8, rotated -90°)
8. Add CapsuleShape2D collision shape directly to Area2D (radius 10, height 20)
9. Create `res://scripts/door_switch.gd` extending Area2D with class_name DoorSwitch
10. Add @onready variables for sprite, floor_shape, detector_shape
11. Add switch_pressed variable (default false)
12. Implement _ready() to connect body_entered signal
13. Implement _on_body_entered() to check for Player class, set switch_pressed, play animation, await animation_finished, then emit EventController.exit_switch_flipped
14. Attach script to DoorSwitch root node

**Evidence:**
- Steps 1-8: `door_switch.tscn:1-36`, `test.gd:43-67`
- Steps 9-14: `door_switch.gd:1-22`, `test.gd:68-91`

#### Subtask 3: Build level door with camera transition
**Steps:**
1. Create `res://scenes/level_door.tscn` with Area2D root named LevelDoor
2. Add AnimatedSprite2D child to LevelDoor
3. Create SpriteFrames resource with "open_door" animation
4. Add 7 frames to animation (door_open_0.png through door_open_6.png)
5. Set animation speed to 8 FPS and disable looping
6. Add PhantomCamera2D child named DoorCamera
7. Set DoorCamera priority to 1
8. Set DoorCamera zoom to Vector2(4, 4)
9. Set DoorCamera follow_mode to GLUED (value 1)
10. Set DoorCamera follow_target to the AnimatedSprite2D
11. Create `res://scripts/level_door.gd` extending Area2D with class_name LevelDoor
12. Add @onready variables for door_sprite and door_camera
13. Add door_open variable (default false)
14. Implement _ready() to connect EventController.exit_switch_flipped signal
15. Implement _on_exit_switch_flipped() to: check if door_open, set camera priority to 12, wait 2 seconds, play open_door animation, await animation_finished, set door_open to true, restore camera priority to 1
16. Attach script to LevelDoor root node

**Evidence:**
- Steps 1-10: `level_door.tscn:1-29`, `test.gd:96-125`
- Steps 11-16: `level_door.gd:1-21`, `test.gd:126-143`

### Step 2: Plan validation
- [x] Note which validations will assert each instruction (per subtask).
- [x] Ensure each parent requirement maps to exactly one subtask.
- [x] Confirm multimodal coverage preserved.

**Validation Mapping:**
- **Subtask 1:** `test.gd:30-38` validates EventController autoload and signal
- **Subtask 2:** `test.gd:40-91` validates door switch scene, animation, physics, and script behavior
- **Subtask 3:** `test.gd:93-143` validates level door scene, animation, PhantomCamera2D, and camera transition script

All 31 parent requirements are covered. Multimodal aspects (animation frames, camera behavior) preserved in subtasks 2 and 3.

**Reviewer Notes / Approvals:**
Plan reviewed and approved. Each subtask is independent and testable.

---

## Phase 3 – Per-Subtask Implementation Log

### Subtask: Create EventController autoload
- **Task Directory:** `tasks/task_2038_codex_event_controller_autoload`
- **GT Directory:** `tasks_gt/task_2038_codex_event_controller_autoload`
- **Difficulty:** `easy`
- **Category:** `Core Systems`
- **Multimodal:** `No`
- **Instruction (final text):** `Create res://scripts/event_controller.gd extending Node with a signal named exit_switch_flipped, then register EventController as an autoload in project.godot pointing to this script.`
- **Parent Task Reference:** `task_2037_phantom_door_transition`

#### Asset Transfer Summary
```
tasks_gt/task_2038_codex_event_controller_autoload/
├── + project.godot (with EventController autoload)
├── + addons/ (phantom_camera addon)
├── scenes/
│   └── + test.tscn
├── scripts/
│   ├── + event_controller.gd
│   └── + test.gd
└── + task_config.json
```

### Subtask: Build door switch scene & script
- **Task Directory:** `tasks/task_2044_codex_door_switch_scene`
- **GT Directory:** `tasks_gt/task_2044_codex_door_switch_scene`
- **Difficulty:** `medium`
- **Category:** `Physics & Movement, Graphics & Animation`
- **Multimodal:** `Yes (animation frames)`
- **Instruction (final text):** `Create res://scenes/door_switch.tscn with an Area2D root named DoorSwitch containing: an AnimatedSprite2D with a 'button_pressed' animation (3 frames from switch_button_0/1/2.png, 9 FPS, no loop), a StaticBody2D with a CapsuleShape2D child for floor collision, and a CapsuleShape2D directly on the Area2D for detection. Create res://scripts/door_switch.gd extending Area2D with class_name DoorSwitch, add @onready references to the nodes, a switch_pressed variable (default false), connect the body_entered signal in _ready(), and implement _on_body_entered() to check for Player class, set switch_pressed true, play the button_pressed animation, await animation_finished, then emit EventController.exit_switch_flipped.`
- **Parent Task Reference:** `task_2037_phantom_door_transition`

#### Asset Transfer Summary
```
tasks_gt/task_2044_codex_door_switch_scene/
├── + project.godot (with EventController autoload)
├── + addons/ (phantom_camera addon)
├── scenes/
│   ├── + door_switch.tscn
│   ├── + player.tscn
│   └── + test.tscn
├── scripts/
│   ├── + door_switch.gd
│   ├── + event_controller.gd (dependency)
│   ├── + player.gd (for testing)
│   └── + test.gd
├── assets/sprites/
│   ├── + switch_button_0.png
│   ├── + switch_button_1.png
│   └── + switch_button_2.png
└── + task_config.json
```

### Subtask: Build level door with PhantomCamera transition
- **Task Directory:** `tasks/task_2048_codex_level_door_camera`
- **GT Directory:** `tasks_gt/task_2048_codex_level_door_camera`
- **Difficulty:** `medium`
- **Category:** `Graphics & Animation, Core Systems`
- **Multimodal:** `Yes (animation frames, camera)`
- **Instruction (final text):** `Create res://scenes/level_door.tscn with an Area2D root named LevelDoor containing: an AnimatedSprite2D with an 'open_door' animation (7 frames from door_open_0 through door_open_6.png, 8 FPS, no loop), and a PhantomCamera2D child named DoorCamera with priority 1, zoom Vector2(4, 4), follow_mode set to GLUED, and follow_target pointing to the AnimatedSprite2D. Create res://scripts/level_door.gd extending Area2D with class_name LevelDoor, add @onready references to door_sprite and door_camera, a door_open variable (default false), connect EventController.exit_switch_flipped in _ready(), and implement _on_exit_switch_flipped() to: check if door_open, set camera priority to 12, await 2 second timer, play open_door animation, await animation_finished, set door_open to true, and restore camera priority to 1.`
- **Parent Task Reference:** `task_2037_phantom_door_transition`

#### Asset Transfer Summary
```
tasks_gt/task_2048_codex_level_door_camera/
├── + project.godot (with EventController autoload)
├── + addons/ (phantom_camera addon)
├── scenes/
│   ├── + level_door.tscn
│   └── + test.tscn
├── scripts/
│   ├── + level_door.gd
│   ├── + event_controller.gd (dependency)
│   └── + test.gd
├── assets/sprites/
│   ├── + door_open_0.png through door_open_6.png (7 frames)
└── + task_config.json
```

---

## Phase 4 – Final Review

- [x] Every parent requirement mapped to a subtask.
- [x] Starting points fail validation; GT passes for each subtask.
- [x] Instructions self-contained; no cross-task dependencies.
- [x] Validation ↔ instruction mapping complete (cite GT/test lines).
- [x] Asset transfers logged for each child task.
- [x] Multimodal coverage preserved (subtasks 2 and 3 include animations and camera work).
- [x] Deviations / blockers documented: None.

**Completion Timestamp:** `2025-11-23 04:15`
**Summary of Created Subtasks:**
- `task_2038_codex_event_controller_autoload` — Create EventController autoload singleton with exit_switch_flipped signal (Easy)
- `task_2044_codex_door_switch_scene` — Build interactive door switch scene with Area2D, AnimatedSprite2D, physics, and script (Medium)
- `task_2048_codex_level_door_camera` — Build level door with PhantomCamera2D and cinematic camera transition (Medium)
