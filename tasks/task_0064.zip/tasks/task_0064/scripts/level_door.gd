extends Area2D

class_name LevelDoor

var door_open := false
