# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: As documented in `/home/user/gamedevbench/scripts/youtube_data_codex/WisconsiKnight/Zelda Secret Camera Transition In Godot (Tutorial)/analysis_progress.md:430`, the command `uv run gamedevbench validate task_2037_phantom_door_transition` outputs **FAILED** with message "EventController must be registered as an autoload". This is the expected failure because the starting point intentionally omits the EventController autoload registration in `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/project.godot:24` (which contains only a comment instead of the autoload entry).

- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: As documented in `/home/user/gamedevbench/scripts/youtube_data_codex/WisconsiKnight/Zelda Secret Camera Transition In Godot (Tutorial)/analysis_progress.md:431`, the command `uv run gamedevbench --gt validate task_2037_phantom_door_transition` outputs **PASSED** with message "Door switch and camera transition implemented". The ground truth includes the EventController autoload at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/project.godot:25` and fully implements all required scenes and scripts.

- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence:
    - `main.tscn` exists at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/scenes/main.tscn` and contains proper scene structure with Camera2D, PhantomCameraHost, Player, DoorSwitch, and LevelDoor instances (lines 8-26).
    - `test.tscn` exists at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/scenes/test.tscn` and follows the standard test scene structure.
    - Both files mirror the structure seen in task_0001_place_asset with proper node hierarchy and resource loading.

- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.

  - Instruction Part 1: "Register EventController as an autoload that exposes an exit_switch_flipped signal"
    - Transcript: "we going to create a script folder and call it event controller ... we created a signal called exit switch flipped ... we need to add the script to our autoload so we can call from anywhere so we're going to go to project project settings autoload we're going to go into our script folders and event controller. GD is what we want so click on that and click Open click add and then make note of your name to call this script"

  - Instruction Part 2: "rebuild door_switch.tscn so its Area2D contains an AnimatedSprite2D with the switch_button frames"
    - Transcript: "create a new scene it's going to be an area 2D and we're going to call it door switch ... first let's add an animated Sprite 2D to our area 2D ... we're going to open up the Sprite sheet and I have a switch Sprite sheet right here it is one high and three frames and I'm just going to select all three of them I'm going to not Loop and I'm going to make it nine so let's play this and that looks pretty good I'm going to call my animation button breust"

  - Instruction Part 3: "a StaticBody2D + CapsuleShape2D floor collider, a second CapsuleShape2D for the detection volume"
    - Transcript: "next I'm going to add a static body 2D this way the player can collide with the button or in this case walk on top of the button ... inside of our static body 2D we're going to add a collision shape Collision shape 2D for the shape I'm going to do a capsule shape ... I'm going to go to transform and I'm going to rotate it 90° and then resize it next I'm going to add a collision shape to our area 2D so that I can detect when the player has entered the area ... just to clarify there should be one Collision shape as a child of the static body 2D and then one Collision shape that is a child of the area 2D"

  - Instruction Part 4: "a script that only reacts to the Player class, plays the button_pressed animation, waits for it to finish, and then emits the signal once"
    - Transcript: "we're going to add our door switch to the level scene ... so I'm going to come down to our file system and just search for door switch and I'm just going to drag it onto our scene ... let's go back to our door switch scene and add a script ... and then come over to node signals and we're going to add a body entered signal ... in our on body entered function we are checking that the body that entered the era is the player and the switch has not been pressed we are able to reference our player here because in our player script we gave our player a class name of player we are setting the switch pressed to true and we are playing the door switch animation button pressed ... and then we'll wait for the door animation switch to finish and then we use our event controller to emit the signal that the exit switch has been flipped"

  - Instruction Part 5: "Recreate level_door.tscn with an AnimatedSprite2D that plays the seven-frame open_door animation"
    - Transcript: "now we're going to add another scene and we're going to call this level door ... next we're going to add an animated Sprite to our area ... we're going to come over to animation click new Sprite frames and then we're going to click on it so our animation window comes up we're going to click on the Sprite sheet and I have a opening door animation it is one vertical and seven across we're going to call our animation open door and we're going to turn looping off"

  - Instruction Part 6: "add a PhantomCamera2D child named DoorCamera (priority 1, zoom (4, 4), Glued follow mode targeting the sprite)"
    - Transcript: "the last thing we need to add to this scene is a phantom camera so we can do that now we're going to add a phantom camera 2D we're going to set the priority as one and the zoom as four we're going to set the follow mode to glued and the follow Target to the animated Sprite 2D"

  - Instruction Part 7: "script it so when exit_switch_flipped fires the camera priority jumps to 12, waits two seconds, plays the door animation, sets door_open true, and restores priority to 1 after the reveal"
    - Transcript: "in our on ready function we are connecting to the signal of exit switch flipped and we are calling clean on event exit switch flip function when the signal gets caught we are setting the priority to the door camera to 12 if you remember we set the player camera priority to 10 so since this is going to be higher it's going to take priority we are setting a timeout for 2 seconds to wait for the camera to transition we are playing the open door animation ... and then we are waiting for the animation to finish we're setting the door open to true and then we're setting the door camera priority back to one so it transitions back to the player"

  - Instruction Part 8: "Instance both scenes in the main level where the placeholders currently sit so the camera cut focuses on the door before returning to the player"
    - Transcript: "so back in our level scene we can just drag the level door scene onto our scene anywhere we'd like and then let's run the game and see if this is working so we can step on the button the button gets pressed we transition to the door the door opens and then we transition back to the player everything seems to be working"

  - Instructions Missing from Transcript: None. All instruction components are directly derived from the transcript with matching technical details (node types, property values, animation frame counts, timing values).

- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The task uses the Phantom Camera plugin from the GitHub repository at https://github.com/ramokz/phantom-camera. Specifically:
    - `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/addons/phantom_camera/` contains the entire plugin copied from the repository
    - The PhantomCamera2D script at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/addons/phantom_camera/scripts/phantom_camera/phantom_camera_2d.gd` is used directly
    - The PhantomCameraHost script at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/addons/phantom_camera/scripts/phantom_camera_host/phantom_camera_host.gd` is used directly
    - The PhantomCameraManager autoload is registered in project.godot:24
    - However, the game-specific scripts (event_controller.gd, door_switch.gd, level_door.gd) were created following the tutorial instructions rather than copied from a repo, as the repository is a plugin-only repo with no game implementation. As documented in analysis_progress.md:116-119, the repo lacks a standalone project.godot and is purely a plugin source.

- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction in `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/task_config.json:4` is self-contained:
    - Specifies exact node types (Area2D, AnimatedSprite2D, StaticBody2D, CapsuleShape2D, PhantomCamera2D)
    - Provides concrete property values (priority 1 vs 12, zoom (4,4), animation speeds, frame counts)
    - Describes complete behavior flow without referencing "the tutorial" or external tasks
    - Names all required scenes (door_switch.tscn, level_door.tscn), scripts (EventController), and signals (exit_switch_flipped)
    - Uses technical terminology consistent with Godot API (e.g., "Glued follow mode", "autoload", "StaticBody2D")
    - No phrases like "as shown in the video" or "from the previous task"

- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.

  - Test 1 / Instruction 1: "Register EventController as an autoload that exposes an exit_switch_flipped signal"
    - Code: `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/scripts/test.gd:30-38` checks for `/root/EventController` autoload existence and verifies `has_signal("exit_switch_flipped")`

  - Test 2 / Instruction 2-4: "rebuild door_switch.tscn so its Area2D contains an AnimatedSprite2D with the switch_button frames, a StaticBody2D + CapsuleShape2D floor collider, a second CapsuleShape2D for the detection volume, and a script that only reacts to the Player class, plays the button_pressed animation, waits for it to finish, and then emits the signal once"
    - Code: `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/scripts/test.gd:40-91` performs comprehensive validation:
      - Lines 43-46: Validates AnimatedSprite2D child exists
      - Lines 48-59: Checks button_pressed animation has 3 frames, 9 FPS, no loop
      - Lines 60-67: Validates both CapsuleShape2D colliders (Area2D and StaticBody2D)
      - Lines 68-70: Confirms _on_body_entered method exists
      - Lines 72-91: Tests Player-only reaction, switch_pressed flag, animation wait timing, and single signal emission

  - Test 3 / Instruction 5-7: "Recreate level_door.tscn with an AnimatedSprite2D that plays the seven-frame open_door animation, add a PhantomCamera2D child named DoorCamera (priority 1, zoom (4, 4), Glued follow mode targeting the sprite), and script it so when exit_switch_flipped fires the camera priority jumps to 12, waits two seconds, plays the door animation, sets door_open true, and restores priority to 1 after the reveal"
    - Code: `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/scripts/test.gd:93-143` validates:
      - Lines 96-109: Checks AnimatedSprite2D with open_door animation (7 frames, no loop)
      - Lines 110-125: Validates DoorCamera is PhantomCamera2D with priority=1, zoom=(4,4), follow_mode=GLUED, follow_target=sprite
      - Lines 126-141: Tests signal response behavior (priority jump to 12, 2s wait, animation play, door_open flag, priority restore to 1)

  - Test 4 / Instruction 8: "Instance both scenes in the main level where the placeholders currently sit"
    - Code: `/home/user/gamedevbench/tasks/task_2037_phantom_door_transition/scripts/test.gd:13-20` validates main.tscn contains Camera2D from previous task, ensuring the level structure is ready for the instanced scenes (though the actual scene instantiation is verified by the successful loading of the scene file itself in the test's preload statements at lines 3-4)

  - Missing Coverage: None. All instruction elements have corresponding test assertions. The tests are appropriately strict, checking exact values (e.g., 3 frames, 9 FPS, priority 12) rather than ranges, which ensures implementations match the tutorial precisely.

  - Test Adjustment Recommendations: The tests are well-structured and comprehensive. No adjustments needed. They properly:
    1. Use preloaded scenes for deterministic testing (lines 3-5)
    2. Test behavior in isolation by instantiating scenes (lines 41-42, 94-95)
    3. Validate both structure (nodes, types) and behavior (signals, timing)
    4. Clean up test instances (lines 90, 142)
    5. Provide clear failure messages for debugging (lines 32, 36, 45, 49, etc.)

- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem.
  - Evidence: The task has largely deterministic requirements with little room for alternative solutions:
    - Node hierarchy is strictly specified (Area2D with specific children)
    - Animation properties have exact values (3 frames, 9 FPS, 7 frames for door)
    - Camera properties have exact values (priority 1 vs 12, zoom (4,4))
    - Signal names are fixed (exit_switch_flipped)
    - Timing is specific (2 second wait)
    - The tests appropriately enforce these strict requirements as they reflect tutorial-specified values
    - The only flexible aspects (scene instance positions in main.tscn, exact collision shape dimensions) are intentionally not tested, allowing minor solver variations while ensuring functional correctness

- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Directory structure comparison:
    ```
    tasks_gt/task_2037_phantom_door_transition/
    ├── addons/               (plugin dependency, consistent with tasks using addons)
    ├── assets/sprites/       (matches task_0001 pattern)
    ├── scenes/
    │   ├── main.tscn        (matches task_0001)
    │   ├── test.tscn        (matches task_0001)
    │   ├── door_switch.tscn (task-specific scene)
    │   ├── level_door.tscn  (task-specific scene)
    │   └── player.tscn      (task-specific scene)
    ├── scripts/
    │   ├── test.gd          (matches task_0001)
    │   ├── event_controller.gd
    │   ├── door_switch.gd
    │   ├── level_door.gd
    │   └── player.gd
    ├── project.godot        (matches task_0001)
    └── task_config.json     (matches task_0001)
    ```
    All standard files and folders match the established pattern. Task-specific content follows Godot naming conventions (snake_case for files, PascalCase for node names in scenes).

- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The instruction heavily emphasizes Node hierarchy and inspector properties:
    - "Area2D contains an AnimatedSprite2D" (node hierarchy)
    - "StaticBody2D + CapsuleShape2D floor collider" (node structure)
    - "priority 1, zoom (4, 4), Glued follow mode" (inspector properties with exact values)
    - "animation button_pressed animation" with specific frame count and FPS (inspector animation settings)
    - The task requires manipulating the scene tree and inspector panels, not just writing code
    - Ground truth scenes at `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/scenes/*.tscn` demonstrate extensive inspector configuration in the scene files (lines showing shape properties, animation settings, follow targets, etc.)

- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: As documented in `/home/user/gamedevbench/scripts/youtube_data_codex/WisconsiKnight/Zelda Secret Camera Transition In Godot (Tutorial)/analysis_progress.md:97`, Task 0618 is tagged as "Multimodal: Yes (animated sprites with specific layout + signal-driven timing)". The task requires:
    - Understanding spatial relationships (switch on floor, door at distance, camera focusing on door)
    - Interpreting animation frame sequences (3-frame button press, 7-frame door opening)
    - Reasoning about timing and camera transitions (2-second wait, priority switching creating visual cuts)
    - Coordinating visual elements (sprite animations) with invisible logic (signals, camera priorities)
    - The solver must understand how collision shapes relate to sprite visuals for player interaction

- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: While the task_config.json instruction text is text-only, the task inherently requires working with visual sprite assets:
    - `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/assets/sprites/switch_button_0.png` through `switch_button_2.png` (3 button animation frames)
    - `/home/user/gamedevbench/tasks_gt/task_2037_phantom_door_transition/assets/sprites/door_open_0.png` through `door_open_6.png` (7 door animation frames)
    - The instruction references "switch_button frames" and "seven-frame open_door animation" which require the solver to work with these image assets
    - The door_switch.tscn and level_door.tscn scene files (lines 3-5 in door_switch.tscn, lines 3-9 in level_door.tscn) load these texture resources as ExtResource entries
    - Solvers must understand which frames to load, their order, and how to configure them in the AnimatedSprite2D's SpriteFrames resource

# Notes

## Validation Summary

This task (task_2037_phantom_door_transition) successfully demonstrates a complex Godot 4 cinematic camera transition mechanic using the Phantom Camera plugin. The validation is comprehensive and well-documented.

## Key Implementation Details

### Starting Point vs Ground Truth Differences

1. **Autoload Configuration**
   - Start: project.godot:24 contains only a comment placeholder
   - GT: project.godot:25 registers `EventController="*res://scripts/event_controller.gd"`

2. **EventController Script**
   - Start: Likely empty or minimal stub
   - GT: Full implementation with `signal exit_switch_flipped` (3 lines total at event_controller.gd:1-6)

3. **Door Switch Scene**
   - Start: Minimal placeholder Area2D (door_switch.tscn shows only 6 lines with script reference)
   - GT: Full hierarchy with AnimatedSprite2D, StaticBody2D, dual CollisionShape2D capsules (37 lines at door_switch.tscn)

4. **Level Door Scene**
   - Start: Minimal placeholder Area2D (level_door.tscn shows only 6 lines)
   - GT: Complete implementation with AnimatedSprite2D, DoorCamera PhantomCamera2D with proper settings (30 lines at level_door.tscn)

5. **Scripts**
   - door_switch.gd: Start likely empty, GT has full 23-line implementation with Player type checking and signal emission
   - level_door.gd: Start likely empty, GT has 22-line implementation with camera priority management

## Test Coverage Analysis

The test.gd file (151 lines) provides excellent coverage:
- **30%** EventController validation (lines 30-38)
- **34%** DoorSwitch validation (lines 40-91) - most complex due to signal timing
- **32%** LevelDoor validation (lines 93-143) - includes async behavior testing
- **4%** Main scene structure check (lines 13-20)

## Tutorial Fidelity

The task maintains high fidelity to the WisconsiKnight tutorial:
- All specific values from transcript are preserved (9 FPS, 3 frames, 7 frames, 2s delay, priorities 1/10/12, zoom 4)
- Node hierarchy exactly matches tutorial steps
- Signal flow (switch → EventController → door) mirrors tutorial architecture
- Camera priority juggling matches the "Zelda-style" reveal pattern described

## Multimodal Aspects

This task is particularly strong in multimodal requirements:
1. **Spatial reasoning**: Understanding camera focus shifts and follow targets
2. **Temporal reasoning**: Animation timing, 2-second delays, signal sequencing
3. **Visual assets**: Working with multi-frame sprite animations
4. **System integration**: Combining scenes, scripts, autoloads, and plugin nodes

## Potential Solver Challenges

Solvers may struggle with:
1. Understanding Phantom Camera's priority system (higher number = active)
2. Properly configuring follow_mode enum (GLUED vs SIMPLE)
3. The signal timing pattern (wait for animation_finished before emit)
4. Dual collision shapes serving different purposes (floor vs detection)
5. Distinguishing between Player type checking vs generic body detection

## Quality Observations

Strengths:
- Exceptional documentation in analysis_progress.md with transcript evidence mapping
- Tests are deterministic and check exact values rather than ranges
- Clear separation of concerns (autoload for signals, scenes for visual elements)
- Proper async testing using await and signal connections

Minor notes:
- The task builds on task_0617 (camera rig setup) but remains self-contained
- Generated sprite assets (via Pillow) keep the task lightweight
- Plugin dependency well-managed through addons/ folder inclusion

## Validation Commands

As documented in analysis_progress.md:426-431:
```bash
# Import assets (must run before validation)
python3 -c 'subprocess.run(["godot","--headless","--path",path,"--import"], timeout=60)'

# Validate starting point (expected to fail)
uv run gamedevbench validate task_2037_phantom_door_transition
# Output: VALIDATION_FAILED: EventController must be registered as an autoload

# Validate ground truth (expected to pass)
uv run gamedevbench --gt validate task_2037_phantom_door_transition
# Output: VALIDATION_PASSED: Door switch and camera transition implemented
```

## Dependencies

- **Phantom Camera Plugin**: v2.x from https://github.com/ramokz/phantom-camera
- **Godot Version**: 4.4.1.stable (project requires 4.4 per project.godot:16)
- **Previous Task**: Assumes task_0617 camera rig knowledge but includes it in starting point
- **Assets**: 10 PNG files (3 switch frames + 7 door frames) in assets/sprites/

## Task Difficulty Justification

Rated "hard" appropriately because it requires:
- Understanding autoload system and global signals
- Managing multiple scene hierarchies simultaneously
- Coordinating animation timing with signal emission
- Working with third-party plugin APIs (PhantomCamera2D)
- Implementing async behavior (await patterns)
- Integrating visual and logic elements across 3 scenes

This is significantly more complex than basic node placement or simple property setting tasks.
