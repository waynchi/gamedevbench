# Key Checklist
- [ ] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Cannot validate - Godot is not available in this environment. However, manual analysis of test.gd (lines 16-47) shows it will fail on the starting point because:
    1. ArmsContainer node is missing from PlayerBody (test.gd:22-24)
    2. ArmsMesh instance is missing (test.gd:27-29)
    3. All export properties are not set in main.tscn (animation_tree, camera_node, arms_node, animation names, and numeric values)
  - Starting point main.tscn (lines 11-19) only has PlayerBody with CollisionShape3D and Camera3D, missing all required wiring
- [ ] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Cannot run validation - Godot not available. However, manual analysis shows ground truth should pass:
    1. Ground truth main.tscn (lines 12-40) has all required nodes: ArmsContainer at (0, 0.5, 0) and ArmsMesh instance
    2. All export properties are set correctly (lines 14-28): animation_tree, camera_node, arms_node, hand_state_machine_playback_path, all animation names, and all numeric values
    3. Test assertions in test.gd match the ground truth configuration exactly
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Both files exist in the task:
    - /home/user/gamedevbench/tasks/task_0045/scenes/main.tscn (verified, 20 lines)
    - /home/user/gamedevbench/tasks/task_0045/scenes/test.tscn (verified, 7 lines)
    - Both follow the same structure as task_0001_place_asset (scenes folder with main.tscn and test.tscn)
- [ ] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - **CRITICAL BLOCKER**: Cannot validate - Tutorial folder does not exist
  - Expected location: /home/user/gamedevbench/scripts/youtube_data_codex_2/Bonkahe/Godot 3D - Making a FPS Horror Game (C#) _ 02 _ Basic FPS controller
  - Actual status: Folder MISSING (verified with test -d command)
  - Impact: Cannot verify that task instructions are derived from tutorial transcript
  - Note: task_config.json references transcript excerpt (lines 12): "we'll just drag that in as a child of the player body... set the transform on the y-axis to 0.5" and "pull in the playback... name them idle lowered, idle raised, firing lowered one, firing raised one, then also reloading"
  - Without access to the full transcript.txt file, cannot validate instruction coverage
- [ ] The task code is directly derived from the repository code. Please document where the derived code is.
  - **CRITICAL BLOCKER**: Cannot validate - Tutorial folder does not exist
  - Expected repo location: {tutorial_folder}/repo
  - Cannot compare player_body_controller.gd, ArmsPrefab.tscn, or other assets with repository code
  - task_config.json references GitHub repo: https://github.com/Bonkahe/FPSHorrorMono
  - Without access to the tutorial folder's repo copy, cannot verify code derivation
- [ ] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: **PARTIALLY AMBIGUOUS** - Instruction has one critical ambiguity:
  - Instruction text: "...and the camera/arms NodePaths plus rotation and movement speeds match the tutorial values."
  - Problem: The phrase "match the tutorial values" is ambiguous - it doesn't specify exact values
  - However, the metadata in task_config.json (lines 18-26) does list specific values
  - The test file (test.gd:65-80) checks exact numeric values:
    - rotation_speed=0.3, camera_actual_rotation_speed=20, arms_actual_rotation_speed=12
    - vertical_rotation_limit=80, speed=5.0, jump_velocity=4.5
  - **ISSUE**: These specific values are NOT in the main instruction text, only in metadata and referenced as "tutorial values"
  - A solver reading just the instruction would not know what exact values to use
  - **RECOMMENDATION**: Instruction should explicitly state: "set rotation_speed to 0.3, camera_actual_rotation_speed to 20, arms_actual_rotation_speed to 12, vertical_rotation_limit to 80, speed to 5.0, and jump_velocity to 4.5"
  - All other parts of instruction are clear and self-contained (no tutorial references for other requirements)
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test Group 1 (lines 16-18): PlayerBody existence → Instruction: implicit (task operates on PlayerBody)
  - Test Group 2 (lines 19-21): Camera3D under PlayerBody → Instruction: "the camera...NodePaths" (implicit camera exists)
  - Test Group 3 (lines 22-24): ArmsContainer exists → Instruction: "Add an `ArmsContainer` Node3D under `PlayerBody`"
  - Test Group 4 (lines 25-26): ArmsContainer position (0, 0.5, 0) → Instruction: "move it to (0, 0.5, 0)"
  - Test Group 5 (lines 27-29): ArmsMesh exists under ArmsContainer → Instruction: "instance...there as `ArmsMesh`"
  - Test Group 6 (lines 30-31): ArmsMesh instances ArmsPrefab.tscn → Instruction: "instance `ScenePrefabs/ArmsPrefab.tscn`"
  - Test Group 7 (lines 33-34): animation_tree NodePath → Instruction: "animation tree points to the prefab"
  - Test Group 8 (lines 35-36): camera_node NodePath → Instruction: "camera...NodePaths"
  - Test Group 9 (lines 37-38): arms_node NodePath → Instruction: "arms NodePaths"
  - Test Group 10 (lines 39-40): hand_state_machine_playback_path → Instruction: "playback path stays `parameters/playback`"
  - Test Group 11 (lines 51-63): Animation names → Instruction: "idle/aim/fire/reload strings read `IdleLowered`, `IdleRaised`, `FiringLowered1`, `FiringRaised1`, `Reloading`"
    - idle_animation_name = "IdleLowered"
    - aiming_animation_name = "IdleRaised"
    - idle_fire_animation_name = "FiringLowered1"
    - aiming_fire_animation_name = "FiringRaised1"
    - reload_animation_name = "Reloading"
  - Test Group 12 (lines 65-80): Numeric values → Instruction: "rotation and movement speeds match the tutorial values" (AMBIGUOUS)
    - rotation_speed = 0.3
    - camera_actual_rotation_speed = 20.0
    - arms_actual_rotation_speed = 12.0
    - vertical_rotation_limit = 80.0
    - speed = 5.0
    - jump_velocity = 4.5
  - Missing Coverage: None - all instruction requirements have corresponding tests
  - Extra Tests: speed and jump_velocity (lines 71-72) are tested but not explicitly in instruction (covered by "movement speeds")
- [ ] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail

  - **Test 1 (lines 16-18)**: PlayerBody node existence and type
    - Assertions: `player` exists, `player is CharacterBody3D`
    - Instruction coverage: Implicit - instruction says "under `PlayerBody`" implying it exists
    - Ambiguity: NONE - PlayerBody existence is implicit in the starting point

  - **Test 2 (lines 19-21)**: Camera3D existence
    - Assertions: `player.get_node_or_null("Camera3D")` is not null
    - Instruction coverage: "the camera...NodePaths" implies Camera3D exists
    - Ambiguity: NONE - camera existence is in starting point and referenced in instruction

  - **Test 3 (lines 22-24)**: ArmsContainer existence
    - Assertions: `player.get_node_or_null("ArmsContainer")` is not null
    - Instruction coverage: "Add an `ArmsContainer` Node3D under `PlayerBody`"
    - Ambiguity: NONE - exact node name "ArmsContainer" specified

  - **Test 4 (lines 25-26)**: ArmsContainer position
    - Assertions: `arms_container.transform.origin.distance_to(Vector3(0, 0.5, 0)) > 0.001` (must be at 0,0.5,0)
    - Instruction coverage: "move it to (0, 0.5, 0)"
    - Ambiguity: NONE - exact coordinates specified

  - **Test 5 (lines 27-29)**: ArmsMesh existence
    - Assertions: `arms_container.get_node_or_null("ArmsMesh")` is not null
    - Instruction coverage: "instance...there as `ArmsMesh`"
    - Ambiguity: NONE - exact node name "ArmsMesh" specified

  - **Test 6 (lines 30-31)**: ArmsMesh scene path
    - Assertions: `arms_mesh.get_scene_file_path() != "res://ScenePrefabs/ArmsPrefab.tscn"`
    - Instruction coverage: "instance `ScenePrefabs/ArmsPrefab.tscn`"
    - Ambiguity: NONE - exact path specified (note: instruction uses relative path, test uses res:// absolute)

  - **Test 7 (lines 33-34)**: animation_tree NodePath
    - Assertions: NodePath property equals "ArmsContainer/ArmsMesh/AnimationTree"
    - Instruction coverage: "animation tree points to the prefab"
    - Ambiguity: **MINOR** - "points to the prefab" is slightly vague, but since ArmsPrefab.tscn contains AnimationTree (verified in ArmsPrefab.tscn:336), the path is deducible

  - **Test 8 (lines 35-36)**: camera_node NodePath
    - Assertions: NodePath property equals "Camera3D"
    - Instruction coverage: "camera...NodePaths"
    - Ambiguity: NONE - Camera3D is the only camera node, path is obvious

  - **Test 9 (lines 37-38)**: arms_node NodePath
    - Assertions: NodePath property equals "ArmsContainer"
    - Instruction coverage: "arms NodePaths"
    - Ambiguity: NONE - ArmsContainer is the arms node just created

  - **Test 10 (lines 39-40)**: hand_state_machine_playback_path
    - Assertions: String property equals "parameters/playback"
    - Instruction coverage: "playback path stays `parameters/playback`"
    - Ambiguity: NONE - exact string specified

  - **Test 11 (lines 51-63)**: Animation name properties
    - Assertions:
      - idle_animation_name == "IdleLowered"
      - aiming_animation_name == "IdleRaised"
      - idle_fire_animation_name == "FiringLowered1"
      - aiming_fire_animation_name == "FiringRaised1"
      - reload_animation_name == "Reloading"
    - Instruction coverage: "idle/aim/fire/reload strings read `IdleLowered`, `IdleRaised`, `FiringLowered1`, `FiringRaised1`, `Reloading`"
    - Ambiguity: **MINOR** - instruction lists the values but doesn't explicitly map which property gets which value. However, the property names in player_body_controller.gd (lines 5-9) make it clear: idle→IdleLowered, aiming→IdleRaised, idle_fire→FiringLowered1, aiming_fire→FiringRaised1, reload→Reloading

  - **Test 12 (lines 65-80)**: Numeric export values
    - Assertions:
      - rotation_speed == 0.3
      - camera_actual_rotation_speed == 20.0
      - arms_actual_rotation_speed == 12.0
      - vertical_rotation_limit == 80.0
      - speed == 5.0
      - jump_velocity == 4.5
    - Instruction coverage: "rotation and movement speeds match the tutorial values"
    - Ambiguity: **CRITICAL** - "tutorial values" does not specify exact numbers. Solver cannot determine values without looking at metadata or tutorial

  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction
      - All string values are exact: "ArmsContainer", "ArmsMesh", "ScenePrefabs/ArmsPrefab.tscn", "parameters/playback"
      - Animation names all specified exactly: "IdleLowered", "IdleRaised", "FiringLowered1", "FiringRaised1", "Reloading"
    - [x] Exact string values/names are in instruction (not just "format text")
      - All node names explicit: ArmsContainer, ArmsMesh, Camera3D, PlayerBody
      - All property string values explicit (except numeric "tutorial values")
    - [ ] Number formats (zero-padding, decimal places) are specified
      - **FAIL**: Numeric values are NOT in instruction, only referenced as "tutorial values"
      - Test checks exact floats (0.3, 20.0, 12.0, 80.0, 5.0, 4.5) but instruction doesn't list them
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria
      - Position check uses distance tolerance (< 0.001), reasonable for Vector3 comparison
      - Scene path check uses != for exact match
      - All other checks are straightforward equality
    - [x] Node names, paths, and types match instruction exactly
      - Node names: ArmsContainer (Node3D), ArmsMesh (instanced scene), Camera3D
      - NodePaths: "Camera3D", "ArmsContainer", "ArmsContainer/ArmsMesh/AnimationTree"
      - All specified in instruction
    - [ ] Property values (numbers, booleans, strings) have exact values in instruction
      - Strings: YES, all exact
      - Numbers: **NO**, numeric export values not specified
  - Ambiguous Tests: **Test 12 (numeric values)** - The six numeric export properties lack exact specification in the instruction. The phrase "match the tutorial values" is ambiguous and unusable without external reference.
- [ ] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: **MOSTLY SINGLE SOLUTION, BUT AMBIGUOUS ON NUMERIC VALUES**
  - The structural requirements (nodes, scene instance, NodePaths, strings) have only one solution, clearly specified
  - The numeric values are ambiguous due to "tutorial values" reference
  - Tests are appropriately strict for a configuration task (exact NodePaths, exact scene path, exact animation names)
  - Position tolerance (0.001) is appropriate for floating-point Vector3 comparison
  - If numeric values were specified in instruction, this would be a single-solution task with clear requirements
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Folder structure is consistent
  - Task folder: /home/user/gamedevbench/tasks/task_0045/
  - Ground truth folder: /home/user/gamedevbench/tasks_gt/task_0045/
  - Standard structure present:
    - project.godot ✓
    - scenes/main.tscn ✓
    - scenes/test.tscn ✓
    - scripts/test.gd ✓
    - scripts/player_body_controller.gd ✓
    - task_config.json ✓
  - Additional assets appropriate for this task:
    - ScenePrefabs/ArmsPrefab.tscn (required by instruction)
    - Materials/ folder (referenced by ArmsPrefab)
    - Meshes/ folder (referenced by ArmsPrefab)
  - Naming follows convention: task_{number}_codex_{descriptive_name} (compared to task_0001)
- [ ] PROCEED. Check this box is the task is validated and all key checks pass successfully.
  - **CANNOT PROCEED - CRITICAL BLOCKERS IDENTIFIED:**
  - **Blocker 1**: Tutorial folder does not exist - cannot validate instruction vs transcript
  - **Blocker 2**: Tutorial folder does not exist - cannot validate code derivation from repository
  - **Blocker 3**: Instruction contains ambiguous reference "tutorial values" for numeric exports
  - **Recommendation**: Before proceeding, must:
    1. Locate or obtain tutorial folder with transcript.txt and repo
    2. Update instruction to explicitly list numeric values instead of "tutorial values"
    3. Verify instruction matches transcript excerpts
    4. Verify code is derived from repository


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: YES - This is primarily a node hierarchy and inspector configuration task
  - Node hierarchy: Add ArmsContainer under PlayerBody, instance ArmsMesh under ArmsContainer
  - Inspector properties: Set 11 export properties on PlayerBody (animation_tree, camera_node, arms_node, hand_state_machine_playback_path, 5 animation names, 4 rotation/speed values, speed, jump_velocity)
  - Position/Transform: Set ArmsContainer position to (0, 0.5, 0)
  - Scene instance: Instance ArmsPrefab.tscn as ArmsMesh
  - This task requires extensive inspector work, making it highly Node/inspector-focused
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: NO - Task is text-only
  - All requirements are textual: node names, paths, property values, coordinates
  - No visual assets need to be analyzed or understood
  - No spatial/visual reasoning required (position is given as exact coordinates)
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: NO - Instruction is pure text
  - task_config.json instruction field contains only text
  - No images, diagrams, or visual references in instruction
  - Note: The task USES 3D assets (ArmsPrefab with mesh/materials) but doesn't require understanding them visually

# Notes

## Summary of Validation

Task: task_0045 - FPS Arms Prefab Wiring
Date: 2025-11-18
Validator: AI Analysis (Godot runtime not available)

## Key Findings

### CRITICAL BLOCKERS (3)

1. **Tutorial Folder Missing**
   - Path: scripts/youtube_data_codex_2/Bonkahe/Godot 3D - Making a FPS Horror Game (C#) _ 02 _ Basic FPS controller
   - Impact: Cannot validate instruction against transcript
   - Impact: Cannot validate code derivation from repository
   - Referenced in task_config.json but folder does not exist on filesystem

2. **Ambiguous Numeric Values in Instruction**
   - Instruction says: "rotation and movement speeds match the tutorial values"
   - Tests check exact values: rotation_speed=0.3, camera_actual_rotation_speed=20, arms_actual_rotation_speed=12, vertical_rotation_limit=80, speed=5.0, jump_velocity=4.5
   - Problem: Solver cannot determine these values from instruction alone
   - Recommendation: Update instruction to explicitly list all six numeric values

3. **Cannot Run Validation Tests**
   - Godot engine not available in validation environment
   - Manual analysis of test.gd shows it should fail on starting point and pass on ground truth
   - But cannot confirm actual test execution

### STRENGTHS

1. **Excellent Test Coverage**
   - All structural requirements have corresponding tests
   - Tests are appropriately strict for a configuration task
   - Test file is well-organized and readable

2. **Clear Structural Requirements**
   - Node names explicitly specified: ArmsContainer, ArmsMesh
   - Paths explicitly specified: ScenePrefabs/ArmsPrefab.tscn
   - NodePaths clearly defined: "Camera3D", "ArmsContainer", "ArmsContainer/ArmsMesh/AnimationTree"
   - Animation names all explicit: IdleLowered, IdleRaised, FiringLowered1, FiringRaised1, Reloading
   - Position explicit: (0, 0.5, 0)

3. **Consistent Folder Structure**
   - Follows standard task organization
   - Both starting point and ground truth folders exist
   - All required files present (main.tscn, test.tscn, test.gd, task_config.json, project.godot)
   - Additional assets (ArmsPrefab, Materials, Meshes) appropriately included

### MINOR ISSUES

1. **Slight Ambiguity in Animation Name Mapping**
   - Instruction lists animation names but doesn't explicitly map idle→IdleLowered, aim→IdleRaised, etc.
   - However, property names in player_body_controller.gd make mapping obvious
   - Not a critical issue but could be clearer

2. **Path Format Difference**
   - Instruction uses relative path: "ScenePrefabs/ArmsPrefab.tscn"
   - Test checks absolute path: "res://ScenePrefabs/ArmsPrefab.tscn"
   - This is fine (Godot normalizes), but worth noting

## Test Analysis

### Test Breakdown
- 12 test groups covering all requirements
- Lines 16-31: Node hierarchy and structure (6 assertions)
- Lines 33-40: NodePath properties (4 assertions)
- Lines 51-63: Animation name properties (5 assertions)
- Lines 65-80: Numeric export properties (6 assertions)

### Test Quality
- Appropriate use of tolerance for Vector3 comparison (0.001)
- Good error messages using _fail() helper
- Reads scene state directly to validate inspector properties (not just runtime state)
- Tests both node existence and property configuration

## Recommendations for Task Improvement

1. **URGENT**: Update instruction to replace "tutorial values" with explicit numeric values
   - Current: "rotation and movement speeds match the tutorial values"
   - Recommended: "set rotation_speed to 0.3, camera_actual_rotation_speed to 20.0, arms_actual_rotation_speed to 12.0, vertical_rotation_limit to 80.0, speed to 5.0, and jump_velocity to 4.5"

2. **URGENT**: Obtain tutorial folder with transcript and repository
   - Needed to validate instruction correctness
   - Needed to verify code derivation

3. **OPTIONAL**: Make animation name mapping more explicit
   - Current: "the idle/aim/fire/reload strings read `IdleLowered`, `IdleRaised`, `FiringLowered1`, `FiringRaised1`, `Reloading`"
   - Better: "set idle_animation_name to `IdleLowered`, aiming_animation_name to `IdleRaised`, idle_fire_animation_name to `FiringLowered1`, aiming_fire_animation_name to `FiringRaised1`, and reload_animation_name to `Reloading`"

## Files Analyzed

- /home/user/gamedevbench/tasks/task_0045/task_config.json
- /home/user/gamedevbench/tasks/task_0045/scenes/main.tscn (starting point)
- /home/user/gamedevbench/tasks/task_0045/scenes/test.tscn
- /home/user/gamedevbench/tasks/task_0045/scripts/test.gd
- /home/user/gamedevbench/tasks/task_0045/scripts/player_body_controller.gd
- /home/user/gamedevbench/tasks/task_0045/ScenePrefabs/ArmsPrefab.tscn
- /home/user/gamedevbench/tasks_gt/task_0045/scenes/main.tscn (ground truth)
- /home/user/gamedevbench/youtube_documentation/task_validation_instruction.md
- /home/user/gamedevbench/tasks/task_0001_place_asset/ (reference for structure comparison)
- /home/user/gamedevbench/tasks/task_0001/ (reference for codex task comparison)

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
