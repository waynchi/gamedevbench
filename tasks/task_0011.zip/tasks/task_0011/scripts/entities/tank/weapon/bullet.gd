extends Area2D
class_name Bullet

var direction: Vector2 = Vector2.ZERO
var tank

func _physics_process(_delta):
    pass

func _on_area_entered(_area):
    pass

func _on_body_entered(_body):
    pass
