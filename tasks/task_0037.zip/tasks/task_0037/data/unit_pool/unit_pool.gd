class_name UnitPool
extends Resource

var returned_units: Array[UnitStats] = []

func add_unit(stats: UnitStats) -> void:
	returned_units.append(stats)
