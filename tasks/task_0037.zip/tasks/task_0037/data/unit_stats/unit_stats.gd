class_name UnitStats
extends Resource

@export var name: String
@export_range(1, 3) var tier := 1
@export var base_cost := 3

func get_gold_value() -> int:
	return base_cost * tier
