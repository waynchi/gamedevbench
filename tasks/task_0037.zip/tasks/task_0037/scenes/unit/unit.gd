class_name Unit
extends Area2D

signal quick_sell_pressed

@export var stats: UnitStats

@onready var drag_and_drop: DragAndDrop = $DragAndDrop

func _ready() -> void:
	add_to_group("units")

func simulate_drop() -> void:
	drag_and_drop.simulate_drop(self)

func simulate_quick_sell() -> void:
	quick_sell_pressed.emit()
