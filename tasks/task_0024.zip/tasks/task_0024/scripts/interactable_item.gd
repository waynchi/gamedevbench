extends Node3D
class_name InteractableItem

@export var item_highlight_mesh: MeshInstance3D

func gain_focus() -> void:
	pass

func lose_focus() -> void:
	pass
