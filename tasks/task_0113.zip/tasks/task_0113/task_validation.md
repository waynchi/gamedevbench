# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure 
  - Evidence: `uv run gamedevbench validate task_0113` -> FAILED with "GameArea TileMapLayer missing".
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: `uv run gamedevbench --gt validate task_0113` -> PASSED with "Task completed successfully".
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: `tasks/task_0113/scenes/main.tscn` and `tasks/task_0113/scenes/test.tscn` exist; GT has matching structure.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Create TileSet using tiles.png with 32x32 size (instruction: "Create a TileSet resource at scenes/arena/tileset.tres using assets/sprites/tiles.png as an atlas source with a 32x32 tile size.")
    - Transcript: "change the tile size ... 32x32 ... drag and drop ... tiles.png ... create the tiles ... save this resource."
  - GameArea at (160, 32) with checkerboard-style tiles (instruction: "add a TileMapLayer named GameArea at position (160, 32) and paint a checkerboard-style playfield using at least two different tiles")
    - Transcript: "rename this to game area ... position is 160 by 32 ... checkerboard effect."
  - Decor/Highlight children; Decor painted, Highlight empty (instruction: "Under GameArea add TileMapLayer children named Decor and Highlight, paint Decor with at least one tile ... leave Highlight empty.")
    - Transcript: "add another tile map layer ... Decor ... add a couple ... duplicate ... rename ... highlight ... delete those ... leave it empty."
  - Bench at (160, 320) with tiles and Highlight child at (160, 32) empty (instruction: "Add a TileMapLayer named Bench at position (160, 320)... add a child TileMapLayer named Highlight positioned at (160, 32) that remains empty.")
    - Transcript: "rename this to bench ... position ... 160 and 320 ... add a highlight tile map layer ... position 160, 32 ... leave it empty."
  - Instructions Missing from Transcript: None noted.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: `tasks_gt/task_0113/scenes/main.tscn` node structure mirrors `scripts/youtube_data_codex_2/GodotGameLab/Godot 4 Autobattler Tutorial_ TileMapLayers & Particles (S1E1)/repo/scenes/arena/arena.tscn` for GameArea/Decor/Highlight/Bench, and `tasks_gt/task_0113/scenes/arena/tileset.tres` matches `.../repo/scenes/arena/tileset.tres` (tiles.png atlas source, 32x32 tile size).
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: Instruction specifies node names, positions, tileset path/size/texture, checkerboard requires at least two tiles, Decor/Bench require at least one tile, and both Highlight layers must be empty.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1, Instruction 1: TileSet path/texture/tile_size and atlas source on each TileMapLayer match tileset creation instruction.
  - Test 2, Instruction 2: GameArea node existence/type/position and checkerboard-style using >=2 tiles matches instruction.
  - Test 3, Instruction 3: Decor/Highlight existence; Decor non-empty; Highlight empty matches instruction.
  - Test 4, Instruction 4: Bench existence/position, non-empty paint; Bench Highlight existence/position and empty matches instruction.
  - Missing Coverage: None.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test group 1, Assertions: `Main` exists; `GameArea` TileMapLayer under Main; position `(160, 32)`; TileSet path `scenes/arena/tileset.tres`; tile size `32x32`; atlas source exists; texture `assets/sprites/tiles.png`. Instruction coverage: TileSet resource path, atlas source, tile size, texture path, and GameArea position.
  - Test group 2, Assertions: `Decor` child TileMapLayer exists; has at least one painted tile; `Highlight` child TileMapLayer exists; highlight empty. Instruction coverage: Decor/Highlight child nodes; Decor painted with at least one tile; Highlight empty.
  - Test group 3, Assertions: `Bench` TileMapLayer exists; position `(160, 320)`; bench painted with at least one tile; Bench/Highlight exists; Bench/Highlight position `(160, 32)`; Bench/Highlight empty. Instruction coverage: Bench position, paint requirement, highlight position and emptiness.
  - Test group 4, Assertions: GameArea has at least two distinct tiles (checkerboard-style). Instruction coverage: checkerboard-style using at least two different tiles.
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction (not applicable).
    - [x] Exact string values/names are in instruction (node names, resource paths).
    - [x] Number formats (zero-padding, decimal places) are specified (explicit integer positions).
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria (exact positions, path suffixes, non-empty checks).
    - [x] Node names, paths, and types match instruction exactly.
    - [x] Property values (numbers, booleans, strings) have exact values in instruction.
  - Ambiguous Tests: None.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: Tests allow any checkerboard-style GameArea using >=2 tiles and any painted Decor/Bench tiles; multiple valid layouts pass.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Standard structure with `project.godot`, `scenes/main.tscn`, `scenes/test.tscn`, `scripts/test.gd`, and `assets/`.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused. 
  - Evidence: Requires TileMapLayer nodes, child structure, and position settings in `scenes/main.tscn`.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Requires painting tiles from `assets/sprites/tiles.png` and constructing a checkerboard-style playfield.
- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: Instruction references `assets/sprites/tiles.png`.

# Notes
- Tests updated to validate non-empty painting and checkerboard-style tile variety instead of exact tile_map_data bytes.
