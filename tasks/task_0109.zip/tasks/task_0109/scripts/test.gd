extends Node

func _ready() -> void:
	run_validation()

func fail(message: String) -> bool:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)
	return false

func assert_value_track(anim: Animation, path: NodePath, times: Array, values: Array) -> bool:
	var track := anim.find_track(path, Animation.TYPE_VALUE)
	if track == -1:
		return fail("Missing value track: " + str(path))
	if anim.track_get_key_count(track) != times.size():
		return fail("Track key count mismatch for " + str(path))
	for i in times.size():
		var time := anim.track_get_key_time(track, i)
		var value: Variant = anim.track_get_key_value(track, i)
		if not is_equal_approx(time, times[i]):
			return fail("Key time mismatch for " + str(path) + " at index " + str(i))
		if value != values[i]:
			return fail("Key value mismatch for " + str(path) + " at index " + str(i))
	return true

func assert_method_track(anim: Animation, method_name: String, time_value: float) -> bool:
	var track := anim.find_track(NodePath("."), Animation.TYPE_METHOD)
	if track == -1:
		return fail("Missing method track")
	if anim.track_get_key_count(track) != 1:
		return fail("Method track should have 1 key")
	var time := anim.track_get_key_time(track, 0)
	if not is_equal_approx(time, time_value):
		return fail("Method key time mismatch")
	var data: Dictionary = anim.track_get_key_value(track, 0)
	if data.method != method_name:
		return fail("Method key mismatch")
	return true

func check_hurt(anim_player: AnimationPlayer) -> bool:
	var anim: Animation = anim_player.get_animation("hurt")
	if anim == null:
		return fail("Missing hurt animation")
	if not is_equal_approx(anim.length, 0.3):
		return fail("Hurt length must be 0.3")
	if not is_equal_approx(anim.step, 0.1):
		return fail("Hurt step must be 0.1")
	if not assert_value_track(anim, NodePath("CharacterSprite:frame"), [0.0, 0.1, 0.2], [70, 71, 72]):
		return false
	if not assert_value_track(anim, NodePath("KnifeSprite:frame"), [0.0, 0.1, 0.2], [70, 71, 72]):
		return false
	if not assert_method_track(anim, "on_action_complete", 0.3):
		return false
	return true

func check_single_frame(anim_player: AnimationPlayer, name: String, frame: int) -> bool:
	var anim: Animation = anim_player.get_animation(name)
	if anim == null:
		return fail("Missing " + name + " animation")
	if not is_equal_approx(anim.length, 0.1):
		return fail(name + " length must be 0.1")
	if anim.loop_mode == Animation.LOOP_NONE:
		return fail(name + " must be looping")
	if not assert_value_track(anim, NodePath("CharacterSprite:frame"), [0.0], [frame]):
		return false
	if not assert_value_track(anim, NodePath("KnifeSprite:frame"), [0.0], [frame]):
		return false
	return true

func run_validation() -> void:
	var main_node := get_node_or_null("Main")
	if main_node == null:
		fail("Main node not found")
		return
	var player := main_node.get_node_or_null("Player")
	if player == null:
		fail("Player node not found")
		return
	var anim_player := player.get_node_or_null("AnimationPlayer")
	if anim_player == null:
		fail("AnimationPlayer not found")
		return
	if not check_hurt(anim_player):
		return
	if not check_single_frame(anim_player, "fall", 80):
		return
	if not check_single_frame(anim_player, "grounded", 82):
		return
	print("VALIDATION_PASSED: Player hurt/fall/grounded animations are configured")
	get_tree().quit(1)
