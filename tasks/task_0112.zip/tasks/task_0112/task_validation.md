# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure 
  - Evidence: `uv run gamedevbench validate task_0112` -> FAILED "Background TileMapLayer missing".
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: `uv run gamedevbench --gt validate task_0112` -> PASSED "Task completed successfully".
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: `tasks/task_0112/scenes/main.tscn`, `tasks/task_0112/scenes/test.tscn`.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction: "Create a TileSet resource at scenes/arena/tileset.tres using assets/sprites/tiles.png as a TileSetAtlasSource with a 32x32 tile size."
    - Transcript: "change the tile size ... 32 by 32 ... drag and drop ... tiles.png ... automatically create the tiles ... save this tile set".
  - Instruction: "add three TileMapLayer nodes named Background, Props, and Walls under a Node2D named Visuals."
    - Transcript: "rename ... visuals ... add a new child node ... tile map layer ... rename this to background ... duplicate ... rename ... props ... duplicate ... walls".
  - Instruction: "assign the TileSet to each layer."
    - Transcript: "save this tile set ... easier to reuse ... for the background ... duplicate this node ... props ... walls".
  - Instruction: "Paint the Background as a fully filled rectangle of tiles that covers the arena."
    - Transcript: "drag ... over the whole screen to make sure that it covers the whole resolution".
  - Instruction: "Paint Props with at least one tile scattered inside the Background rectangle (not fully filled)."
    - Transcript: "place random tile ... scatter around the props ... a couple props scattered throughout the whole arena".
  - Instruction: "Paint Walls only along the border of the Background rectangle so there is at least one wall tile on each side."
    - Transcript: "start painting the walls ... around the arena ... paint the sides ... top and bottom".
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: tutorial repo `repo/scenes/arena/tileset.tres` matches `tasks_gt/task_0112/scenes/arena/tileset.tres`; tutorial repo `repo/scenes/arena/arena.tscn` Background/Props/Walls `tile_map_data` matches `tasks_gt/task_0112/scenes/main.tscn`.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: instruction defines tile set source, tile size, node names/types, and explicit layout constraints without referencing the tutorial.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (node presence/types/paths), Instruction: add Visuals Node2D and Background/Props/Walls TileMapLayer + assign TileSet at `scenes/arena/tileset.tres` using `assets/sprites/tiles.png` with 32x32 size.
  - Test 2 (background filled rectangle), Instruction: "Paint the Background as a fully filled rectangle of tiles that covers the arena."
  - Test 3 (props scattered inside), Instruction: "Paint Props with at least one tile scattered inside the Background rectangle (not fully filled)."
  - Test 4 (walls on border), Instruction: "Paint Walls only along the border of the Background rectangle so there is at least one wall tile on each side."
  - Missing Coverage: None.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1, Assertions: Main has child `Visuals` Node2D; `Background`, `Props`, `Walls` exist and are `TileMapLayer`; each has TileSet with resource_path ending `scenes/arena/tileset.tres`; `tile_set.tile_size == Vector2i(32, 32)`; TileSet source 0 is `TileSetAtlasSource`; atlas texture path ends with `assets/sprites/tiles.png`. Instruction coverage: explicitly names Visuals/Background/Props/Walls, tile set path, tile size, and tiles.png atlas source.
  - Test 2, Assertions: Background used cells form a filled rectangle (area equals used cells count). Instruction coverage: "fully filled rectangle of tiles that covers the arena."
  - Test 3, Assertions: Props has at least one tile, fewer than background tiles, all inside Background rectangle. Instruction coverage: "at least one tile scattered inside the Background rectangle (not fully filled)."
  - Test 4, Assertions: Walls tiles are only on border and there is at least one wall tile on each side. Instruction coverage: "Paint Walls only along the border ... at least one wall tile on each side."
  - **CRITICAL AMBIGUITY CHECKS**
    - [x] String formatting (not applicable)
    - [x] Exact string values/names are in instruction (Visuals/Background/Props/Walls, tileset path, tiles.png)
    - [x] Number formats (not applicable)
    - [x] Any comparison operators have clear criteria (filled rectangle, inside border, at least one)
    - [x] Node names, paths, and types match instruction exactly
    - [x] Property values (tile size 32x32, tile set path, tiles.png atlas)
  - Ambiguous Tests: None.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: tests allow any filled background rectangle, any scattered props inside, and any border walls layout that frames the area.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: `tasks/task_0112/scenes/main.tscn`, `tasks/task_0112/scenes/test.tscn`, `scripts/test.gd`, `task_config.json`.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused. 
  - Evidence: instruction requires creating TileSet resource and adding TileMapLayer nodes under Visuals in `scenes/main.tscn`.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: instructions are fully specified in text and do not require matching a visual layout.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: no image or screenshot provided in the task instruction.

# Notes
- Updated tests now validate layout constraints (filled background rectangle, scattered props inside, border walls) instead of exact byte arrays.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
