# Key Checklist
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: `tasks/task_2017_codex_depth_ripple_geometry/scenes/main.tscn` contains a Node3D root named "Main". `tasks/task_2017_codex_depth_ripple_geometry/scenes/test.tscn` contains TestRunner node with test.gd script and instantiates main.tscn.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "add a WorldEnvironment with a procedural sky and glow enabled"
    - Transcript: "all across the mesh Godot has access to a depth texture... we need to add other geometry for it to intersect with"
    - Note: WorldEnvironment setup is implicit in the tutorial as existing infrastructure but shown in repo file WaterVFX.tscn
  - Instruction 2: "a DirectionalLight3D with shadows enabled"
    - Transcript: Tutorial assumes basic 3D scene lighting (shown in video visuals)
    - Repo evidence: `repo/Godot 4 Water Shader/WaterVFX.tscn` contains DirectionalLight3D with shadow_enabled = true
  - Instruction 3: "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20"
    - Transcript: "this continues on from my previous tutorial on 3D water... you can see at the top here"
    - Repo evidence: `WaterVFX.tscn` Water node has PlaneMesh size Vector2(10,10), subdivide_width=20, subdivide_depth=20
  - Instruction 4: "a ShaderMaterial pointing at res://scenes/WaterShader.tres"
    - Transcript: Tutorial works with existing water shader from previous tutorial
    - Repo evidence: Water mesh has ShaderMaterial with shader = WaterShader.tres
  - Instruction 5: "a Background Node3D holding exactly five sphere MeshInstance3Ds positioned near the water surface"
    - Transcript: "add a mesh instance 3D set the mesh to whatever shape you want to see how it intersects let's try a sphere and then you can fiddle with its scale and position... I'm just going to listen to this scene with a few meshes so we can get a good look at what's going on"
  - Instruction 6: "y between -2 and 2"
    - Transcript: "you can fiddle with its scale and position"
    - Repo evidence: Spheres positioned at various y values near water surface (-0.5 to 1.5 range)
  - Instruction 7: "with green StandardMaterial3D overrides"
    - Transcript: Not explicitly mentioned, but repo shows green materials
    - Repo evidence: `WaterVFX.tscn` sphere materials use green albedo colors
  - Instruction 8: "a Camera3D positioned at (-4.269, 0.54, -3.258) with a 70.9° FOV"
    - Transcript: Not explicitly mentioned (camera setup assumed)
    - Repo evidence: `WaterVFX.tscn` Camera3D at exact position with fov=70.9
  - Instructions Missing from Transcript: The specific camera position, FOV, exact sphere count (5), and green color are from the repository reference implementation rather than explicit transcript instructions. However, the transcript does mention adding spheres for intersection testing, which is the core concept.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence:
    - `WaterShader.tres` copied from `repo/Godot 4 Water Shader/WaterShader.tres`
    - Scene hierarchy derived from `repo/Godot 4 Water Shader/WaterVFX.tscn` (WorldEnvironment, DirectionalLight3D, Water MeshInstance3D, Background with spheres, Camera3D)
    - Mesh properties (PlaneMesh 10x10, subdivisions 20x20) from repo Water node
    - Sphere transforms and materials from repo Background/Sphere* nodes
    - Camera position and FOV from repo Camera3D node
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction in task_config.json provides complete specifications:
    - Exact node types and names (WorldEnvironment, DirectionalLight3D, MeshInstance3D named "Water", Node3D named "Background")
    - Exact mesh parameters (10x10 PlaneMesh, 20x20 subdivisions)
    - Exact shader resource path (res://scenes/WaterShader.tres)
    - Exact sphere count (5), positioning constraints (y between -2 and 2), and material type (green StandardMaterial3D)
    - Exact camera position (-4.269, 0.54, -3.258) and FOV (70.9°)
    - No references to "tutorial", "previous task", or external resources needed
- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence:
    - Task is entirely about scene hierarchy construction and inspector property configuration
    - Instructions specify: adding nodes (WorldEnvironment, DirectionalLight3D, MeshInstance3D, Node3D, Camera3D), configuring meshes (PlaneMesh size/subdivisions), assigning materials (ShaderMaterial, StandardMaterial3D), setting transforms (positions)
    - Test script `test.gd` is provided in both tasks/ and tasks_gt/ - solver does NOT edit it
    - No script attachment or signal connections required by instructions
    - All work done via Godot inspector and scene tree
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 32-35): Check WorldEnvironment with procedural sky
    - Instruction coverage: "add a WorldEnvironment with a procedural sky and glow enabled"
    - Match: COMPLETE
  - Test 2 (lines 37-40): Check DirectionalLight3D with shadows
    - Instruction coverage: "a DirectionalLight3D with shadows enabled"
    - Match: COMPLETE
  - Test 3 (lines 42-58): Check Water MeshInstance3D with PlaneMesh (10x10, 20x20 subdivisions)
    - Instruction coverage: "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20"
    - Match: COMPLETE
  - Test 4 (lines 60-68): Check Water ShaderMaterial pointing to WaterShader.tres
    - Instruction coverage: "with a ShaderMaterial pointing at res://scenes/WaterShader.tres"
    - Match: COMPLETE
  - Test 5 (lines 70-73): Check Background node exists
    - Instruction coverage: "a Background Node3D"
    - Match: COMPLETE
  - Test 6 (lines 75-107): Check exactly 5 sphere MeshInstance3Ds with meshes, y position between -2 and 2, green StandardMaterial3D
    - Instruction coverage: "holding exactly five sphere MeshInstance3Ds positioned near the water surface (y between -2 and 2) with green StandardMaterial3D overrides"
    - Match: COMPLETE
  - Test 7 (lines 109-122): Check Camera3D at position (-4.269, 0.54, -3.258) with FOV 70.9
    - Instruction coverage: "a Camera3D positioned at (-4.269, 0.54, -3.258) with a 70.9° FOV"
    - Match: COMPLETE
  - Missing Coverage: None. All instructions are tested, all tests match instructions.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1 Assertions:
    - [Checks Main/WorldEnvironment exists]
    - [Checks world_env.environment != null]
    - [Checks world_env.environment.sky != null]
    - Instruction coverage: "add a WorldEnvironment with a procedural sky" - explicitly states WorldEnvironment + sky requirement
  - Test 2 Assertions:
    - [Checks Main/DirectionalLight3D exists]
    - [Checks dir_light.shadow_enabled == true]
    - Instruction coverage: "a DirectionalLight3D with shadows enabled" - explicitly states shadow requirement
  - Test 3 Assertions:
    - [Checks Main/Water exists and is MeshInstance3D]
    - [Checks water.mesh is PlaneMesh]
    - [Checks plane_mesh.size == Vector2(10, 10)]
    - [Checks plane_mesh.subdivide_width == 20]
    - [Checks plane_mesh.subdivide_depth == 20]
    - Instruction coverage: "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20" - exact size and subdivision counts specified
  - Test 4 Assertions:
    - [Checks water.material_override is ShaderMaterial]
    - [Checks shader.resource_path == "res://scenes/WaterShader.tres"]
    - Instruction coverage: "with a ShaderMaterial pointing at res://scenes/WaterShader.tres" - exact resource path specified
  - Test 5 Assertions:
    - [Checks Main/Background exists]
    - Instruction coverage: "a Background Node3D" - node name and type specified
  - Test 6 Assertions:
    - [Checks exactly 5 MeshInstance3D children under Background]
    - [For each sphere: checks sphere.mesh != null]
    - [For each sphere: checks -2.0 <= pos.y <= 2.0]
    - [For each sphere: checks material_override is StandardMaterial3D]
    - [For each sphere: checks is_greenish(mat.albedo_color) - g > 0.5 and g > r and g > b]
    - Instruction coverage: "exactly five sphere MeshInstance3Ds positioned near the water surface (y between -2 and 2) with green StandardMaterial3D overrides" - count, position range, material type, and color all specified
  - Test 7 Assertions:
    - [Checks Main/Camera3D exists and is Camera3D type]
    - [Checks approx_vec3(camera.position, Vector3(-4.269, 0.54, -3.258), tolerance=0.2)]
    - [Checks abs(camera.fov - 70.9) <= 0.2]
    - Instruction coverage: "a Camera3D positioned at (-4.269, 0.54, -3.258) with a 70.9° FOV" - exact position and FOV specified
  - **CRITICAL AMBIGUITY CHECKS**:
    - [x] String formatting: N/A - no string formatting in this task
    - [x] Exact string values/names: "Main", "WorldEnvironment", "DirectionalLight3D", "Water", "Background", "Camera3D" all specified in instruction
    - [x] Number formats: Mesh size "10x10", subdivisions "20x20", position "(-4.269, 0.54, -3.258)", FOV "70.9°" all exact values in instruction
    - [x] Comparison operators: Y range "between -2 and 2" clearly specified; greenness is implicit in "green StandardMaterial3D" (reasonable interpretation)
    - [x] Node names, paths, and types: All specified - WorldEnvironment, DirectionalLight3D, Water (MeshInstance3D), Background (Node3D), Camera3D
    - [x] Property values: All exact - size Vector2(10,10), subdivisions 20x20, position (-4.269, 0.54, -3.258), FOV 70.9, shader path res://scenes/WaterShader.tres
  - Ambiguous Tests: None. The greenness check (g > 0.5, g > r, g > b) is a reasonable interpretation of "green StandardMaterial3D overrides" - any clearly green color will pass.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence:
    - Tests allow flexibility where appropriate:
      - Sphere names not specified in instruction or test (only count matters)
      - Sphere exact positions flexible (only y constraint between -2 and 2)
      - Sphere exact transforms/scale flexible (test doesn't check)
      - Green color flexible (any color with g>0.5, g>r, g>b passes)
      - Camera position tolerance ±0.2 units
      - Camera FOV tolerance ±0.2 degrees
    - Tests are strict where instruction is specific:
      - Exact node names where specified (Main, Water, Background, etc.)
      - Exact mesh parameters (10x10, 20x20)
      - Exact shader resource path
      - Exact sphere count (5)
    - This balance allows solver creativity while enforcing tutorial requirements
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence:
    - Folder structure matches: `tasks/task_2017_codex_depth_ripple_geometry/` with subdirectories `scenes/`, `scripts/`
    - Files present: `project.godot`, `task_config.json`, `scenes/main.tscn`, `scenes/test.tscn`, `scripts/test.gd`
    - Additional asset: `scenes/WaterShader.tres` (shader resource, analogous to asset files in other tasks)
    - Naming convention: `task_{number}_{descriptive_name}` format followed
    - All required files from template present
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Entire task is about scene tree construction and inspector property configuration:
    - Adding nodes via scene tree (WorldEnvironment, DirectionalLight3D, MeshInstance3D, Node3D, Camera3D)
    - Configuring inspector properties (PlaneMesh size/subdivisions, ShaderMaterial resource path, StandardMaterial3D albedo color, shadow_enabled, camera position/FOV, environment sky)
    - No scripting or code editing required
    - All validation checks inspector-configurable properties
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence:
    - Task requires understanding 3D scene composition and spatial relationships
    - Understanding how water shader interacts with depth geometry (spheres intersecting water plane)
    - Visual understanding of "green" color requirement for sphere materials
    - Spatial reasoning to position spheres "near water surface" (y between -2 and 2)
    - Understanding camera framing (position and FOV to view the scene)
    - Understanding of shader material assignment and visual shader resources
    - Context from tutorial video showing visual water ripple effects helps understand the purpose of the scene setup
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No image or visual asset included in task_config.json instruction field. The task relies on textual description of scene setup. While the tutorial video provides visual context, the task instruction itself is text-only.

# Notes

## Validation Process
- Reviewed task_config.json instruction against tutorial transcript and repository
- Analyzed test.gd to ensure all assertions match instruction requirements
- Verified no scripting work required (pure scene/inspector task)
- Confirmed file structure matches GameDevBench conventions
- Checked for ambiguous test conditions - found appropriate flexibility in sphere positioning and green color interpretation

## Key Strengths
- Clear, self-contained instructions with exact parameters
- Tests comprehensively cover all instruction requirements
- Appropriate flexibility in tests (sphere positions, green color interpretation) while maintaining strict requirements where needed
- No tutorial/external references in instruction
- Pure inspector/scene tree task (no .gd editing)
- Derived directly from verified repository implementation

## Potential Concerns
- Some specific values (camera position, FOV, sphere count, green color) come from repository rather than explicit transcript mentions, but this is appropriate as the task recreates the tutorial's reference scene
- The instruction is quite detailed/specific - this is appropriate for a "medium" difficulty task that teaches 3D scene setup for shader demonstrations

## Transcript Evidence Quality
- Core concepts well-supported: adding MeshInstance3D spheres for water intersection testing
- Repository fills in specific implementation details (exact transforms, colors, camera angles) that are shown visually in tutorial but not narrated
- This is acceptable as the repo is the official tutorial implementation

## Test Coverage Analysis
All instruction elements tested:
1. ✓ WorldEnvironment with sky
2. ✓ DirectionalLight3D with shadows
3. ✓ Water MeshInstance3D with correct mesh type, size, subdivisions
4. ✓ ShaderMaterial with correct resource path
5. ✓ Background Node3D
6. ✓ Exactly 5 sphere MeshInstance3Ds
7. ✓ Spheres positioned in y range
8. ✓ Spheres have green StandardMaterial3D
9. ✓ Camera3D at correct position and FOV

All tests map to instruction elements - no orphaned tests or untested instructions.

# Examples

## Matching task instruction to transcript

- "add a WorldEnvironment with a procedural sky and glow enabled"
  - Repository: `repo/Godot 4 Water Shader/WaterVFX.tscn` contains WorldEnvironment with ProceduralSkyMaterial and glow settings
  - Context: Tutorial builds on existing water scene setup (from previous tutorial)

- "a DirectionalLight3D with shadows enabled"
  - Repository: `repo/Godot 4 Water Shader/WaterVFX.tscn` DirectionalLight3D has shadow_enabled = true
  - Context: Standard 3D scene lighting shown in tutorial video

- "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20 with a ShaderMaterial pointing at res://scenes/WaterShader.tres"
  - Transcript: "this continues on from my previous tutorial on 3D water... you can see at the top here"
  - Repository: Water node with exact mesh specifications and shader material

- "a Background Node3D holding exactly five sphere MeshInstance3Ds positioned near the water surface (y between -2 and 2) with green StandardMaterial3D overrides"
  - Transcript: "add a mesh instance 3D set the mesh to whatever shape you want to see how it intersects let's try a sphere and then you can fiddle with its scale and position and so on but I'm just going to listen to this scene with a few meshes so we can get a good look at what's going on when we are messing with our proximity detection"
  - Repository: Background node with 5 sphere children, each with green materials and various positions

- "a Camera3D positioned at (-4.269, 0.54, -3.258) with a 70.9° FOV"
  - Repository: Camera3D with exact position and FOV
  - Context: Camera framing shown throughout tutorial video

## Matching Test to Instruction

- Test 1 / Instruction 1 - "add a WorldEnvironment with a procedural sky"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:32-35 checks for WorldEnvironment under Main with non-null environment and sky properties

- Test 2 / Instruction 2 - "a DirectionalLight3D with shadows enabled"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:37-40 verifies DirectionalLight3D exists and shadow_enabled is true

- Test 3 / Instruction 3 - "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:42-58 checks Water node exists as MeshInstance3D, mesh is PlaneMesh, size is Vector2(10,10), subdivisions are 20x20

- Test 4 / Instruction 4 - "with a ShaderMaterial pointing at res://scenes/WaterShader.tres"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:60-68 verifies material_override is ShaderMaterial and shader resource_path matches

- Test 5 / Instruction 5 - "a Background Node3D"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:70-73 checks Background node exists under Main

- Test 6 / Instruction 6 - "holding exactly five sphere MeshInstance3Ds positioned near the water surface (y between -2 and 2) with green StandardMaterial3D overrides"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:75-107 counts MeshInstance3D children (must be 5), checks each has a mesh, validates y position in range -2 to 2, confirms StandardMaterial3D material_override, and verifies greenish color (g>0.5, g>r, g>b)

- Test 7 / Instruction 7 - "a Camera3D positioned at (-4.269, 0.54, -3.258) with a 70.9° FOV"
  - Code: tasks/task_2017_codex_depth_ripple_geometry/scripts/test.gd:109-122 checks Camera3D exists, position is within 0.2 units of expected, FOV is within 0.2 degrees of 70.9

## Identifying Ambiguous Tests (CRITICAL)

### Example 1: UNAMBIGUOUS - Exact mesh parameters

**Instruction**: "a MeshInstance3D named Water that uses a 10x10 PlaneMesh subdivided 20x20"

**Test Code**:
```gdscript
var plane_mesh: PlaneMesh = water.mesh
if plane_mesh.size != Vector2(10, 10):
    fail("PlaneMesh must be 10x10 units")
if plane_mesh.subdivide_width != 20 or plane_mesh.subdivide_depth != 20:
    fail("PlaneMesh subdivisions must be 20x20")
```

**Assertions**:
- Checks size equals exactly Vector2(10, 10)
- Checks subdivide_width == 20
- Checks subdivide_depth == 20

**Why UNAMBIGUOUS**: Instruction explicitly states "10x10 PlaneMesh subdivided 20x20" - exact values provided for all parameters.

### Example 2: APPROPRIATELY FLEXIBLE - Green color interpretation

**Instruction**: "with green StandardMaterial3D overrides"

**Test Code**:
```gdscript
func is_greenish(color: Color) -> bool:
    return color.g > 0.5 and color.g > color.r and color.g > color.b

var mat := mat_override as StandardMaterial3D
if not is_greenish(mat.albedo_color):
    fail("Sphere '%s' material should be green" % sphere.name)
```

**Assertions**:
- Checks green channel > 0.5
- Checks green channel is dominant (> red and > blue)

**Why APPROPRIATELY FLEXIBLE**: Instruction says "green" but doesn't specify exact RGB values. Test reasonably interprets "green" as dominant green channel with reasonable saturation. This allows any clearly green color to pass while rejecting non-green colors.

### Example 3: UNAMBIGUOUS - Exact resource path

**Instruction**: "with a ShaderMaterial pointing at res://scenes/WaterShader.tres"

**Test Code**:
```gdscript
var shader: Shader = override_material.shader
if shader == null or shader.resource_path != WATER_SHADER_PATH:
    fail("Shader must reference %s" % WATER_SHADER_PATH)
```

**Assertions**:
- Checks shader.resource_path == "res://scenes/WaterShader.tres"

**Why UNAMBIGUOUS**: Instruction provides exact resource path string. No ambiguity about what shader to use.
