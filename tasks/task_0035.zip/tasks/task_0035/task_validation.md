# Key Checklist
- [X] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: The starting point has an empty _draw() function (tasks/task_0035/scripts/steer_component.gd:38-39), which will fail the test checks for required draw_line and draw_circle patterns (test.gd:34-43).
- [X] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: The ground truth implements all required draw commands (tasks_gt/task_0035/scripts/steer_component.gd:44-48) that match the test patterns exactly.
- [X] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Both files exist in tasks/task_0035/scenes/ directory (main.tscn and test.tscn).
- [ ] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - SKIPPED: Tutorial transcript file not found at expected location. The task_config.json references "scripts/youtube_data_codex_2/Cashew OldDew/Debug Visually in Godot 4.2" but this folder does not exist in the repository. The video_id is "0MfTANzADHw" and github_repo is "https://github.com/cashew-olddew/godot-tutorials". Without access to the transcript, cannot verify this requirement.
- [ ] The task code is directly derived from the repository code. Please document where the derived code is.
  - SKIPPED: Cannot verify without access to the GitHub repository code locally. The referenced repository is https://github.com/cashew-olddew/godot-tutorials but the tutorial folder does not exist in the local scripts directory.
- [X] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction "Use the SteerComponent's _draw function to render the velocity vector in black, the desired velocity in red, a blue connector between them, and circles at both tips so the steering forces are visible during play." is self-contained and clear. It specifies the exact function (_draw), the exact components to render (velocity vector, desired velocity, connector, circles), and their exact colors (black, red, blue).
- [X] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1: Checks for debug["velocity"] entry - Instruction mentions "velocity vector"
  - Test 2: Checks for debug["scaled_desired_velocity"] entry - Instruction mentions "desired velocity"
  - Test 3: Checks for draw_line(position, debug["velocity"], Color.BLACK) - Instruction: "render the velocity vector in black"
  - Test 4: Checks for draw_line(position, debug["scaled_desired_velocity"], Color.RED) - Instruction: "desired velocity in red"
  - Test 5: Checks for draw_line(debug["velocity"], debug["scaled_desired_velocity"], Color.BLUE) - Instruction: "blue connector between them"
  - Test 6: Checks for draw_circle(debug["velocity"], 6.0, Color.BLACK) - Instruction: "circles at both tips" (velocity tip)
  - Test 7: Checks for draw_circle(debug["scaled_desired_velocity"], 6.0, Color.RED) - Instruction: "circles at both tips" (desired velocity tip)
  - Missing Coverage: None. All instruction elements are tested.
- [ ] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - **AMBIGUOUS**: The instruction does NOT specify:
    - Circle radius (test requires exactly 6.0)
    - Line width (test patterns don't check this, but ground truth uses 4.0)
    - Starting position for lines (test requires "position" but instruction doesn't specify this)
    - Exact dictionary key names (test requires debug["velocity"] and debug["scaled_desired_velocity"] but instruction just says "velocity vector" and "desired velocity")
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [ ] String formatting (padding, delimiters, exact format) is specified in instruction - N/A (no strings)
    - [ ] Exact string values/names are in instruction (not just "format text") - N/A
    - [ ] Number formats (zero-padding, decimal places) are specified - FAIL: Circle radius 6.0 not specified
    - [ ] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - PASS: Pattern matching is used
    - [ ] Node names, paths, and types match instruction exactly - PASS: SteerComponent is specified
    - [X] Property values (numbers, booleans, strings) have exact values in instruction - FAIL: Circle radius and line starting positions not specified
  - Ambiguous Tests:
    - Circle radius is tested to be exactly 6.0 but instruction doesn't specify radius
    - Line starting position "position" is not explained in instruction (what is "position"?)
    - Dictionary key names are tested exactly but instruction uses descriptive terms instead
- [X] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: While there are some ambiguities (circle radius, exact position), the tests allow for flexibility in implementation details like line width. The core requirement (draw specific vectors with specific colors and circles at tips) is unambiguous enough that there's essentially one reasonable solution.
- [X] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Task follows naming convention task_####_codex_name_description. Contains standard folders: assets/, scenes/, scripts/, and standard files: project.godot, task_config.json.
- [ ] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [X] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The task requires working with the SteerComponent node and understanding its structure, including the debug dictionary and _draw function. However, most work is code-based rather than inspector-based.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: No multimodal reasoning required. This is purely a code-based task working with GDScript draw commands.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or multimodal inputs in the instruction.

# Notes

## Validation Summary
Date: 2025-11-18
Validator: Claude (automated)

### Key Findings:
1. **Missing Tutorial Files**: The tutorial folder referenced in task_config.json does not exist in the repository. Expected at "scripts/youtube_data_codex_2/Cashew OldDew/Debug Visually in Godot 4.2" but not found.

2. **Ambiguities in Instruction**:
   - Circle radius not specified (test expects 6.0)
   - Line starting position terminology ("position") not explained
   - Dictionary key names not explicitly stated in instruction

3. **Task Structure**: Otherwise well-formed with proper scenes (main.tscn, test.tscn), clear instruction, and functional tests.

4. **Recommendation**:
   - DO NOT PROCEED - Missing tutorial transcript and GitHub repository code makes it impossible to verify that the task accurately represents the tutorial content.
   - The instruction should be updated to specify exact circle radius and clarify "position" terminology.
   - Tutorial folder needs to be created or task_config.json needs to be updated with correct path.

### Test Validation:
- Starting point: Has empty _draw() function, should fail tests ✓
- Ground truth: Implements all required draw commands ✓
- Tests check for specific patterns in code ✓

### Files Checked:
- tasks/task_0035/scripts/test.gd
- tasks/task_0035/scripts/steer_component.gd
- tasks_gt/task_0035/scripts/steer_component.gd
- tasks/task_0035/task_config.json
- tasks/task_0035/scenes/ (main.tscn, test.tscn verified)

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
