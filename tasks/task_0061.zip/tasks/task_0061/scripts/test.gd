extends Node

func _ready():
	run_validation()

func run_validation():
	var main = get_node_or_null("Main")
	if not main:
		print("VALIDATION_FAILED: Main scene not instanced")
		get_tree().quit(1)
		return
	await get_tree().process_frame

	var player = main.get_node_or_null("FPSPlayer")
	if not player:
		print("VALIDATION_FAILED: FPSPlayer not found in Main")
		get_tree().quit(1)
		return

	var canvas_layer = player.get_node_or_null("CanvasLayer")
	if not canvas_layer:
		print("VALIDATION_FAILED: CanvasLayer missing on FPSPlayer")
		get_tree().quit(1)
		return
	if not canvas_layer is CanvasLayer:
		print("VALIDATION_FAILED: CanvasLayer node is wrong type")
		get_tree().quit(1)
		return

	var label = canvas_layer.get_node_or_null("Label")
	if not label:
		print("VALIDATION_FAILED: Label missing under CanvasLayer")
		get_tree().quit(1)
		return
	if not label is Label:
		print("VALIDATION_FAILED: Label node is wrong type")
		get_tree().quit(1)
		return

	if not is_equal_approx(label.offset_left, 10.0) or not is_equal_approx(label.offset_top, 15.0) \
	or not is_equal_approx(label.offset_right, 50.0) or not is_equal_approx(label.offset_bottom, 41.0):
		print("VALIDATION_FAILED: Label offsets not set to 10,15,50,41")
		get_tree().quit(1)
		return

	if label.get_theme_font_size("font_size") != 16:
		print("VALIDATION_FAILED: Label font size is not 16")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: CanvasLayer and Label configured correctly")
	get_tree().quit(0)
