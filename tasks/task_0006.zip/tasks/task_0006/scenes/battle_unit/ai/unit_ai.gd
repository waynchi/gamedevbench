class_name UnitAI
extends Node

@export var debug_label: Label
@export var enabled: bool:
    set(value):
        enabled = value
        if debug_label:
            debug_label.visible = value
@export var actor: Node

func _ready() -> void:
    if debug_label and debug_label.text == "":
        debug_label.text = "IDLE"
    if debug_label:
        debug_label.visible = enabled
