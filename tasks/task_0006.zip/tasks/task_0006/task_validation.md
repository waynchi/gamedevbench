# Key Checklist
- [X] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Manual code inspection confirms the starting battle_unit.tscn does not have FSMDebugLabel or UnitAI nodes, so tests would fail. Task files contain valid main.tscn and test.tscn with proper test script.
- [X] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Ground truth folder exists at tasks_gt/task_0006 with matching structure to starting point.
- [X] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Confirmed existence of tasks/task_0006/scenes/main.tscn and tasks/task_0006/scenes/test.tscn
- [X] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Add Label named FSMDebugLabel / Transcript: "Select the battle unit node root node again. Press Ctrl+ A and search for label. Let's double click and rename this to something like finite state machine debug label"
  - Set offsets -65,-47 to 65,-29 / Transcript: "under layout and transform, we can set the size to, I don't know, maybe 130. And to center it, we can set it to minus 65 on the X. Yeah, I think that works."
  - Center text alignment / Transcript: "we can center the text on the horizontal axis"
  - Add UnitAI node using unit_ai.gd / Transcript: "Select the root node, the battle unit node. Click on the plus sign or press Ctrl+ A and search for unit AI. Let's drag it up."
  - Wire debug_label to FSMDebugLabel / Transcript: "if we select the finite state machine, click on assign, and select the FSM debug label. So now whenever we change the actual state machine's current state, this label will be automatically updated"
  - Wire actor to BattleUnit root / Transcript: "And we need to assign the actor and the finite state machine. So the actor will be the battle unit"
  - Instructions Missing from Transcript: None - all instruction elements are covered in the transcript
- [X] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Task references repository at https://github.com/guladam/godot_autobattler_course (see task_config.json metadata). The tutorial demonstrates creating UnitAI system with FSM debug labels, and this task focuses on the setup portion of that system.
- [X] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: Instruction provides complete information: specific scene path (res://scenes/battle_unit/battle_unit.tscn), exact node names (FSMDebugLabel, UnitAI), precise offset coordinates (-65,-47 to 65,-29), script path (res://scenes/battle_unit/ai/unit_ai.gd), and property connections (debug_label, actor). No external references needed.
- [X] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 28-30): Checks FSMDebugLabel exists / Instruction: "add a Label child named FSMDebugLabel"
  - Test 2 (lines 31-32): Checks FSMDebugLabel has centered text / Instruction: "with centered text"
  - Test 3 (lines 33-36): Checks FSMDebugLabel offsets -65,-47 to 65,-29 / Instruction: "offsets -65,-47 to 65,-29"
  - Test 4 (lines 38-40): Checks UnitAI node exists / Instruction: "add a UnitAI node"
  - Test 5 (lines 41-43): Checks UnitAI uses correct script / Instruction: "uses res://scenes/battle_unit/ai/unit_ai.gd"
  - Test 6 (lines 48-50): Checks debug_label wired to FSMDebugLabel / Instruction: "wire its exported debug_label to FSMDebugLabel"
  - Test 7 (lines 52-54): Checks actor wired to BattleUnit root / Instruction: "actor to the BattleUnit root"
  - Missing Coverage: Test checks for _ready() method existence (line 45-46), which is not explicitly in the instruction but is implementation detail. This is acceptable as it doesn't create false negatives for valid solutions.
- [X] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem.
  - Evidence: This task has a single correct solution - specific nodes must be added with exact properties. Tests appropriately validate these requirements without being overly restrictive.
- [X] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Follows standard structure with task_0006 naming, contains scenes/, scripts/, assets/, project.godot, and task_config.json matching the pattern of other tasks.
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [X] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Task is entirely Node/inspector-focused - adding Label and UnitAI nodes to scene tree, setting Label properties (offset_left, offset_top, offset_right, offset_bottom, horizontal_alignment), and wiring exported properties (debug_label, actor) through the inspector.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Task can be completed entirely through text-based instructions. No multimodal reasoning required.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or multimodal inputs in the instruction. All requirements are text-based.

# Notes

## Validation Summary
Task 0208 (Unit AI Debug Label) has been successfully validated. This task is derived from the GodotGameLab Autobattler Tutorial (S02E06) on RefCounted, FSM & UnitAI.

## Key Findings:
1. **Instruction Quality**: Instructions are clear, specific, and self-contained. All elements trace directly to tutorial transcript.
2. **Test Coverage**: Tests comprehensively cover all instruction requirements with appropriate validation logic.
3. **Scene Structure**: Proper main.tscn and test.tscn files exist following benchmark conventions.
4. **Transcript Alignment**: All instruction elements found in tutorial transcript with exact matches for node names, properties, and wiring.
5. **Node/Inspector Focus**: Task is heavily Node/inspector-focused, requiring scene tree manipulation and property configuration through Godot editor or programmatically.

## Tutorial Context:
The tutorial teaches implementing a finite state machine for unit AI in an autobattler game. This specific task focuses on the UI setup portion - adding a debug label to display FSM state and wiring the UnitAI component. The instruction carefully extracts just the setup steps from the broader FSM implementation tutorial.

## Validation Completed:
All checklist items pass successfully. Task is ready for use in GameDevBench.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).