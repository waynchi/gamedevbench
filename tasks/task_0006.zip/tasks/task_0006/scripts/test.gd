extends Node

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func succeed(message: String) -> void:
    print("VALIDATION_PASSED: %s" % message)
    get_tree().quit(0)

func ensure(condition: bool, message: String) -> bool:
    if not condition:
        fail(message)
        return true
    return false

func run_validation() -> void:
    var main: Node = get_node_or_null("Main")
    if ensure(main != null, "Main scene must be instanced in test.tscn"):
        return
    var unit: Node = main.get_node_or_null("BattleUnit")
    if ensure(unit != null, "Main must contain a BattleUnit child"):
        return

    var label: Label = unit.get_node_or_null("FSMDebugLabel")
    if ensure(label != null, "BattleUnit must include an FSMDebugLabel child"):
        return
    if ensure(label.horizontal_alignment == HORIZONTAL_ALIGNMENT_CENTER, "FSMDebugLabel must center-align text"):
        return
    var expected_rect: Rect2 = Rect2(-65, -47, 130, 18)
    var actual_rect: Rect2 = Rect2(label.offset_left, label.offset_top, label.offset_right - label.offset_left, label.offset_bottom - label.offset_top)
    if ensure(actual_rect == expected_rect, "FSMDebugLabel must span offsets -65,-47 to 65,-29"):
        return

    var unit_ai: Node = unit.get_node_or_null("UnitAI")
    if ensure(unit_ai != null, "BattleUnit must include a UnitAI node"):
        return
    var script: Script = unit_ai.get_script()
    if ensure(script != null and script.resource_path == "res://scenes/battle_unit/ai/unit_ai.gd", "UnitAI must use the provided unit_ai.gd script"):
        return

    if ensure(unit_ai.has_method("_ready"), "UnitAI script must define _ready()"):
        return

    var debug_label_ref: Label = unit_ai.get("debug_label")
    if ensure(debug_label_ref == label, "UnitAI.debug_label must reference FSMDebugLabel"):
        return

    var actor_ref: Node = unit_ai.get("actor")
    if ensure(actor_ref == unit, "UnitAI.actor must point to the BattleUnit root"):
        return

    succeed("UnitAI debug label wiring matches tutorial requirements")
