# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Ran `uv run gamedevbench validate task_0051` and got `Validation result: FAILED` with message "Sprite2D child missing on Player". The starting point has an incomplete Player.tscn with only the CharacterBody2D and script, missing the Sprite2D and CollisionShape2D children.
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: After running `godot --headless --path . --import` to import assets, then `uv run gamedevbench --gt validate task_0051` outputs `Validation result: PASSED`. The ground truth has complete Player.tscn and player.gd implementation matching all test requirements.
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Verified both files exist:
    - `scenes/Main.tscn`: Contains a Node2D root with Player instance
    - `scenes/test.tscn`: Contains TestRunner node with test.gd script and Main instance as child
    - Both follow the standard structure for GameDevBench tasks
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - "Populate scenes/Player.tscn" / "Start with a CharacterBody2D node, and add a Sprite2D and CollisionShape2D to it" (transcript lines 17-23)
  - "CharacterBody2D named Player with a Sprite2D" / "Start with a CharacterBody2D node, and add a Sprite2D and CollisionShape2D to it" (lines 17-23)
  - "uses assets/sprites/tileYellow_02.png" / Not explicitly in transcript, but texture assignment is standard practice shown in the KidsCanCode tutorials
  - "RectangleShape2D sized 32×68" / "CollisionShape2D" mentioned in line 23, size not specified but matches the ground truth implementation
  - "export speed=1200, jump_speed=-1800, and gravity=4000" / "@export var speed = 1200, @export var jump_speed = -1800, @export var gravity = 4000" (lines 35-37)
  - "increment velocity.y by gravity each _physics_process" / "velocity.y += gravity * delta" (line 42)
  - "set velocity.x from Input.get_axis(\"move_left\", \"move_right\") * speed" / "velocity.x = Input.get_axis(\"walk_left\", \"walk_right\") * speed" (line 45) - NOTE: Instruction uses "move_left"/"move_right" while transcript uses "walk_left"/"walk_right"
  - "call move_and_slide()" / "move_and_slide()" (line 47)
  - "only apply jump_speed when Input.is_action_just_pressed(\"jump\") and is_on_floor()" / "if Input.is_action_just_pressed(\"jump\") and is_on_floor(): velocity.y = jump_speed" (lines 50-51)
  - Instructions Missing from Transcript: The specific texture file path (tileYellow_02.png) and collision shape size (32×68) are not in the transcript. The input action names differ: instruction uses "move_left"/"move_right" while transcript uses "walk_left"/"walk_right".
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The ground truth code in `tasks_gt/task_0051/scripts/player.gd` is derived from the repository at https://github.com/godotrecipes/2d_platform_basic/blob/master/platform_character.gd
  - Repository code uses: `@export var speed/jump_speed`, `gravity * delta`, `Input.get_axis("move_left", "move_right")`, `move_and_slide()`, `Input.is_action_just_pressed("jump") and is_on_floor()`
  - Task ground truth simplifies the repository code by removing lerp-based acceleration/friction (which is in the "Friction and acceleration" section of the transcript) and focusing on the basic implementation from lines 33-71 of the transcript
  - The task uses the core platform movement pattern from the repository but with simpler direct velocity assignment instead of lerp interpolation, matching the "basic" version shown first in the tutorial
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction is a single, comprehensive sentence that specifies all implementation details:
    - File locations: "scenes/Player.tscn and scripts/player.gd"
    - Node structure: "CharacterBody2D named Player with a Sprite2D... and a RectangleShape2D"
    - Asset path: "assets/sprites/tileYellow_02.png"
    - Collision size: "sized 32×68"
    - Export variables with exact values: "speed=1200, jump_speed=-1800, and gravity=4000"
    - Physics implementation: "increment velocity.y by gravity each _physics_process"
    - Input handling: "set velocity.x from Input.get_axis(\"move_left\", \"move_right\") * speed"
    - Movement call: "call move_and_slide()"
    - Jump logic: "only apply jump_speed when Input.is_action_just_pressed(\"jump\") and is_on_floor()"
  - No references to the tutorial or other tasks are present. The instruction is completely self-contained.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 11-14): Check Main scene exists / Instruction: "Main instantiates a CharacterBody2D"
  - Test 2 (lines 16-22): Check Player node exists and is CharacterBody2D / Instruction: "CharacterBody2D named Player"
  - Test 3 (lines 24-27): Check Player script exists / Instruction: "scripts/player.gd"
  - Test 4 (lines 29-38): Check Sprite2D child exists and uses tileYellow_02.png texture / Instruction: "with a Sprite2D that uses assets/sprites/tileYellow_02.png"
  - Test 5 (lines 40-51): Check CollisionShape2D child with RectangleShape2D sized Vector2(32,68) / Instruction: "and a RectangleShape2D sized 32×68"
  - Test 6 (lines 59-67): Check script exports speed, jump_speed, gravity properties / Instruction: "export speed=1200, jump_speed=-1800, and gravity=4000"
  - Test 7 (line 68-70): Check exported defaults are 1200/-1800/4000 / Instruction: "export speed=1200, jump_speed=-1800, and gravity=4000"
  - Test 8 (lines 71-73): Check gravity increments velocity.y each frame / Instruction: "increment velocity.y by gravity each _physics_process"
  - Test 9 (lines 74-78): Check Input.get_axis("move_left", "move_right") is used / Instruction: "set velocity.x from Input.get_axis(\"move_left\", \"move_right\") * speed"
  - Test 10 (lines 79-81): Check move_and_slide() is called / Instruction: "call move_and_slide()"
  - Test 11 (lines 82-87): Check jump logic uses Input.is_action_just_pressed("jump") and is_on_floor() / Instruction: "only apply jump_speed when Input.is_action_just_pressed(\"jump\") and is_on_floor()"
  - Missing Coverage: All instructions are covered by tests. All tests correspond to instructions.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1 (Main exists): Assertions: [main != null], Instruction: "Main instantiates" (implicit that Main scene exists)
  - Test 2 (Player node): Assertions: [player != null, player is CharacterBody2D], Instruction: "CharacterBody2D named Player"
  - Test 3 (Script): Assertions: [script != null], Instruction: "scripts/player.gd" (implicit that script is attached)
  - Test 4 (Sprite2D): Assertions: [sprite != null, sprite.texture != null, texture path contains "tileYellow_02.png"], Instruction: "Sprite2D that uses assets/sprites/tileYellow_02.png"
  - Test 5 (Collision): Assertions: [collider != null, shape is RectangleShape2D, shape.size.is_equal_approx(Vector2(32,68))], Instruction: "RectangleShape2D sized 32×68"
  - Test 6 (Exports exist): Assertions: [script contains "@export var speed", "@export var jump_speed", "@export var gravity"], Instruction: "export speed=1200, jump_speed=-1800, and gravity=4000"
  - Test 7 (Export values): Assertions: [script contains "= 1200", "-1800", "= 4000"], Instruction: "export speed=1200, jump_speed=-1800, and gravity=4000"
  - Test 8 (Gravity): Assertions: [script contains "velocity.y += gravity * delta"], Instruction: "increment velocity.y by gravity each _physics_process" (Note: instruction says "increment" but doesn't explicitly specify "* delta", though this is standard in Godot _physics_process)
  - Test 9 (Input axis): Assertions: [script contains 'Input.get_axis("move_left"' OR 'Input.get_axis(\'move_left\''], Instruction: "Input.get_axis(\"move_left\", \"move_right\") * speed"
  - Test 10 (move_and_slide): Assertions: [script contains "move_and_slide()"], Instruction: "call move_and_slide()"
  - Test 11 (Jump): Assertions: [script contains 'Input.is_action_just_pressed("jump"' OR 'Input.is_action_just_pressed(\'jump\'', script contains "is_on_floor()"], Instruction: "only apply jump_speed when Input.is_action_just_pressed(\"jump\") and is_on_floor()"
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - N/A, no string formatting in this task
    - [x] Exact string values/names are in instruction (not just "format text") - YES: "move_left", "move_right", "jump", "tileYellow_02.png" all specified
    - [x] Number formats (zero-padding, decimal places) are specified - YES: 1200, -1800, 4000, 32, 68 all exact integers
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - Tests use contains/find for code checking which is appropriate for validating code structure
    - [x] Node names, paths, and types match instruction exactly - YES: "Player", "Sprite2D", "CollisionShape2D", "CharacterBody2D", "RectangleShape2D" all specified
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - YES: speed=1200, jump_speed=-1800, gravity=4000, size 32×68
  - Ambiguous Tests: MINOR - Test 8 checks for exact string "velocity.y += gravity * delta" but instruction says "increment velocity.y by gravity each _physics_process" without explicitly mentioning "* delta". However, this is the standard and only way to properly increment with gravity in Godot's _physics_process, so it's unambiguous in practice.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The tests are appropriately flexible where needed:
    - Tests check for string presence using `find()` rather than exact line matching, allowing different code organization
    - Collision shape size uses `is_equal_approx()` for floating point comparison tolerance
    - Tests accept both single quotes and double quotes for string literals (lines 74-87)
    - The instruction is very specific about the implementation approach, so there is essentially one correct solution
    - However, the tests do NOT enforce: exact code ordering, variable naming (only checks for presence in script text), or specific implementation details beyond what's specified
  - The tests strike a good balance: strict on required API calls and values, flexible on code style and organization
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Folder structure matches the standard GameDevBench pattern:
    - Root: `tasks/task_0051/` and `tasks_gt/task_0051/`
    - Subdirectories: `assets/`, `scenes/`, `scripts/`
    - Standard files: `project.godot`, `task_config.json` (starting point only)
    - Scene files: `scenes/Main.tscn`, `scenes/Player.tscn`, `scenes/test.tscn`
    - Script files: `scripts/player.gd`, `scripts/test.gd`
    - The naming follows the pattern: task_{number}_{descriptive_name}
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The task requires setting up a node hierarchy (CharacterBody2D → Sprite2D, CollisionShape2D) and configuring inspector properties (texture, collision shape size, exported variables). Much of the work involves scene tree construction and property assignment in the inspector.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Understanding the relationship between code (player.gd) and scene structure (Player.tscn), visualizing the sprite and collision shape placement, understanding how physics properties affect character behavior. The solver needs to understand both visual/spatial aspects (sprite, collision box) and code logic.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No image input is provided in the instruction. The task relies on text-based specification of the sprite asset path and collision dimensions.

# Notes

## Validation Summary
This task has been validated and passes all key criteria. It is a well-structured GameDevBench task that tests basic platform character implementation in Godot.

## Key Findings

### Strengths
1. **Clear Instruction**: The single-sentence instruction is comprehensive and specifies all necessary implementation details
2. **Comprehensive Testing**: The test.gd file covers all aspects of the instruction with 11 distinct test checks
3. **Good Test Flexibility**: Tests check for required functionality without being overly prescriptive about code style
4. **Proper Validation Flow**: Starting point correctly fails, ground truth correctly passes after asset import
5. **Standard Structure**: Follows GameDevBench conventions for folder structure and file naming

### Minor Issues Identified
1. **Input Action Name Discrepancy**: The instruction uses "move_left"/"move_right" while the transcript uses "walk_left"/"walk_right". However, the project.godot file in the ground truth correctly defines "move_left"/"move_right", so this is consistent with the instruction.

2. **Delta Multiplication Implicit**: The instruction says "increment velocity.y by gravity each _physics_process" but doesn't explicitly mention multiplying by delta. The test checks for "velocity.y += gravity * delta". This is the standard and correct approach in Godot, so it's not truly ambiguous, but could be more explicit.

### Assets Import Note
**IMPORTANT**: When running ground truth validation, assets must be imported first:
```bash
cd tasks_gt/task_0051
godot --headless --path . --import
cd ../..
uv run gamedevbench --gt validate task_0051
```

### Tutorial Alignment
The task accurately reflects the "basic" platform character implementation from the KidsCanCode tutorial, specifically the first implementation (lines 33-71) before the friction/acceleration enhancements. This is appropriate for a "core movement" task.

### Test Coverage
All 11 tests map directly to instruction requirements:
- Scene structure (Main, Player node)
- Node types (CharacterBody2D, Sprite2D, CollisionShape2D)
- Asset assignments (texture, shape)
- Script exports (speed, jump_speed, gravity with values)
- Physics implementation (gravity increment, input axis, move_and_slide)
- Jump logic (action press + floor check)

## Recommendations
✅ TASK IS VALIDATED - All criteria pass. Ready for use in GameDevBench.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
