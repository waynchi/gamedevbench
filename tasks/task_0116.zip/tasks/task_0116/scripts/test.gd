extends Node

var has_failed := false

func _ready() -> void:
	_run_validation()

func _run_validation() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	if scene == null:
		return _fail("Missing res://scenes/main.tscn")
	var main_scene: Node = scene.instantiate()
	add_child(main_scene)
	var rain: GPUParticles2D = main_scene.get_node_or_null("Rain")
	if rain == null:
		return _fail("Main must contain a GPUParticles2D named Rain")
	if not rain is GPUParticles2D:
		return _fail("Rain must be a GPUParticles2D")
	var splash: GPUParticles2D = main_scene.get_node_or_null("Splash")
	if splash == null:
		return _fail("Main must contain a GPUParticles2D named Splash")
	_check_ground_support(main_scene)
	if has_failed:
		return
	_check_rain_setup(rain, splash)
	if has_failed:
		return
	_check_splash_setup(splash)
	if has_failed:
		return
	_pass("Rain particles collide and spawn splash bursts")

func _check_ground_support(main_scene: Node) -> void:
	var occluder: LightOccluder2D = main_scene.get_node_or_null("GroundOccluder")
	if occluder == null:
		return _fail("GroundOccluder node missing")
	var polygon := occluder.occluder
	if polygon == null or polygon.polygon.size() < 4:
		return _fail("GroundOccluder must use an OccluderPolygon2D covering the floor")
	var collision_shape: CollisionShape2D = main_scene.get_node_or_null("GroundCollider/CollisionShape2D")
	if collision_shape == null:
		return _fail("GroundCollider/CollisionShape2D missing")
	var rect_shape := collision_shape.shape
	if rect_shape == null or not rect_shape is RectangleShape2D:
		return _fail("Ground collider must rely on a RectangleShape2D")
	if rect_shape.size.x < 1500 or rect_shape.size.y < 80:
		return _fail("Ground collider should span the screen width (>=1500x80)")

func _check_rain_setup(rain: GPUParticles2D, splash: GPUParticles2D) -> void:
	if not rain.texture:
		return _fail("Rain texture should be set")
	if not rain.texture.resource_path.contains("assets/raindrop.png"):
		return _fail("Rain texture should be set")
	if rain.modulate.a8 == 0 or rain.modulate.a8 == 255:
		return _fail("Rain alpha channel should be semi-transparent")
	if rain.modulate.b < rain.modulate.r or rain.modulate.b < rain.modulate.g:
		return _fail("Rain should have a blue tint")
	if rain.amount < 800:
		return _fail("Rain should emit at least 800 particles")
	if rain.lifetime < 5.0:
		return _fail("Rain lifetime must be at least 5 seconds")
	if rain.preprocess < 10.0:
		return _fail("Rain preprocess should be at least 10 seconds")
	var rect := rain.visibility_rect
	if rect.size.x < 1800 or rect.size.y < 900:
		return _fail("Rain visibility rect must cover 1800x900")
	if abs(rect.position.x + 900) > 0.01 or rect.position.y > -200 + 0.01:
		return _fail("Rain visibility rect should start around (-900,-200)")
	if rain.collision_base_size < 5.0:
		return _fail("Increase Rain collision base size to keep drops above the ground")
	if rain.sub_emitter != NodePath("../Splash"):
		return _fail("Rain sub_emitter must target the Splash node")
	var mat := rain.process_material
	if mat == null or not mat is ParticleProcessMaterial:
		return _fail("Rain requires a ParticleProcessMaterial")
	if mat.emission_shape != ParticleProcessMaterial.EMISSION_SHAPE_BOX:
		return _fail("Rain emission shape should be Box")
	if mat.emission_box_extents.x < 900:
		return _fail("Rain emission box must span roughly 900 pixels to each side")
	if not mat.direction.is_equal_approx(Vector3(0.1, 1.0, 0.0)):
		return _fail("Rain direction should be (0.1, 1, 0) so the wind pushes drops right")
	if mat.initial_velocity_min < 600 or mat.initial_velocity_max < 850:
		return _fail("Rain initial velocity range must start near 600 and reach 850")
	if mat.scale_min > 0.21:
		return _fail("Rain scale minimum should stay near 0.2")
	if mat.collision_mode != 2:
		return _fail("Enable hide-on-contact collision mode for Rain")
	if mat.sub_emitter_mode != 3:
		return _fail("Rain sub emitter mode must trigger on collision")
	if mat.sub_emitter_amount_at_collision != 4:
		return _fail("Rain should spawn four Splash particles per collision")

func _check_splash_setup(splash: GPUParticles2D) -> void:
	if not splash.texture:
		return _fail("Splash texture must be set")
	if not splash.texture.resource_path.contains("assets/raindrop.png"):
		return _fail("Splash texture should be set")
	if splash.modulate.a8 == 0 or splash.modulate.a8 == 255:
		return _fail("Splash alpha channel should be semi-transparent")
	if splash.modulate.b < splash.modulate.r or splash.modulate.b < splash.modulate.g:
		return _fail("Splash should have a blue tint")
	if splash.amount < 6400:
		return _fail("Splash amount should allow thousands of particles for collisions")
	if not is_equal_approx(splash.explosiveness, 1.0):
		return _fail("Splash explosiveness should be 1.0 to fire bursts")
	var mat := splash.process_material
	if mat == null or not mat is ParticleProcessMaterial:
		return _fail("Splash requires its own ParticleProcessMaterial")
	if not mat.particle_flag_align_y:
		return _fail("Splash particles should align with their velocity")
	if mat.initial_velocity_min < 50 or mat.initial_velocity_max < 60:
		return _fail("Splash velocity must be in the 50-60 range")
	if mat.gravity.y < 90:
		return _fail("Splash gravity needs to pull drops back down")
	if mat.scale_min > 0.11 or mat.scale_max > 0.25:
		return _fail("Splash scale should stay between 0.1 and 0.2")

func _fail(message: String) -> void:
	has_failed = true
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func _pass(message: String) -> void:
	print("VALIDATION_PASSED: %s" % message)
	get_tree().quit()
