extends Node

func _ready():
	run_validation()

func run_validation():
	var scene = load("res://scenes/main.tscn").instantiate()
	add_child(scene)
	var qm = _get_qm()
	var issues = []
	var quest_ui = scene.get_node_or_null("QuestUI")
	if quest_ui == null:
		issues.append("QuestUI CanvasLayer missing")
	else:
		if quest_ui.quest_name != "Shoot Em Up":
			issues.append("quest_name should remain 'Shoot Em Up'")
		if quest_ui.quest_resource == null:
			issues.append("quest_resource export is not assigned")
		var quest = qm.get_player_quest(quest_ui.quest_name)
		var quest_missing = quest.is_empty()
		if quest_missing:
			issues.append("QuestManager did not register the quest on ready")
		var do_label: Label = quest_ui.get_node("QuestPanel/VBoxContainer/Do")
		var expected_text = "Destroy 5 ships 00/05"
		if do_label.text != expected_text:
			issues.append("Initial incremental text should be '%s' (got %s)" % [expected_text, do_label.text])
		var timer_step = {
			"step_type": qm.TIMER_STEP,
			"details": "Survive 10 seconds",
			"time": 8
		}
		quest_ui.update_ui(timer_step)
		if not do_label.text.begins_with("Survive 10 seconds") or not do_label.text.ends_with("08"):
			issues.append("Timer formatting must show countdown seconds (expected suffix 08)")
		var required_signals = [
			"step_updated",
			"step_complete",
			"quest_completed",
			"quest_failed"
		]
		for signal_name in required_signals:
			if not _has_connection(qm, signal_name, quest_ui):
				issues.append("QuestUI must connect to QuestManager.%s" % signal_name)
		if not quest_missing:
			var player = scene.get_node("Player")
			quest_ui.state = quest_ui.State.RUNNING
			player.hp = 0
			quest_ui._process(0.016)
			if not qm.get_player_quest(quest_ui.quest_name).failed:
				issues.append("Quest should fail when player HP drops to zero")
	qm.wipe_player_data()
	if issues.is_empty():
		print("VALIDATION_PASSED: Quest HUD configured correctly")
	else:
		print("VALIDATION_FAILED: %s" % "; ".join(issues))
	get_tree().quit()

func _get_qm():
	return get_tree().root.get_node("QuestManager")

func _has_connection(qm: Node, signal_name: StringName, target: Object) -> bool:
	for conn in qm.get_signal_connection_list(signal_name):
		if conn.has("callable") and conn["callable"].get_object() == target:
			return true
	return false
