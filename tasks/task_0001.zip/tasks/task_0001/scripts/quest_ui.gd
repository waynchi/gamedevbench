extends CanvasLayer

@export var quest_name := "Shoot Em Up"
@export var quest_resource: Resource

@onready var quest_label: Label = $QuestPanel/VBoxContainer/Quest
@onready var quest_info_label: Label = $QuestPanel/VBoxContainer/Do
@onready var time_label: Label = $QuestPanel/VBoxContainer/HP
@onready var player := %Player

enum State {
	START,
	RUNNING,
	LOSE,
	WIN
}

var state := State.START
var current_quest: Dictionary
var quest_steps: Array
var current_step: Dictionary
var time_left: float

func _ready():
	quest_label.text = quest_name
	quest_info_label.text = "Quest info will appear here."
	time_label.text = "Time remaining: --"

	current_quest = quest_resource.get_quest_by_name(quest_name)
	if not current_quest.is_empty():
		quest_steps = quest_resource.get_quest_steps_sorted(quest_name)
		# Find the timer step
		for step in quest_steps:
			if step.step_type == "timer_step":
				current_step = step
				break
		
		if current_step:
			time_left = current_step.total_time
			state = State.RUNNING
			update_ui(current_step)
		else:
			quest_info_label.text = "Timer step not found in quest."
			time_label.text = ""
	else:
		quest_info_label.text = "Quest '%s' not found." % quest_name


func update_ui(step):
	quest_info_label.text = step.details
	if state == State.RUNNING:
		time_label.text = "Time remaining: %d" % ceil(time_left)

func quest_complete(quest):
	pass

func quest_failed(quest):
	pass

func _process(delta):
	if state == State.RUNNING and current_step:
		if time_left > 0:
			time_left -= delta
			update_ui(current_step)
		else:
			state = State.LOSE
			time_left = 0
			time_label.text = "Time's up!"


func _on_retry_pressed():
	get_tree().reload_current_scene()

func _on_exit_pressed():
	get_tree().quit()
