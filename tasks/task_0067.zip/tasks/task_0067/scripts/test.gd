extends Node

func _ready():
	var missile_scene: PackedScene = load("res://scenes/missile.tscn")
	if missile_scene == null:
		return _fail("Missile scene not found at res://scenes/missile.tscn")

	var missile_instance = missile_scene.instantiate()
	add_child(missile_instance)

	if not missile_instance is Area2D:
		return _fail("Missile root must be Area2D")
	if missile_instance.name != "Missile":
		return _fail("Missile root node must be named 'Missile'")

	if missile_instance.collision_layer != 4:
		return _fail("Missile collision_layer must be 4")
	if missile_instance.collision_mask != 26:
		return _fail("Missile collision_mask must be 26 (targets enemies, bridges, power stations)")

	var sprite: Sprite2D = missile_instance.get_node_or_null("Sprite2D")
	if sprite == null:
		return _fail("Missile must include a Sprite2D child")
	if not sprite.region_enabled:
		return _fail("Sprite2D region mode must be enabled")
	if sprite.region_rect != Rect2(69, 0, 4, 4):
		return _fail("Sprite2D region must crop the missile (Rect2(69,0,4,4))")
	if sprite.texture == null or not sprite.texture.resource_path.ends_with("sprites-Sheet.png"):
		return _fail("Sprite2D must use sprites-Sheet.png texture")

	var collision: CollisionShape2D = missile_instance.get_node_or_null("CollisionShape2D")
	if collision == null:
		return _fail("Missile needs a CollisionShape2D child")
	if not collision.shape is RectangleShape2D:
		return _fail("Missile collision shape must be RectangleShape2D")
	if collision.shape.size != Vector2(4, 4):
		return _fail("Missile collider must be 4×4")

	var notifier: VisibleOnScreenNotifier2D = missile_instance.get_node_or_null("VisibleOnScreenNotifier2D")
	if notifier == null:
		return _fail("VisibleOnScreenNotifier2D required to clean missiles off-screen")
	if notifier.scale.distance_to(Vector2(0.2, 0.2)) > 0.01:
		return _fail("VisibleOnScreenNotifier2D scale should be close to Vector2(0.2, 0.2)")

	print("VALIDATION_PASSED: Missile projectile scene matches tutorial structure")
	get_tree().quit(0)

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
