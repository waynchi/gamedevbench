extends Node

func _ready():
	_run_validation()

func _run_validation():
	var main = get_node_or_null("Main")
	if not main:
		return _fail("Main node not found")
	var lights = main.get_node_or_null("Lights")
	if not lights:
		return _fail("Lights container missing under Main")
	var markers = main.get_node_or_null("Markers")
	if not markers:
		return _fail("Markers node missing for position references")

	var expectations = [
		{"name": "TorchLeft", "texture": "res://assets/sprites/glow_disc.tres", "marker": "Left"},
		{"name": "TorchCenter", "texture": "res://assets/sprites/glow_streak.tres", "marker": "Center"},
		{"name": "TorchRight", "texture": "res://assets/sprites/glow_disc.tres", "marker": "Right"},
	]

	for entry in expectations:
		var sprite = lights.get_node_or_null(entry.name)
		if not sprite:
			return _fail("Missing Sprite2D %s under Lights" % entry.name)
		if not sprite is Sprite2D:
			return _fail("%s must be a Sprite2D" % entry.name)
		if sprite.texture == null:
			return _fail("%s missing texture" % entry.name)
		var path = sprite.texture.resource_path
		if not path.ends_with(entry.texture.replace("res://", "")) and path != entry.texture:
			return _fail("%s must use %s" % [entry.name, entry.texture])
		var mat = sprite.material
		if not mat or not mat is CanvasItemMaterial:
			return _fail("%s must use a CanvasItemMaterial" % entry.name)
		if mat.blend_mode != CanvasItemMaterial.BLEND_MODE_ADD:
			return _fail("%s CanvasItemMaterial must be set to Add" % entry.name)
		if mat.light_mode != CanvasItemMaterial.LIGHT_MODE_LIGHT_ONLY:
			return _fail("%s CanvasItemMaterial must be Light Only" % entry.name)
		var marker = markers.get_node_or_null(entry.marker)
		if not marker:
			return _fail("Marker %s missing" % entry.marker)
		if sprite.global_position.distance_to(marker.global_position) > 0.5:
			return _fail("%s must align with marker %s" % [entry.name, entry.marker])

	print("VALIDATION_PASSED: Faux additive lights created correctly")
	get_tree().quit()

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
