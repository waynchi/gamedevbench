extends Area2D

# TODO: implement drag-and-drop behavior described in the tutorial.
# The finished version must manage dragging, spawn/despawn tweens,
# and emit a dropped signal with overlapping areas when released.
