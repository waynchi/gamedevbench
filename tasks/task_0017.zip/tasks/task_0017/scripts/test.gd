extends Node

const EXPECTED := {
    "Hand_R_IK": {
        "root": StringName("upper_arm.R"),
        "tip": StringName("hand.R"),
        "target": NodePath("../../../../RightHandTargetContainer/Hand_R_Target")
    },
    "Hand_L_IK": {
        "root": StringName("upper_arm.L"),
        "tip": StringName("hand.L"),
        "target": NodePath("../../../../LeftHandTargetContainer/Hand_L_Target")
    },
    "Foot_R_IK": {
        "root": StringName("thigh.R"),
        "tip": StringName("foot.R"),
        "target": NodePath("../../../../RightFootTargetContainer/Foot_R_Target")
    },
    "Foot_L_IK": {
        "root": StringName("thigh.L"),
        "tip": StringName("foot.L"),
        "target": NodePath("../../../../LeftFootTargetContainer/Foot_L_Target")
    }
}

func _ready():
    run_validation()

func run_validation():
    var main := get_tree().current_scene.get_node_or_null("Main")
    if main == null:
        fail("Main scene missing")
        return
    var skeleton := main.get_node("Cultist/CultistBody/CultistRig/Skeleton3D")
    for name in EXPECTED.keys():
        if not validate_ik(skeleton, name, EXPECTED[name]):
            return
    print("VALIDATION_PASSED: All limb IK solvers configured")
    get_tree().quit()

func validate_ik(skeleton: Node, name: String, spec: Dictionary) -> bool:
    var node := skeleton.get_node_or_null(name)
    if node == null:
        fail("Missing %s" % name)
        return false
    if not node is SkeletonIK3D:
        fail("%s must be SkeletonIK3D" % name)
        return false
    if node.root_bone != spec["root"]:
        fail("%s root bone must be %s" % [name, spec["root"]])
        return false
    if node.tip_bone != spec["tip"]:
        fail("%s tip bone must be %s" % [name, spec["tip"]])
        return false
    if not node.use_magnet:
        fail("%s must enable magnet" % name)
        return false
    if node.target_node != spec["target"]:
        fail("%s target node must be %s" % [name, spec["target"]])
        return false
    return true

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)
