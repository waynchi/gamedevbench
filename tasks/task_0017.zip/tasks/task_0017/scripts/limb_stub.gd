extends Node3D

@export var LimbIKContainer: NodePath
@export var Skeleton: NodePath
@export var LimbIKSolver: NodePath
@export var LimbIKMagnetOffset: Vector3 = Vector3.ZERO
@export var LimbIKTargetOffset: Vector3 = Vector3.ZERO
@export var EnemyBodyDesiredVelocityBias: float = 0.9
@export var ThisLimb: int = 0
@export var TargetPointOffsetMinimumDistance: float = 0.4
@export var ControlPointOffset: float = 0.25
@export var BlendSpeed: float = 4.5
