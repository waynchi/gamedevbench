extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		return _fail("Main node not found")

	var tile_map = main.get_node_or_null("TileMap")
	if tile_map == null or not (tile_map is TileMap):
		return _fail("TileMap node missing under Main")

	if tile_map.get_layer_name(0) != "Base":
		return _fail("TileMap layer 0 must be named Base")

	var tile_set: TileSet = tile_map.tile_set
	if tile_set == null:
		return _fail("TileMap must have a TileSet assigned")

	if tile_set.tile_size != Vector2i(18, 18):
		return _fail("TileSet tile_size must be 18x18")

	var source = tile_set.get_source(0)
	if source == null or not (source is TileSetAtlasSource):
		return _fail("TileSet source 0 must be a TileSetAtlasSource")
	
	for y in range(9):
		for x in range(20):
			var vec : Vector2i = source.get_tile_at_coords(Vector2i(x, y))
			if vec.x < 0 or vec.y < 0:
				return _fail("Some tiles are not set up correctly")
	
	if source.has_tiles_outside_texture():
		return _fail("Has tiles outside texture!")

	if source.texture == null or source.texture.resource_path != "res://assets/sprites/tilemap.png":
		return _fail("Atlas source must use res://assets/sprites/tilemap.png")

	if source.texture_region_size != Vector2i(18, 18):
		return _fail("Atlas source tile size must be 18x18")

	if source.separation != Vector2i(1, 1):
		return _fail("Atlas source separation must be 1x1")
		
	# Actual part
	source = source as TileSetAtlasSource
	
	var table = []
	
	for y in range(8):
		for x in range(4):
			table.append(Vector2i(x, y))
	
	for x in range(4, 7):
		for y in range(0, 2):
			table.append(Vector2i(x, y))
	
	for x in range(9, 16):
		table.append(Vector2i(x, 0))
	
	for x in range(8, 12):
		table.append(Vector2i(x, 1))
	
	for x in range(7, 11):
		table.append(Vector2i(x, 2))
	
	table.append(Vector2i(4, 5))
	
	for y in range(9):
		for x in range(6):   # only to 6, due to some unavoidable ambiguity in later tiles
			var tile_data: TileData = source.get_tile_data(Vector2i(x, y), 0)
			if tile_data == null:
				return _fail("Atlas source must define tile data for (%d, %d)" % [x, y])

			var has_coll = tile_data.get_collision_polygons_count(0) >= 1
			if Vector2i(x, y) not in table:
				if has_coll:
					return _fail("Tile (%d, %d) should not have a collision polygon" % [x, y])
				continue
			if not has_coll:
				return _fail("Tile (%d, %d) needs a collision polygon on physics layer 0" % [x, y])

			var points = tile_data.get_collision_polygon_points(0, 0)
			var expected = PackedVector2Array([
				Vector2(-9, -9),
				Vector2(9, -9),
				Vector2(9, 9),
				Vector2(-9, 9),
			])
			if points != expected:
				return _fail("Tile (%d, %d) collision polygon must be a full 18x18 box" % [x, y])
	
	
	

	print("VALIDATION_PASSED: TileMap atlas and TileSet configured.")
	get_tree().quit()

func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
