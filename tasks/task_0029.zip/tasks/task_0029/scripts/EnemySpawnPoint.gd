extends Marker3D
class_name EnemySpawnPoint

@export var EnemyPackedScene: PackedScene
@export var AutoSetTarget: bool = false
@export var TargetToSet: Node3D

func SpawnInitiated(_collided_body: Node3D) -> void:
	# TODO: Instantiate the packed scene, copy this node's transform, call PlaceOnMesh,
	# and optionally set the target from TargetToSet.
	pass
