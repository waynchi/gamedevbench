extends Node

var has_failed := false

func _ready():
	var main = get_node_or_null("Main")
	if main == null:
		_fail("Main scene is not instanced under TestRunner.")
		return
	
	var player = main.get_node_or_null("PlayerBody")
	if player == null:
		_fail("PlayerBody node missing.")
		return
	
	var spawn_trigger = main.get_node_or_null("NavigationRegion3D/Triggers/SpawnTrigger1")
	if spawn_trigger == null:
		_fail("SpawnTrigger1 node missing.")
		return
	
	_check_trigger_script(spawn_trigger)
	if has_failed:
		return
	var spawn_points = _gather_spawn_points(main)
	if has_failed:
		return
	_check_spawn_point_scripts(spawn_points, player)
	if has_failed:
		return
	_check_signal_connections(spawn_trigger, spawn_points)
	if has_failed:
		return
	_check_spawn_logic(spawn_points[0], player)
	if has_failed:
		return
	_check_trigger_cleanup(spawn_trigger, player)
	if has_failed:
		return
	
	print("VALIDATION_PASSED")
	get_tree().quit()

func _check_trigger_script(spawn_trigger: Area3D) -> void:
	var trigger_script = spawn_trigger.get_script()
	if trigger_script == null:
		_fail("SpawnTrigger1 must have res://scripts/TriggerVolume.gd attached.")
		return
	if trigger_script.resource_path != "res://scripts/TriggerVolume.gd":
		_fail("SpawnTrigger1 script path should be res://scripts/TriggerVolume.gd.")
		return
	if not spawn_trigger.has_method("TriggerVolume_BodyEntered"):
		_fail("TriggerVolume_BodyEntered method missing on SpawnTrigger1.")
		return

func _gather_spawn_points(main: Node) -> Array:
	var base_path = "NavigationRegion3D/Triggers"
	var names = ["EnemySpawnPointA", "EnemySpawnPointB", "EnemySpawnPointC"]
	var spawn_points: Array = []
	for name in names:
		var node = main.get_node_or_null("%s/%s" % [base_path, name])
		if node == null:
			_fail("%s not found under %s." % [name, base_path])
			return []
		spawn_points.append(node)
	return spawn_points

func _check_spawn_point_scripts(spawn_points: Array, player: Node3D) -> void:
	for spawn_point in spawn_points:
		var script = spawn_point.get_script()
		if script == null:
			_fail("%s must use res://scripts/EnemySpawnPoint.gd." % spawn_point.name)
			return
		if script.resource_path != "res://scripts/EnemySpawnPoint.gd":
			_fail("%s script path should be res://scripts/EnemySpawnPoint.gd." % spawn_point.name)
			return
		if not spawn_point.has_method("SpawnInitiated"):
			_fail("%s is missing SpawnInitiated()." % spawn_point.name)
			return
		if not spawn_point.AutoSetTarget:
			_fail("%s AutoSetTarget should be true." % spawn_point.name)
			return
		if spawn_point.TargetToSet != player:
			_fail("%s TargetToSet must reference PlayerBody." % spawn_point.name)
			return
		if spawn_point.EnemyPackedScene == null:
			_fail("%s needs an EnemyPackedScene reference." % spawn_point.name)
			return
		if spawn_point.EnemyPackedScene.resource_path != "res://scenes/Cultist.tscn":
			_fail("%s EnemyPackedScene should point to res://scenes/Cultist.tscn." % spawn_point.name)
			return

func _check_signal_connections(spawn_trigger: Area3D, spawn_points: Array) -> void:
	var expected = {}
	for spawn_point in spawn_points:
		expected[spawn_point] = false
	
	for connection in spawn_trigger.get_signal_connection_list("body_entered"):
		var callable: Callable = connection["callable"]
		var target = callable.get_object()
		if not expected.has(target):
			continue
		if callable.get_method() != "SpawnInitiated":
			continue
		expected[target] = true
	
	for spawn_point in spawn_points:
		if not expected[spawn_point]:
			_fail("SpawnTrigger1 must connect body_entered to %s.SpawnInitiated." % spawn_point.name)
			return

func _check_spawn_logic(spawn_point: Marker3D, player: Node3D) -> void:
	var parent = spawn_point.get_parent()
	var before_count = parent.get_child_count()
	spawn_point.SpawnInitiated(player)
	var after_count = parent.get_child_count()
	if after_count != before_count + 1:
		_fail("SpawnInitiated should add a spawned enemy to %s." % parent.name)
	var new_enemy = parent.get_child(after_count - 1)
	if not (new_enemy is EnemyAIController):
		_fail("Spawned node must use EnemyAIController.gd.")
		return
	if new_enemy.global_transform != spawn_point.global_transform:
		_fail("Spawned enemy global transform must match spawn point.")
		return
	if not new_enemy.did_place_on_mesh:
		_fail("Spawned enemy must call PlaceOnMesh() before finishing.")
		return
	if new_enemy.last_target != player:
		_fail("Spawned enemy must target PlayerBody when AutoSetTarget is true.")
		return
	new_enemy.queue_free()

func _check_trigger_cleanup(spawn_trigger: Area3D, player: Node3D) -> void:
	spawn_trigger.TriggerVolume_BodyEntered(player)
	if not spawn_trigger.is_queued_for_deletion():
		_fail("TriggerVolume_BodyEntered should queue_free the trigger.")
		return

func _fail(message: String) -> void:
	if has_failed:
		return
	has_failed = true
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
