extends CharacterBody2D

signal taken_damage

@onready var body_sprite := $Body

func take_damage():
    taken_damage.emit(20)
    if body_sprite:
        var tween = create_tween()
        tween.tween_property(body_sprite, "modulate", Color.RED, 0.1)
        tween.tween_property(body_sprite, "modulate", Color.WHITE, 0.1)
