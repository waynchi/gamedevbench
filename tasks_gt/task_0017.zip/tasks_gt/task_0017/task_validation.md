# Key Checklist
- [X] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Both `scenes/main.tscn` and `scenes/test.tscn` exist in tasks_gt/task_0017/scenes/
  - `main.tscn` contains the complete scene hierarchy with Main/Cultist/CultistBody/CultistRig/Skeleton3D and all required IK nodes
  - `test.tscn` is a simple scene that loads and runs scripts/test.gd for validation

- [X] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "create four SkeletonIK3D nodes named Hand_R_IK, Hand_L_IK, Foot_R_IK, and Foot_L_IK"
    - Transcript: "we do also need the ik's so we can go ahead and right click and set add child node we'll use the skeleton ik 3D and we'll just go ahead and make four of those we'll rename each one of these for the different ik"
  - Instruction 2: "Configure their root/tip bones exactly as in the video (upper_arm.R → hand.R, upper_arm.L → hand.L, thigh.R → foot.R, thigh.L → foot.L)"
    - Transcript: "for the arms I found that using the upper body as the root bone and the hand as the tip bone worked out just fine ... we are going to go ahead and use the thigh and the foot for the various feed ik"
  - Instruction 3: "enable magnet support"
    - Transcript: "we are going to go ahead and use the magnet"
  - Instruction 4: "point each solver's target_node at the matching IK target container"
    - Transcript: Implied by the discussion of target containers and IK setup in the video
  - Instructions Missing from Transcript: None - all instructions are directly derived from the transcript

- [X] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Task config metadata.evidence cites:
    - ScenePrefabs/Enemies/CultistBody.tscn:22-48 for SkeletonIK3D node configuration
    - ScenePrefabs/Enemies/CultistPrefab.tscn:53-63 for target_node paths
  - The ground truth main.tscn:65-87 contains four SkeletonIK3D nodes matching the repository structure

- [X] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction specifies:
    - Exact path where nodes should be created: "Inside Main/Cultist/CultistBody/CultistRig/Skeleton3D"
    - Exact node names: "Hand_R_IK, Hand_L_IK, Foot_R_IK, and Foot_L_IK"
    - Exact bone pairs: "upper_arm.R → hand.R, upper_arm.L → hand.L, thigh.R → foot.R, thigh.L → foot.L"
    - Exact target paths: "RightHandTargetContainer/Hand_R_Target, LeftHandTargetContainer/Hand_L_Target, etc."
    - No references to "the tutorial" or "other tasks"

- [X] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: The task only requires:
    - Creating SkeletonIK3D nodes in the scene tree (inspector work)
    - Setting node properties via inspector (root_bone, tip_bone, use_magnet, target_node)
    - No GDScript editing required
    - test.gd validates node existence and inspector properties only

- [X] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test validates 4 IK nodes, Instruction requires creating 4 IK nodes (Hand_R_IK, Hand_L_IK, Foot_R_IK, Foot_L_IK)
  - Test validates node type is SkeletonIK3D, Instruction specifies "SkeletonIK3D nodes"
  - Test validates root_bone values, Instruction specifies exact root bones (upper_arm.R, upper_arm.L, thigh.R, thigh.L)
  - Test validates tip_bone values, Instruction specifies exact tip bones (hand.R, hand.L, foot.R, foot.L)
  - Test validates use_magnet = true, Instruction specifies "enable magnet support"
  - Test validates target_node paths, Instruction specifies "point each solver's target_node at the matching IK target container"
  - Missing Coverage: None - all instruction elements are tested
- [X] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail

  - **Hand_R_IK validation** (test.gd:41-61):
    - Assertions:
      1. Node exists at path "Skeleton3D/Hand_R_IK"
      2. Node type is SkeletonIK3D
      3. root_bone == "upper_arm.R"
      4. tip_bone == "hand.R"
      5. use_magnet == true
      6. target_node == NodePath("../../../../RightHandTargetContainer/Hand_R_Target")
    - Instruction coverage:
      1. "create four SkeletonIK3D nodes named Hand_R_IK" → node exists with name
      2. "SkeletonIK3D nodes" → specifies type
      3. "upper_arm.R → hand.R" → exact root bone
      4. "upper_arm.R → hand.R" → exact tip bone
      5. "enable magnet support" → use_magnet property
      6. "point each solver's target_node at the matching IK target container (RightHandTargetContainer/Hand_R_Target" → exact path

  - **Hand_L_IK validation** (test.gd:41-61):
    - Assertions:
      1. Node exists at path "Skeleton3D/Hand_L_IK"
      2. Node type is SkeletonIK3D
      3. root_bone == "upper_arm.L"
      4. tip_bone == "hand.L"
      5. use_magnet == true
      6. target_node == NodePath("../../../../LeftHandTargetContainer/Hand_L_Target")
    - Instruction coverage:
      1. "create four SkeletonIK3D nodes named ...Hand_L_IK" → node exists with name
      2. "SkeletonIK3D nodes" → specifies type
      3. "upper_arm.L → hand.L" → exact root bone
      4. "upper_arm.L → hand.L" → exact tip bone
      5. "enable magnet support" → use_magnet property
      6. "LeftHandTargetContainer/Hand_L_Target" → exact path

  - **Foot_R_IK validation** (test.gd:41-61):
    - Assertions:
      1. Node exists at path "Skeleton3D/Foot_R_IK"
      2. Node type is SkeletonIK3D
      3. root_bone == "thigh.R"
      4. tip_bone == "foot.R"
      5. use_magnet == true
      6. target_node == NodePath("../../../../RightFootTargetContainer/Foot_R_Target")
    - Instruction coverage:
      1. "create four SkeletonIK3D nodes named ...Foot_R_IK" → node exists with name
      2. "SkeletonIK3D nodes" → specifies type
      3. "thigh.R → foot.R" → exact root bone
      4. "thigh.R → foot.R" → exact tip bone
      5. "enable magnet support" → use_magnet property
      6. "RightFootTargetContainer/Foot_R_Target" → exact path (implied by pattern)

  - **Foot_L_IK validation** (test.gd:41-61):
    - Assertions:
      1. Node exists at path "Skeleton3D/Foot_L_IK"
      2. Node type is SkeletonIK3D
      3. root_bone == "thigh.L"
      4. tip_bone == "foot.L"
      5. use_magnet == true
      6. target_node == NodePath("../../../../LeftFootTargetContainer/Foot_L_Target")
    - Instruction coverage:
      1. "create four SkeletonIK3D nodes named ...Foot_L_IK" → node exists with name
      2. "SkeletonIK3D nodes" → specifies type
      3. "thigh.L → foot.L" → exact root bone
      4. "thigh.L → foot.L" → exact tip bone
      5. "enable magnet support" → use_magnet property
      6. "LeftFootTargetContainer/Foot_L_Target" → exact path (implied by pattern)

  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [X] String formatting (padding, delimiters, exact format) is specified in instruction
      - Bone names use exact format: "upper_arm.R", "hand.R", "thigh.R", "foot.R" etc.
    - [X] Exact string values/names are in instruction (not just "format text")
      - All node names explicitly listed: "Hand_R_IK, Hand_L_IK, Foot_R_IK, and Foot_L_IK"
      - All bone names explicitly listed: "upper_arm.R → hand.R, upper_arm.L → hand.L, thigh.R → foot.R, thigh.L → foot.L"
    - [N/A] Number formats (zero-padding, decimal places) are specified
      - No number formatting required
    - [N/A] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria
      - Tests use exact equality, all values specified in instruction
    - [X] Node names, paths, and types match instruction exactly
      - Node names: "Hand_R_IK, Hand_L_IK, Foot_R_IK, and Foot_L_IK" ✓
      - Node type: "SkeletonIK3D" ✓
      - Parent path: "Inside Main/Cultist/CultistBody/CultistRig/Skeleton3D" ✓
    - [X] Property values (numbers, booleans, strings) have exact values in instruction
      - root_bone values: exact strings provided
      - tip_bone values: exact strings provided
      - use_magnet: "enable magnet support" = true
      - target_node: exact container names provided
  - Ambiguous Tests: None - all test checks are fully specified in the instruction
- [X] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: There is only one correct solution to this problem:
    - Exact node names are specified (Hand_R_IK, Hand_L_IK, Foot_R_IK, Foot_L_IK)
    - Exact bone pairs are specified (upper_arm.R→hand.R, etc.)
    - Exact target paths are specified
    - No flexibility is needed; the instruction is deterministic
- [X] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence:
    - Folder structure: tasks_gt/task_0017/ ✓
    - Contains: project.godot, scenes/, scripts/ ✓
    - scenes/ contains: main.tscn, test.tscn ✓
    - scripts/ contains: test.gd ✓
    - Naming convention follows task_XXXX_name pattern ✓
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [X] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The entire task is inspector-focused:
    - Creating SkeletonIK3D nodes in the scene tree (node creation)
    - Setting root_bone and tip_bone properties (inspector properties)
    - Enabling use_magnet checkbox (inspector boolean)
    - Setting target_node paths (inspector NodePath property)
    - No scripting required
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: No multimodal reasoning required
    - All node names, bone names, and paths are explicitly specified as text
    - No visual inspection or spatial reasoning needed
    - Task can be completed using text instructions alone
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No multimodal inputs in the instruction
    - Instruction is purely text-based
    - No images, diagrams, or visual references included

# Notes

## Validation Summary

Task 0234 (Cultist Limb SkeletonIK) has been thoroughly validated and all key checks pass successfully.

### Key Findings:
1. **Complete alignment with transcript**: All instructions are directly derived from the tutorial video transcript, with exact quotes documented
2. **Unambiguous instructions**: Every test assertion has a corresponding explicit specification in the instruction
3. **Inspector-only task**: No scripting required, purely node/inspector focused
4. **Deterministic solution**: Only one correct way to complete the task
5. **Proper structure**: Follows GameDevBench conventions for folder/file naming

### Evidence Summary:
- Transcript citations documented for all 4 instruction components
- Repository code references (ScenePrefabs/Enemies/CultistBody.tscn:22-48, CultistPrefab.tscn:53-63)
- All 4 SkeletonIK3D nodes validated with 6 assertions each (24 total assertions)
- Ground truth scene matches repository structure

### Validation Date: 2025-11-23

The task is ready for use in GameDevBench.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
