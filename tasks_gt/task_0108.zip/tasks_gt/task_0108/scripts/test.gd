extends Node

func _ready():
	run_validation()

func run_validation():
	var world_scene_text = FileAccess.get_file_as_string("res://scenes/world.tscn")
	if world_scene_text.is_empty():
		fail("world.tscn not found or empty")
		return
	if world_scene_text.find("custom_data_layer_0/name = \"tile_type\"") == -1:
		fail("TileSet missing tile_type custom data layer")
		return
	if world_scene_text.find("water_color = SubResource(\"GradientTexture1D_water\")") == -1:
		fail("World node missing water_color gradient")
		return
	if world_scene_text.find("dirt_color = SubResource(\"GradientTexture1D_dirt\")") == -1:
		fail("World node missing dirt_color gradient")
		return
	if world_scene_text.find("grass_color = SubResource(\"GradientTexture1D_grass\")") == -1:
		fail("World node missing grass_color gradient")
		return

	var world_script_text = FileAccess.get_file_as_string("res://scripts/world.gd")
	if world_script_text.is_empty():
		fail("world.gd not found or empty")
		return
	if world_script_text.find("enum TILE_TYPES") == -1:
		fail("World is missing TILE_TYPES enum")
		return
	if world_script_text.find("get_gradient_at") == -1:
		fail("World is missing get_gradient_at")
		return

	var tank_scene_text = FileAccess.get_file_as_string("res://scenes/tank.tscn")
	if tank_scene_text.is_empty():
		fail("tank.tscn not found or empty")
		return
	if tank_scene_text.find("LeftTrackParticles") == -1:
		fail("Tank scene missing LeftTrackParticles")
		return
	if tank_scene_text.find("RightTrackParticles") == -1:
		fail("Tank scene missing RightTrackParticles")
		return
	if tank_scene_text.find("z_index = -1") == -1:
		fail("Track particles should be below the tank")
		return
	if tank_scene_text.find("emitting = false") == -1:
		fail("Track particles should start with emitting disabled")
		return

	var tank_script_text = FileAccess.get_file_as_string("res://scripts/tank.gd")
	if tank_script_text.is_empty():
		fail("tank.gd not found or empty")
		return
	if tank_script_text.find("World.get_gradient_at") == -1:
		fail("Tank is missing World.get_gradient_at call")
		return
	if tank_script_text.find("color_ramp") == -1:
		fail("Tank does not apply particle gradient to color_ramp")
		return
	if tank_script_text.find("emitting = true") == -1:
		fail("Tank does not enable particles while moving")
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)

func fail(reason: String):
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)
