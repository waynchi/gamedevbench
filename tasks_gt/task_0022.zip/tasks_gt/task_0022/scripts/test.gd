extends Node

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func run_validation():
    var main_node = get_node_or_null("Main")
    if not main_node:
        fail("Main scene is missing")
        return

    var trap = main_node.get_node_or_null("Trap")
    if not trap or not trap is Node2D:
        fail("Trap node must exist as a Node2D child of Main")
        return

    var spawn_holder = trap.get_node_or_null("SpawningPoints")
    if not spawn_holder or not spawn_holder is Node2D:
        fail("Add a Node2D named SpawningPoints under Trap")
        return

    var spawn_top = spawn_holder.get_node_or_null("SpawnTop")
    if not spawn_top or not spawn_top is Marker2D:
        fail("SpawningPoints needs a Marker2D child named SpawnTop")
        return

    var spawn_bot = spawn_holder.get_node_or_null("SpawnBot")
    if not spawn_bot or not spawn_bot is Marker2D:
        fail("SpawningPoints needs a Marker2D child named SpawnBot")
        return

    if spawn_top.position != Vector2(0, 15):
        fail("SpawnTop must sit 15px above Trap (Vector2(0, 15))")
        return

    if spawn_bot.position != Vector2(0, -15):
        fail("SpawnBot must sit 15px below Trap (Vector2(0, -15))")
        return

    if spawn_bot.z_index != 1:
        fail("SpawnBot should render above Trap by setting z_index to 1")
        return

    print("VALIDATION_PASSED: Spawning markers configured for the trap")
    get_tree().quit(0)
