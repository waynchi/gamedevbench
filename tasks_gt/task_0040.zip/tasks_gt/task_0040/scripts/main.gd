extends Node3D

@onready var porch_light: OmniLight3D = $PorchLight
@onready var clock_label: Label = $ClockLabel

func _ready() -> void:
	# ensure label has a sensible starting display
	clock_label.text = "00:00"

func _on_day_night_cycle_time_changed(current_time: String) -> void:
	clock_label.text = current_time
	if current_time == "06:00":
		porch_light.visible = false
	elif current_time == "18:00":
		porch_light.visible = true
