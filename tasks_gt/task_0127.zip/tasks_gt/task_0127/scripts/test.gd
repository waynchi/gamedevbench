extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var music_player := get_node_or_null("/root/MusicPlayer")
	if music_player == null:
		print("VALIDATION_FAILED: MusicPlayer autoload not found")
		get_tree().quit(1)
		return
	if not music_player is AudioStreamPlayer:
		print("VALIDATION_FAILED: MusicPlayer must be AudioStreamPlayer")
		get_tree().quit(1)
		return
	if music_player.stream == null or music_player.stream.resource_path != "res://assets/sounds/music.ogg":
		print("VALIDATION_FAILED: Music stream not set")
		get_tree().quit(1)
		return
	if not music_player.autoplay:
		print("VALIDATION_FAILED: MusicPlayer autoplay must be enabled")
		get_tree().quit(1)
		return
	if music_player.bus != "Music":
		print("VALIDATION_FAILED: MusicPlayer bus must be Music")
		get_tree().quit(1)
		return
	
	if not AudioServer.is_bus_mute(AudioServer.get_bus_index("Music")):
		print("VALIDATION_FAILED: Bus Music must be muted")
		get_tree().quit(1)
		return
	
	if AudioServer.is_bus_mute(AudioServer.get_bus_index("Sound")):
		print("VALIDATION_FAILED: Bus Sound shouldn't be changed")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)
