extends Node

func _ready() -> void:
	await get_tree().process_frame
	run_validation()

func run_validation() -> void:
	var main_node = get_node_or_null("Main")
	if main_node == null:
		return _fail("Main scene was not instanced in test.tscn")
	var pickup = main_node.get_node_or_null("ItemPickup")
	if pickup == null:
		return _fail("Main scene must instance ItemPickup")
	if not (pickup is RigidBody3D):
		return _fail("ItemPickup must be a RigidBody3D")
	if pickup.collision_layer != 2 or pickup.collision_mask != 3:
		return _fail("ItemPickup collision layers must be set to layer 2 / mask 3")
	if pickup.get_script() == null or not pickup.get_script().resource_path.ends_with("interactable_item.gd"):
		return _fail("ItemPickup must use interactable_item.gd")
	if not (pickup is InteractableItem):
		return _fail("InteractableItem class_name is missing")
	var highlight: MeshInstance3D = pickup.item_highlight_mesh
	if highlight == null:
		return _fail("item_highlight_mesh export is unassigned")
	if highlight.visible:
		return _fail("Highlight mesh should be hidden by default")
	var material := highlight.get_active_material(0)
	if material == null or not (material is StandardMaterial3D) or not material.emission_enabled:
		return _fail("Highlight mesh needs an emissive StandardMaterial3D")
	pickup.gain_focus()
	if not highlight.visible:
		return _fail("gain_focus must show the highlight mesh")
	pickup.lose_focus()
	if highlight.visible:
		return _fail("lose_focus must hide the highlight mesh")
	var item_data = load("res://resources/items/test_cube.tres")
	if item_data == null or not (item_data is ItemData):
		return _fail("test_cube.tres must be an ItemData resource")
	if item_data.item_name.strip_edges() != "Test Cube":
		return _fail("ItemData.item_name must equal 'Test Cube'")
	if item_data.item_model_prefab == null:
		return _fail("ItemData must reference the pickup PackedScene")
	if item_data.item_model_prefab.resource_path != "res://scenes/item_pickup.tscn":
		return _fail("ItemData.item_model_prefab must point to scenes/item_pickup.tscn")
	print("VALIDATION_PASSED: Interactable highlight prefab and metadata created")
	get_tree().quit()

func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
