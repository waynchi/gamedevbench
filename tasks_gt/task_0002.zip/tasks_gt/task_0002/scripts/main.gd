extends Node2D

@export var quest_name := "Shoot Em Up"
@export var quest_resource: Resource
@onready var quest_progress_label = $UI/QuestProgress

func _ready():
	if quest_resource:
		QuestManager.add_quest(quest_name, quest_resource)
	QuestManager.step_updated.connect(_on_step_updated)

func _on_step_updated(step):
	if step.step_type == QuestManager.INCREMENTAL_STEP:
		quest_progress_label.text = "Enemies %02d/%02d" % [step.collected, step.required]
