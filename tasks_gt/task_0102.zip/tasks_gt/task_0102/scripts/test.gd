extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		return _fail("Main node not found")

	var tile_map = main.get_node_or_null("TileMap")
	if tile_map == null or not (tile_map is TileMap):
		return _fail("TileMap node missing under Main")

	if tile_map.get_layers_count() < 2:
		return _fail("TileMap must have at least two layers")

	if tile_map.get_layer_name(0) != "Base":
		return _fail("TileMap layer 0 must be named Base")
	if tile_map.get_layer_name(1) != "Details":
		return _fail("TileMap layer 1 must be named Details")

	var tile_set: TileSet = tile_map.tile_set
	if tile_set == null:
		return _fail("TileMap must have a TileSet assigned")

	if tile_set.get_physics_layers_count() < 1:
		return _fail("TileSet must define a physics layer")
	if tile_set.get_physics_layer_collision_layer(0) != 2:
		return _fail("Physics layer 0 collision layer must be set to 2")

	var source = tile_set.get_source(0)
	if source == null or not (source is TileSetAtlasSource):
		return _fail("TileSet source 0 must be a TileSetAtlasSource")

	var tile_data: TileData = source.get_tile_data(Vector2i(0, 0), 0)
	if tile_data == null:
		return _fail("Atlas source must define tile data for (0, 0)")

	if tile_data.get_collision_polygons_count(0) < 1:
		return _fail("Tile (0, 0) needs a collision polygon on physics layer 0")

	var points = tile_data.get_collision_polygon_points(0, 0)
	var expected = PackedVector2Array([
		Vector2(-9, -9),
		Vector2(9, -9),
		Vector2(9, 9),
		Vector2(-9, 9),
	])
	if points != expected:
		return _fail("Tile (0, 0) collision polygon must be a full 18x18 box")

	print("VALIDATION_PASSED: TileMap layers and physics collisions configured.")
	get_tree().quit()

func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
