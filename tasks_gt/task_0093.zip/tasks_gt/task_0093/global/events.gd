extends Node

signal battle_over_screen_requested(text: String, type: int)
