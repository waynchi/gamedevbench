extends Node

const SHADER_PATH := "res://shaders/weapon_clip_and_fov_shader.gdshader"
const EXPECTED_FOV := 54.0
const EXPECTED_ALBEDO := Color(0.2, 0.7, 0.9, 1)

func _ready():
	await get_tree().process_frame
	run_validation()

func run_validation():
	var main_node = get_node_or_null("Main")
	if not main_node:
		print("VALIDATION_FAILED: Main node not found")
		get_tree().quit(1)
		return

	var weapon_manager = main_node.get_node_or_null("WeaponManager")
	if not weapon_manager:
		print("VALIDATION_FAILED: WeaponManager node not found")
		get_tree().quit(1)
		return

	var knife = weapon_manager.get_node_or_null("ViewModel/Knife")
	if not knife or not (knife is MeshInstance3D):
		print("VALIDATION_FAILED: Knife MeshInstance3D not found")
		get_tree().quit(1)
		return

	if knife.cast_shadow != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF:
		print("VALIDATION_FAILED: Knife must have shadow casting disabled")
		get_tree().quit(1)
		return

	var mesh = knife.mesh
	if mesh == null:
		print("VALIDATION_FAILED: Knife mesh is missing")
		get_tree().quit(1)
		return

	var surface_material = mesh.surface_get_material(0)
	if not surface_material or not (surface_material is ShaderMaterial):
		print("VALIDATION_FAILED: Knife surface material is not a ShaderMaterial")
		get_tree().quit(1)
		return

	var shader_mat := surface_material as ShaderMaterial
	if not shader_mat.shader:
		print("VALIDATION_FAILED: ShaderMaterial has no shader")
		get_tree().quit(1)
		return
	if shader_mat.shader.resource_path != SHADER_PATH:
		print("VALIDATION_FAILED: Shader path is incorrect")
		get_tree().quit(1)
		return

	var fov_value = float(shader_mat.get_shader_parameter("viewmodel_fov"))
	if abs(fov_value - EXPECTED_FOV) > 0.01:
		print("VALIDATION_FAILED: viewmodel_fov must be set to 54.0")
		get_tree().quit(1)
		return

	var albedo_value = shader_mat.get_shader_parameter("albedo")
	if not _color_close(albedo_value, EXPECTED_ALBEDO, 0.01):
		print("VALIDATION_FAILED: Shader albedo parameter was not copied from base material")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: View model shader applied and configured")
	get_tree().quit(1)

func _color_close(a: Color, b: Color, eps: float) -> bool:
	return abs(a.r - b.r) <= eps and abs(a.g - b.g) <= eps and abs(a.b - b.b) <= eps and abs(a.a - b.a) <= eps
