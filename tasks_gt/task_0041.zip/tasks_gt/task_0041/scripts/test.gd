extends Node

func _ready():
	run_validation()

func fail(reason: String) -> void:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)

func run_validation():
	var main_node = get_node_or_null("Main")
	if main_node == null:
		fail("Main node not found")
		return
	
	if main_node.get_script() == null:
		fail("Main node is missing pong.gd script")
		return
	if main_node.get_script().resource_path != "res://scripts/pong.gd":
		fail("Main script should be res://scripts/pong.gd")
		return
	
	var left_label = main_node.get_node_or_null("LeftLabel")
	var right_label = main_node.get_node_or_null("RightLabl")
	if left_label == null or right_label == null:
		fail("Score Labels LeftLabel and RightLabl must exist")
		return
	if left_label.text != "0" or right_label.text != "0":
		fail("Score labels must start at 0")
		return
	
	for label in [left_label, right_label]:
		if not (label is Label):
			fail("%s must be a Label" % label.name)
			return
	
	var left_wall = main_node.get_node_or_null("LeftWall")
	var right_wall = main_node.get_node_or_null("RightWall")
	if left_wall == null or right_wall == null:
		fail("Wall nodes missing")
		return
	
	if not left_wall.is_connected("rightPointUp", Callable(main_node, "_on_left_wall_right_point_up")):
		fail("LeftWall.rightPointUp must be connected to _on_left_wall_right_point_up")
		return
	if not right_wall.is_connected("leftPointUp", Callable(main_node, "_on_right_wall_left_point_up")):
		fail("RightWall.leftPointUp must be connected to _on_right_wall_left_point_up")
		return
	
	if not main_node.has_method("reset_points") or not main_node.has_method("handle_right_point_up") or not main_node.has_method("handle_left_point_up"):
		fail("Pong script missing scoring methods")
		return
	
	main_node.reset_points()
	if main_node.left_points != 0 or main_node.right_points != 0:
		fail("reset_points must zero both counters")
		return
	
	main_node._on_left_wall_right_point_up()
	if main_node.right_points != 1 or right_label.text != "1":
		fail("Right score must increment when left wall reports a point")
		return
	
	main_node._on_right_wall_left_point_up()
	if main_node.left_points != 1 or left_label.text != "1":
		fail("Left score must increment when right wall reports a point")
		return
	
	var target_points = 11
	main_node.right_points = target_points - 1
	main_node.handle_right_point_up()
	if main_node.right_points != 0 or right_label.text != "0":
		fail("Scores must reset after reaching MAX_POINTS")
		return
	if left_label.text != "0":
		fail("Reset should also zero the opponent label")
		return
	
	print("VALIDATION_PASSED")
	get_tree().quit(0)
