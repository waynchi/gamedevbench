extends Node

func _ready():
	run_validation()

func ensure(condition: bool, message: String) -> bool:
	if not condition:
		print("VALIDATION_FAILED: %s" % message)
		get_tree().quit(1)
		return true
	return false

func run_validation():
	load("res://scripts/stats_ui.gd")
	var scene = load("res://scenes/stats_ui.tscn")
	if ensure(scene is PackedScene, "StatsUI scene missing"):
		return
	var stats_ui = scene.instantiate()
	add_child(stats_ui)
	if ensure(stats_ui is HBoxContainer, "StatsUI root must be an HBoxContainer"):
		return
	if ensure(stats_ui.get_script() != null, "StatsUI scene must have a script attached"):
		return
	if stats_ui.theme:
		if ensure(stats_ui.theme.resource_path.ends_with("assets/main_theme.tres"), "StatsUI should use the provided theme"):
			return
	else:
		if ensure(false, "StatsUI should assign the shared theme"):
			return

	var block = stats_ui.get_node_or_null("Block")
	var health = stats_ui.get_node_or_null("Health")
	if ensure(block is HBoxContainer and health is HBoxContainer, "Block and Health containers missing"):
		return
	if ensure(block.get_theme_constant("separation", "") == 0, "Block separation must be 0"):
		return
	if ensure(health.get_theme_constant("separation", "") == 2, "Health separation must be 2"):
		return

	var block_image = block.get_node_or_null("BlockImage")
	var health_image = health.get_node_or_null("HealthImage")
	if ensure(block_image is TextureRect and health_image is TextureRect, "TextureRects missing"):
		return
	if ensure(block_image.texture and block_image.texture.resource_path.ends_with("tile_0102.png"), "Block image must use tile_0102 texture"):
		return
	if ensure(health_image.texture and health_image.texture.resource_path.ends_with("heart.png"), "Health image must use heart texture"):
		return

	var block_label = stats_ui.get_node_or_null("%BlockLabel")
	var health_label = stats_ui.get_node_or_null("%HealthLabel")
	if ensure(block_label is Label and health_label is Label, "Labels missing or not marked with unique names"):
		return
	if ensure(block_label.horizontal_alignment == HORIZONTAL_ALIGNMENT_CENTER and health_label.horizontal_alignment == HORIZONTAL_ALIGNMENT_CENTER, "Labels must center text"):
		return
	if ensure(block_label.vertical_alignment == VERTICAL_ALIGNMENT_CENTER and health_label.vertical_alignment == VERTICAL_ALIGNMENT_CENTER, "Labels must align vertically"):
		return

	var stats = Stats.new()
	stats.max_health = 10
	stats.health = 10
	stats.block = 4
	stats_ui.update_stats(stats)
	if ensure(block_label.text == "4" and health_label.text == "10", "update_stats should apply stat values"):
		return
	if ensure(block.visible and health.visible, "Sections should show when values are positive"):
		return

	stats.block = 0
	stats_ui.update_stats(stats)
	if ensure(not block.visible, "Block container should hide when block is zero"):
		return

	stats.health = 0
	stats_ui.update_stats(stats)
	if ensure(not health.visible, "Health container should hide when health is zero"):
		return

	print("VALIDATION_PASSED: StatsUI scene and script are configured correctly")
	stats_ui.queue_free()
	get_tree().quit()
