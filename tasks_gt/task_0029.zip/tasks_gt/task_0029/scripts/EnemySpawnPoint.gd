extends Marker3D
class_name EnemySpawnPoint

@export var EnemyPackedScene: PackedScene
@export var AutoSetTarget: bool = false
@export var TargetToSet: Node3D

func SpawnInitiated(_collided_body: Node3D) -> void:
	if EnemyPackedScene == null:
		return
	
	var new_enemy := EnemyPackedScene.instantiate()
	get_parent().add_child(new_enemy)
	new_enemy.global_transform = global_transform
	
	if new_enemy is EnemyAIController:
		var ai := new_enemy as EnemyAIController
		ai.PlaceOnMesh()
		if AutoSetTarget and TargetToSet != null:
			ai.SetNodeTarget(TargetToSet)
