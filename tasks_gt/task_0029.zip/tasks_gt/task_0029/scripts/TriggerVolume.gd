extends Area3D
class_name TriggerVolume

func TriggerVolume_BodyEntered(_collided_body: Node3D) -> void:
	queue_free()
