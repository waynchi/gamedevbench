extends CharacterBody3D

@export_node_path("Node") var gun_effects_path: NodePath
var gun_effects: Node

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	gun_effects = get_node_or_null(gun_effects_path)

func _unhandled_input(event):
	if event.is_action_pressed("ui_cancel") and gun_effects and gun_effects.has_method("reload"):
		gun_effects.reload()
	if event.is_action_pressed("ui_accept") and gun_effects and gun_effects.has_method("fire_revolver"):
		gun_effects.fire_revolver()
