class_name DamageableObject
extends Node

@export var impact_effect: PackedScene

func hit_object(_hit_location: Vector3, _force: Vector3) -> void:
	pass
