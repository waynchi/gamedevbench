extends Node

func _ready():
	run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func succeed(message: String) -> void:
	print("VALIDATION_PASSED: %s" % message)
	get_tree().quit()

func run_validation():
	var main := get_node_or_null("Main")
	if not main:
		fail("Main scene missing")
		return

	var arms := main.get_node_or_null("ArmsRig")
	if not arms:
		fail("ArmsRig node missing")
		return

	var barrel_end := arms.get_node_or_null("FrontAttachment/BarrelEnd") as Node3D
	if not barrel_end:
		fail("BarrelEnd node missing under ArmsRig")
		return

	var raycast := barrel_end.get_node_or_null("RayCast3D") as RayCast3D
	if not raycast:
		fail("RayCast3D missing under BarrelEnd")
		return

	if not _vectors_close(raycast.target_position, Vector3(0, 0, -1000)):
		fail("RayCast3D target_position must extend -1000 on Z axis")
		return

	var controller := arms.get_node_or_null("WeaponEffectsController")
	if not controller:
		fail("WeaponEffectsController node missing")
		return

	if controller.get_script() == null or String(controller.get_script().resource_path).find("weapon_effects_controller.gd") == -1:
		fail("WeaponEffectsController must use weapon_effects_controller.gd")
		return

	if controller.get("barrel_end_path") != NodePath("../FrontAttachment/BarrelEnd"):
		fail("WeaponEffectsController.barrel_end must point to BarrelEnd")
		return

	if controller.get("barrel_raycast_path") != NodePath("../FrontAttachment/BarrelEnd/RayCast3D"):
		fail("WeaponEffectsController.barrel_raycast must point to RayCast3D")
		return

	var muzzle_scene: PackedScene = controller.get("muzzle_flash_scene")
	if muzzle_scene == null or String(muzzle_scene.resource_path).find("muzzle_flash_effect.tscn") == -1:
		fail("WeaponEffectsController.muzzle_flash_scene must reference the muzzle flash effect scene")
		return

	var impact_scene: PackedScene = controller.get("impact_effect_scene")
	if impact_scene == null or String(impact_scene.resource_path).find("impact_effect.tscn") == -1:
		fail("WeaponEffectsController.impact_effect_scene must reference the impact effect scene")
		return

	var player := main.get_node_or_null("PlayerBody")
	if not player:
		fail("PlayerBody node missing")
		return

	if player.get("gun_effects_path") != NodePath("../ArmsRig/WeaponEffectsController"):
		fail("PlayerBody.gun_effects must target the WeaponEffectsController")
		return

	succeed("Weapon effects controller wired correctly")

func _vectors_close(a: Vector3, b: Vector3) -> bool:
	return a.distance_to(b) <= 0.01
