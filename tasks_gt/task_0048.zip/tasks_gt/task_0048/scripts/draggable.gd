extends Area2D
class_name Draggable

const DRAGGING_SPEED := 50.0

var initial_position := Vector2.ZERO
var initial_scale := Vector2.ONE
var is_dragging := false
var texture: Texture2D

signal dropped(draggable: Draggable, overlapping_areas: Array)

@onready var sprite: Sprite2D = $Sprite
@onready var collision_shape: CollisionShape2D = $CollisionShape

func _ready() -> void:
	if texture and sprite.texture == null:
		sprite.texture = texture
	initial_position = global_position
	initial_scale = scale
	play_spawn_animation()

func _process(delta: float) -> void:
	if is_dragging:
		global_position = global_position.lerp(
			get_global_mouse_position(),
			delta * DRAGGING_SPEED
		)

func _on_input_event(_viewport: Viewport, event: InputEvent, _shape_idx: int) -> void:
	if event.is_action_pressed("click"):
		is_dragging = true

func _input(event: InputEvent) -> void:
	if is_dragging and event.is_action_released("click"):
		is_dragging = false
		var overlapping_areas := get_overlapping_areas()
		dropped.emit(self, overlapping_areas)
		if overlapping_areas.is_empty():
			self_destruct()

func self_destruct() -> void:
	await _play_self_destruct_animation()
	queue_free()

func play_spawn_animation() -> void:
	scale = Vector2.ZERO
	get_tree().create_tween() \
		.tween_property(self, "scale", initial_scale, 0.3) \
		.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)

func _play_self_destruct_animation() -> void:
	await get_tree().create_tween() \
		.tween_property(self, "scale", Vector2.ZERO, 0.1) \
		.set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD).finished
