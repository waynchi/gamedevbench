extends CharacterBody2D

const SPEED = 100.0
const JUMP_VELOCITY = -300.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
@onready var animated_sprite_2d = $AnimatedSprite2D

func _physics_process(delta):
	if not is_on_floor():
		velocity.y += gravity * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		animated_sprite_2d.play("run")
		velocity.x = direction * SPEED
	else:
		animated_sprite_2d.play("default")
		velocity.x = move_toward(velocity.x, 0, SPEED)

	animated_sprite_2d.flip_h = direction < 0
	move_and_slide()
