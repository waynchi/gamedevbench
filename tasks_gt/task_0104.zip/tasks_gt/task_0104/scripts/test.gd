extends Node

func _ready():
	run_validation()

func fail(msg: String) -> void:
	print("VALIDATION_FAILED: %s" % msg)
	get_tree().quit(1)

func approx_equal(a: Vector2, b: Vector2, tolerance := 0.01) -> bool:
	return a.distance_to(b) <= tolerance

func atlas_matches(tex: AtlasTexture) -> bool:
	if tex == null or tex.atlas == null:
		return false
	var path := tex.atlas.resource_path
	return path.ends_with("DinoSprites - tard.png") or path.ends_with("DinoSprites - tard.res")

func check_atlas_frames(frames: SpriteFrames, anim_name: String, regions: Array, expected_speed: float) -> void:
	if not frames.has_animation(anim_name):
		fail("SpriteFrames missing %s animation" % anim_name)
	if frames.get_frame_count(anim_name) != regions.size():
		fail("%s animation frame count mismatch" % anim_name)
	if not frames.get_animation_loop(anim_name):
		fail("%s animation should loop" % anim_name)
	if abs(frames.get_animation_speed(anim_name) - expected_speed) > 0.01:
		fail("%s animation speed should be %.2f" % [anim_name, expected_speed])
	for i in regions.size():
		var tex = frames.get_frame_texture(anim_name, i)
		if tex == null or not (tex is AtlasTexture):
			fail("%s frame %d must be an AtlasTexture" % [anim_name, i])
		if not atlas_matches(tex):
			fail("%s frame %d must reference DinoSprites - tard texture" % [anim_name, i])
		var rect: Rect2 = tex.region
		var expected: Rect2 = regions[i]
		if rect.position != expected.position or rect.size != expected.size:
			fail("%s frame %d region mismatch" % [anim_name, i])
		var duration = frames.get_frame_duration(anim_name, i)
		if abs(duration - 1.0) > 0.01:
			fail("%s frame %d duration should be 1.0" % [anim_name, i])

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		fail("Main node not found")

	var dino = main.get_node_or_null("DinoSheet")
	if dino == null or not (dino is CharacterBody2D):
		fail("DinoSheet CharacterBody2D missing")

	var collision: CollisionShape2D = dino.get_node_or_null("CollisionShape2D")
	if collision == null:
		fail("CollisionShape2D missing")
	var shape = collision.shape
	if shape == null or not (shape is RectangleShape2D):
		fail("Collision shape must be RectangleShape2D")
	if not approx_equal(shape.size, Vector2(15, 17.25)):
		fail("Collision shape size incorrect")

	var anim: AnimatedSprite2D = dino.get_node_or_null("AnimatedSprite2D")
	if anim == null:
		fail("AnimatedSprite2D missing")
	if anim.sprite_frames == null:
		fail("SpriteFrames missing on AnimatedSprite2D")
	if anim.autoplay != "run":
		fail("AnimatedSprite2D autoplay should be run")

	var frames: SpriteFrames = anim.sprite_frames
	check_atlas_frames(frames, "default", [
		Rect2(0, 0, 24, 24),
		Rect2(24, 0, 24, 24),
		Rect2(48, 0, 24, 24),
		Rect2(72, 0, 24, 24)
	], 5.0)

	check_atlas_frames(frames, "run", [
		Rect2(96, 0, 24, 24),
		Rect2(120, 0, 24, 24),
		Rect2(144, 0, 24, 24),
		Rect2(168, 0, 24, 24),
		Rect2(192, 0, 24, 24),
		Rect2(216, 0, 24, 24)
	], 5.0)

	var player_script = dino.get_script()
	if player_script == null:
		fail("Movement script missing")
	if not dino.has_method("_physics_process"):
		fail("Movement script must implement _physics_process")
	if abs(dino.SPEED - 100.0) > 0.01:
		fail("SPEED constant should be 100")
	if abs(dino.JUMP_VELOCITY + 300.0) > 0.01:
		fail("JUMP_VELOCITY should be -300")
	var code := ""
	if player_script is GDScript:
		code = player_script.source_code
	if code.find("play(\"run\"") == -1 or code.find("play(\"default\"") == -1:
		fail("Script should play run/default animations based on input")
	if code.find("flip_h") == -1:
		fail("Script should flip sprite horizontally")

	print("VALIDATION_PASSED: Sprite sheet animation configured")
	get_tree().quit(0)
