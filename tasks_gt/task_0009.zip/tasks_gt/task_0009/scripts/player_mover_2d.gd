extends Node2D
class_name PlayerMover2D

var player: Node2D = null

func _on_player_detector_area_entered(area: Area2D) -> void:
	player = area

func _on_player_detector_area_exited(_area: Area2D) -> void:
	player = null

func move_player(movement_amount: Vector2) -> void:
	if player:
		player.position += movement_amount

func clearCollisionShapes() -> void:
	for child in $PlayerDetector.get_children():
		child.queue_free()

func addCollisionShape(shape: CollisionShape2D) -> void:
	$PlayerDetector.add_child(shape)
