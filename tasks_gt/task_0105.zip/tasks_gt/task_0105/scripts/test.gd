extends Node

const AUDIO_SCRIPT_PATH := "res://scenes/audio_player/audio_player.gd"

var _failed := false


func _ready() -> void:
	run_validation()


func run_validation() -> void:
	_validate_bus_layout()
	if _failed:
		return
	_validate_autoloads()
	if _failed:
		return
	_validate_audio_script()
	if _failed:
		return
	_validate_player_scene("res://scenes/audio_player/music_player.tscn", "MusicPlayer", "Music", 4)
	if _failed:
		return
	_validate_player_scene("res://scenes/audio_player/sfx_player.tscn", "SFXPlayer", "SFX", 16)
	if _failed:
		return
	print("VALIDATION_PASSED: Audio players configured.")
	get_tree().quit(0)


func _validate_bus_layout() -> void:
	var bus_layout_path := "res://default_bus_layout.tres"
	if not FileAccess.file_exists(bus_layout_path):
		_fail("default_bus_layout.tres not found")
		return

	var bus_text := FileAccess.get_file_as_string(bus_layout_path)
	if bus_text.find('bus/1/name = &"Music"') == -1:
		_fail("Music bus missing in default_bus_layout.tres")
		return
	if bus_text.find('bus/2/name = &"SFX"') == -1:
		_fail("SFX bus missing in default_bus_layout.tres")
		return


func _validate_autoloads() -> void:
	var project_text := FileAccess.get_file_as_string("res://project.godot")
	if project_text.find('MusicPlayer="*res://scenes/audio_player/music_player.tscn"') == -1:
		_fail("MusicPlayer autoload not configured")
		return
	if project_text.find('SFXPlayer="*res://scenes/audio_player/sfx_player.tscn"') == -1:
		_fail("SFXPlayer autoload not configured")
		return


func _validate_audio_script() -> void:
	if not FileAccess.file_exists(AUDIO_SCRIPT_PATH):
		_fail("audio_player.gd not found")
		return
	var script_text := FileAccess.get_file_as_string(AUDIO_SCRIPT_PATH)
	if script_text.find("func play") == -1:
		_fail("audio_player.gd missing play()")
		return
	if script_text.find("func stop") == -1:
		_fail("audio_player.gd missing stop()")
		return


func _validate_player_scene(scene_path: String, root_name: String, bus_name: String, expected_count: int) -> void:
	var packed: Resource = load(scene_path)
	if packed == null or not packed is PackedScene:
		_fail("Missing or invalid scene: %s" % scene_path)
		return
	var packed_scene: PackedScene = packed
	var root: Node = packed_scene.instantiate()
	if root.name != root_name:
		_fail("%s root node must be named %s" % [scene_path, root_name])
		return
	if root.get_script() == null or root.get_script().resource_path != AUDIO_SCRIPT_PATH:
		_fail("%s root node must use audio_player.gd" % scene_path)
		return

	var players: Array[AudioStreamPlayer] = []
	for child in root.get_children():
		if child is AudioStreamPlayer:
			players.append(child)

	if players.size() != expected_count:
		_fail("%s must have %d AudioStreamPlayer children" % [scene_path, expected_count])
		return

	for player in players:
		if player.bus != bus_name:
			_fail("%s AudioStreamPlayer bus must be %s" % [scene_path, bus_name])
			return


func _fail(message: String) -> void:
	_failed = true
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
