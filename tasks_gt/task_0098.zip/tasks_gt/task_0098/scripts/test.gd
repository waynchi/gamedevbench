extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		print("VALIDATION_FAILED: Main node not found")
		get_tree().quit(1)
		return

	var player = main.get_node_or_null("Player")
	if player == null:
		print("VALIDATION_FAILED: Player node not found")
		get_tree().quit(1)
		return

	var sprite_lower = player.get_node_or_null("Anchor/SpriteLower")
	if sprite_lower == null:
		print("VALIDATION_FAILED: SpriteLower node not found")
		get_tree().quit(1)
		return

	var anim_player = player.get_node_or_null("AnimationPlayerLower")
	if anim_player == null:
		print("VALIDATION_FAILED: AnimationPlayerLower node not found")
		get_tree().quit(1)
		return

	if not anim_player.has_animation("run"):
		print("VALIDATION_FAILED: run animation missing")
		get_tree().quit(1)
		return
	if not anim_player.has_animation("stand"):
		print("VALIDATION_FAILED: stand animation missing")
		get_tree().quit(1)
		return

	var run_anim: Animation = anim_player.get_animation("run")
	if abs(run_anim.length - 0.6) > 0.001:
		print("VALIDATION_FAILED: run animation length must be 0.6")
		get_tree().quit(1)
		return
	if abs(run_anim.step - 0.1) > 0.001:
		print("VALIDATION_FAILED: run animation step must be 0.1")
		get_tree().quit(1)
		return
	if run_anim.loop_mode == Animation.LOOP_NONE:
		print("VALIDATION_FAILED: run animation must loop")
		get_tree().quit(1)
		return
	if run_anim.get_track_count() != 1:
		print("VALIDATION_FAILED: run animation must have one track")
		get_tree().quit(1)
		return
	if run_anim.track_get_path(0) != NodePath("Anchor/SpriteLower:frame"):
		print("VALIDATION_FAILED: run animation track must target SpriteLower:frame")
		get_tree().quit(1)
		return
	if run_anim.track_get_key_count(0) != 6:
		print("VALIDATION_FAILED: run animation must have 6 keys")
		get_tree().quit(1)
		return
	for i in range(6):
		var expected_time = 0.1 * i
		var time_value = run_anim.track_get_key_time(0, i)
		if abs(time_value - expected_time) > 0.001:
			print("VALIDATION_FAILED: run key time mismatch at index %d" % i)
			get_tree().quit(1)
			return
		var frame_value = int(run_anim.track_get_key_value(0, i))
		if frame_value != i:
			print("VALIDATION_FAILED: run frame mismatch at index %d" % i)
			get_tree().quit(1)
			return

	var stand_anim: Animation = anim_player.get_animation("stand")
	if abs(stand_anim.length - 0.1) > 0.001:
		print("VALIDATION_FAILED: stand animation length must be 0.1")
		get_tree().quit(1)
		return
	if abs(stand_anim.step - 0.1) > 0.001:
		print("VALIDATION_FAILED: stand animation step must be 0.1")
		get_tree().quit(1)
		return
	if stand_anim.get_track_count() != 1:
		print("VALIDATION_FAILED: stand animation must have one track")
		get_tree().quit(1)
		return
	if stand_anim.track_get_path(0) != NodePath("Anchor/SpriteLower:frame"):
		print("VALIDATION_FAILED: stand animation track must target SpriteLower:frame")
		get_tree().quit(1)
		return
	if stand_anim.track_get_key_count(0) != 1:
		print("VALIDATION_FAILED: stand animation must have one key")
		get_tree().quit(1)
		return
	var stand_frame = int(stand_anim.track_get_key_value(0, 0))
	if stand_frame != 6:
		print("VALIDATION_FAILED: stand frame must be 6")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)
