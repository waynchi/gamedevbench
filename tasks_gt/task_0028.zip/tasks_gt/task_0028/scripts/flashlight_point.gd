extends Marker3D
class_name FlashlightPoint

## Represents a world point the flashlight can target.
enum Priority { LOW, MEDIUM, HIGH }

@export var priority: Priority = Priority.LOW
var has_been_targeted: bool = false

func mark_targeted() -> void:
    has_been_targeted = true

func reset_target_state() -> void:
    has_been_targeted = false
