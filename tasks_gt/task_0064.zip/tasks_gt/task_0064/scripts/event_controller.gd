extends Node

signal exit_switch_flipped

func emit_exit_switch_flipped() -> void:
	exit_switch_flipped.emit()
