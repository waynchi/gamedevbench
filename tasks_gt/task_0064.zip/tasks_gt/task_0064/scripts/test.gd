extends Node

const SWITCH_SCENE := preload("res://scenes/door_switch.tscn")
const DOOR_SCENE := preload("res://scenes/level_door.tscn")
const PLAYER_SCENE := preload("res://scenes/player.tscn")
var event_controller: Node = null
var _switch_signal_count := 0

func _ready() -> void:
	await run_validation()

func run_validation() -> void:
	var main := get_node_or_null("Main")
	if main == null:
		fail("Test scene must instance the main level")
		return
	var camera: Camera2D = main.get_node_or_null("Camera2D")
	if camera == null:
		fail("Camera rig from the previous task must remain in the level")
		return
	await get_tree().process_frame     # wait initialization finish
	if not await _validate_event_controller():
		return
	if not await _validate_switch():
		return
	if not await _validate_door():
		return
	print("VALIDATION_PASSED: Door switch and camera transition implemented")
	get_tree().quit(0)

func _validate_event_controller() -> bool:
	if not has_node("/root/EventController"):
		fail("EventController must be registered as an autoload")
		return false
	event_controller = get_node("/root/EventController")
	if not event_controller.has_signal("exit_switch_flipped"):
		fail("EventController must declare an exit_switch_flipped signal")
		return false
	return true

func _validate_switch() -> bool:
	var door_switch := SWITCH_SCENE.instantiate()
	add_child(door_switch)
	var sprite := door_switch.get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	if sprite == null:
		fail("Door switch scene needs an AnimatedSprite2D child")
		return false
	var frames := sprite.sprite_frames
	if frames == null or not frames.has_animation("button_pressed"):
		fail("Door switch animation button_pressed is missing")
		return false
	if frames.get_frame_count("button_pressed") != 3:
		fail("Door switch animation must contain three frames")
		return false
	if frames.get_animation_speed("button_pressed") != 9.0:
		fail("Door switch animation speed should be 9 FPS")
		return false
	if frames.get_animation_loop("button_pressed"):
		fail("Door switch animation must not loop")
		return false
	var area_shape := door_switch.get_node_or_null("CollisionShape2D") as CollisionShape2D
	var floor_shape := door_switch.get_node_or_null("StaticBody2D/CollisionShape2D") as CollisionShape2D
	if area_shape == null or not (area_shape.shape is CapsuleShape2D):
		fail("Door switch needs an Area2D collision CapsuleShape2D")
		return false
	if floor_shape == null or not (floor_shape.shape is CapsuleShape2D):
		fail("StaticBody2D must have a CapsuleShape2D so the player can stand on it")
		return false
	if not door_switch.has_method("_on_body_entered"):
		fail("Door switch script must handle body_entered")
		return false
	_switch_signal_count = 0
	event_controller.connect("exit_switch_flipped", Callable(self, "_on_exit_switch_test"))
	var player := PLAYER_SCENE.instantiate()
	door_switch.call("_on_body_entered", player)
	if door_switch.switch_pressed != true:
		fail("Door switch must set switch_pressed after a Player enters")
		event_controller.disconnect("exit_switch_flipped", Callable(self, "_on_exit_switch_test"))
		return false
	if _switch_signal_count != 0:
		fail("Door switch should wait for the animation before emitting the signal")
		event_controller.disconnect("exit_switch_flipped", Callable(self, "_on_exit_switch_test"))
		return false
	await sprite.animation_finished
	await get_tree().process_frame
	if _switch_signal_count != 1:
		fail("Door switch must emit exit_switch_flipped exactly once after the animation finishes")
		event_controller.disconnect("exit_switch_flipped", Callable(self, "_on_exit_switch_test"))
		return false
	event_controller.disconnect("exit_switch_flipped", Callable(self, "_on_exit_switch_test"))
	door_switch.queue_free()
	return true

func _validate_door() -> bool:
	var door := DOOR_SCENE.instantiate()
	add_child(door)
	var sprite := door.get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	if sprite == null:
		fail("Level door scene needs an AnimatedSprite2D")
		return false
	var frames := sprite.sprite_frames
	if frames == null or not frames.has_animation("open_door"):
		fail("Level door must include an open_door animation")
		return false
	if frames.get_frame_count("open_door") != 7:
		fail("open_door animation must use seven frames")
		return false
	if frames.get_animation_loop("open_door"):
		fail("open_door animation cannot loop")
		return false
	var door_camera := door.get_node_or_null("DoorCamera")
	if door_camera == null or not (door_camera is PhantomCamera2D):
		fail("Level door needs a PhantomCamera2D child named DoorCamera")
		return false
	if door_camera.priority != 1:
		fail("Door camera default priority must be 1")
		return false
	if door_camera.zoom != Vector2(4, 4):
		fail("Door camera zoom must be 4x")
		return false
	if door_camera.follow_mode != door_camera.FollowMode.GLUED:
		fail("Door camera follow mode must be Glued")
		return false
	if door_camera.follow_target != sprite:
		fail("Door camera follow_target must point to the AnimatedSprite2D")
		return false
	event_controller.exit_switch_flipped.emit()
	await get_tree().process_frame
	if door_camera.priority != 12:
		fail("Door camera priority must jump to 12 when the signal fires")
		return false
	await get_tree().create_timer(2.1).timeout
	if sprite.animation != "open_door" or not sprite.is_playing():
		fail("Door must play the open_door animation after the 2 second delay")
		return false
	await sprite.animation_finished
	if door.door_open != true:
		fail("Door should set door_open to true once the animation completes")
		return false
	if door_camera.priority != 1:
		fail("Door camera must restore its priority back to 1 after the reveal")
		return false
	door.queue_free()
	return true

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func _on_exit_switch_test() -> void:
	_switch_signal_count += 1
