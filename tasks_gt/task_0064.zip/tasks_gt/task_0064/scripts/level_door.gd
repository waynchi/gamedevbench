extends Area2D

class_name LevelDoor

@onready var door_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var door_camera: PhantomCamera2D = $DoorCamera

var door_open := false

func _ready() -> void:
	EventController.exit_switch_flipped.connect(_on_exit_switch_flipped)

func _on_exit_switch_flipped() -> void:
	if door_open:
		return
	door_camera.priority = 12
	await get_tree().create_timer(2.0).timeout
	door_sprite.play("open_door")
	await door_sprite.animation_finished
	door_open = true
	door_camera.priority = 1
