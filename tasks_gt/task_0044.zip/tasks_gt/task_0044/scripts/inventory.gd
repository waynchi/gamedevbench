extends PanelContainer

const ICON_PATH := "res://assets/sprites/item_icon.tres"

@onready var grid_container: GridContainer = $MarginContainer/GridContainer
@onready var _icon_texture: Texture2D = load(ICON_PATH)
@export var item_array: Array[Item] = []

func add_item_resource() -> void:
	for child in grid_container.get_children():
		if child is Slot and child.slotItemResource == null:
			var item := Item.new()
			item.texture = _icon_texture
			item.quantity = randi_range(1, 20)
			item_array.append(item)
			child.set_item(item)
			return
	print("VALIDATION_FAILED: No empty slot available to add an item")

func clear_all_inventory_items() -> void:
	item_array.clear()
	for child in grid_container.get_children():
		if child is Slot:
			child.set_data_empty()
