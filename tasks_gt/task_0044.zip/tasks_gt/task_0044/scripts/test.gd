extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		return fail("Main scene not found")
	var inventory: PanelContainer = main.get_node_or_null("Inventory")
	if inventory == null:
		return fail("Inventory panel missing from Main")
	if not inventory.has_method("add_item_resource"):
		return fail("Inventory script missing add_item_resource")
	if not inventory.has_method("clear_all_inventory_items"):
		return fail("Inventory script missing clear_all_inventory_items")
	var add_button: Button = main.get_node_or_null("HBoxContainer/AddItemButton")
	var clear_button: Button = main.get_node_or_null("HBoxContainer/ClearItemsButton")
	if add_button == null or clear_button == null:
		return fail("Add/Clear buttons must exist under HBoxContainer")
	var add_callable := Callable(inventory, "add_item_resource")
	var clear_callable := Callable(inventory, "clear_all_inventory_items")
	if not add_button.is_connected("pressed", add_callable):
		return fail("Add button must call add_item_resource")
	if not clear_button.is_connected("pressed", clear_callable):
		return fail("Clear button must call clear_all_inventory_items")
	var grid: GridContainer = inventory.get_node_or_null("MarginContainer/GridContainer")
	if grid == null:
		return fail("Inventory must expose MarginContainer/GridContainer")
	var slots := []
	for child in grid.get_children():
		if child is Slot:
			slots.append(child)
	if slots.size() < 3:
		return fail("Inventory grid must include multiple Slot instances")
	inventory.clear_all_inventory_items()
	if inventory.item_array.size() != 0:
		return fail("clear_all_inventory_items should empty exported array")
	inventory.add_item_resource()
	if inventory.item_array.size() != 1:
		return fail("add_item_resource must append to item_array")
	var first_slot: Slot = slots[0]
	if first_slot.slotItemResource == null:
		return fail("First empty slot should receive an Item")
	var first_item := first_slot.slotItemResource
	if first_item.texture == null:
		return fail("Items must assign the icon texture when added")
	if first_item.quantity < 1 or first_item.quantity > 20:
		return fail("Item quantities must be randomized between 1 and 20")
	var first_label: Label = first_slot.get_node("TextureHolder/TextureRect/Label")
	if first_label.text != str(first_item.quantity):
		return fail("slot.set_item must display the Item quantity")
	inventory.add_item_resource()
	if inventory.item_array.size() != 2:
		return fail("Second add should append another Item")
	var second_slot: Slot = slots[1]
	if second_slot.slotItemResource == null:
		return fail("Second slot must be populated after two adds")
	if second_slot.slotItemResource == first_item:
		return fail("Each add must create a new Item resource")
	inventory.clear_all_inventory_items()
	if inventory.item_array.size() != 0:
		return fail("clear_all_inventory_items must reset the exported array")
	for slot in [first_slot, second_slot]:
		if slot.slotItemResource != null:
			return fail("clear_all_inventory_items must empty every Slot")
		var label: Label = slot.get_node("TextureHolder/TextureRect/Label")
		if label.text != "":
			return fail("Slot labels must be cleared when inventory is cleared")
	print("VALIDATION_PASSED: Inventory buttons add and clear slot data")
	get_tree().quit(0)

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
