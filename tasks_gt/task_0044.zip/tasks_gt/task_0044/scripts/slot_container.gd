extends PanelContainer
class_name Slot

@export var slotItemResource: Item = null

@onready var _texture_rect: TextureRect = %TextureRect
@onready var _quantity_label: Label = %Label

func set_item(item_resource: Item) -> void:
	if item_resource == null:
		set_data_empty()
		return
	slotItemResource = item_resource
	_texture_rect.texture = slotItemResource.texture
	_quantity_label.text = str(slotItemResource.quantity)

func _get_drag_data(_at_position):
	if slotItemResource == null:
		return null
	var preview_texture := TextureRect.new()
	preview_texture.texture = _texture_rect.texture
	preview_texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview_texture.size = Vector2(49, 49)
	var preview := Control.new()
	preview.add_child(preview_texture)
	set_drag_preview(preview)
	return self

func _can_drop_data(_at_position, data):
	return data is Slot

func _drop_data(_at_position, data):
	if not (data is Slot):
		return
	if slotItemResource == null:
		set_item(data.slotItemResource)
		data.set_data_empty()
		return
	if data.slotItemResource == null:
		return
	var temp := slotItemResource
	set_item(data.slotItemResource)
	data.set_item(temp)

func set_data_empty() -> void:
	_texture_rect.texture = null
	slotItemResource = null
	_quantity_label.text = ""
