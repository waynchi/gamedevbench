extends Area2D

var tile_size: int = 64
var animation_speed: float = 2.0
var moving: bool = false
var inputs := {
	"right": Vector2.RIGHT,
	"left": Vector2.LEFT,
	"up": Vector2.UP,
	"down": Vector2.DOWN,
}

@onready var ray: RayCast2D = $RayCast2d

func _ready() -> void:
	position = position.snapped(Vector2.ONE * tile_size)
	position += Vector2.ONE * tile_size / 2

func _unhandled_input(event: InputEvent) -> void:
	if moving:
		return
	for dir in inputs.keys():
		if event.is_action_pressed(dir):
			move(dir)

func move(dir: String) -> void:
	if not inputs.has(dir):
		return
	ray.target_position = inputs[dir] * tile_size
	ray.force_raycast_update()
	if ray.is_colliding():
		return

	var target: Vector2 = position + inputs[dir] * tile_size
	var tween := get_tree().create_tween()
	tween.tween_property(self, "position", target, 1.0 / animation_speed).set_trans(Tween.TRANS_SINE)
	moving = true
	if has_node("AnimationPlayer"):
		$AnimationPlayer.play(dir)
	await tween.finished
	moving = false
