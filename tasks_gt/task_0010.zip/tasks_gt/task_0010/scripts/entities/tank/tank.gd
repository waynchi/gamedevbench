extends CharacterBody2D
class_name Tank

signal collected(collectable)
signal reloaded()
signal reload_progress(progress)

const SPEED = 64.0
const TURN_SPEED = 2

@onready var body_sprite := $BodySprite
@onready var animation_player = $AnimationPlayer
@onready var collider = $CollisionShape2D
@onready var audio_player: AudioStreamPlayer = $AudioStreamPlayer

var direction := Vector2.RIGHT
var speed_modifier := 1.0
var has_control := true

func _ready():
	pass

func collect(pickup):
	collected.emit(pickup)


func _physics_process(delta):
	if !has_control:
		return

	var drive_input := Input.get_axis("move_backward", "move_forward")
	var turn_input := Input.get_axis("turn_left", "turn_right")
	if turn_input != 0:
		# Rotate direction based on our input vector and apply turn speed
		direction = direction.rotated(turn_input * (PI / 2) * TURN_SPEED * delta)
		rotation = direction.angle()
	if drive_input != 0:
		# Move in a forward/backward motion and play animation
		animation_player.play("move")
		# Simplified: removed World.get_custom_data_at calls for water/speed detection
		var move_speed = SPEED * speed_modifier
		velocity = lerp(velocity, (direction.normalized() * drive_input) * move_speed, SPEED * delta)
		if !audio_player.playing:
			audio_player.play()
	else:
		if audio_player.playing:
			audio_player.stop()
		# Bring to a stop
		velocity = Vector2.ZERO
		animation_player.play('idle')

	# Simplified: removed particle emission logic

	# Apply our movement velocity
	move_and_slide()

	# Simplified: removed weapon rotation logic
