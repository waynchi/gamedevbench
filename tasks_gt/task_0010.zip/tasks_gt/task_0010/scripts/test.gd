extends Node

func _ready():
    run_validation()

func _fail(msg):
    print("VALIDATION_FAILED: %s" % msg)
    get_tree().quit(1)

func _succeed(msg):
    print("VALIDATION_PASSED: %s" % msg)
    get_tree().quit(0)

func _ensure(condition, msg):
    if not condition:
        _fail(msg)
        return true
    return false

func run_validation():
    var pickup_scene: PackedScene = load("res://scenes/entities/world/pickup.tscn")
    if _ensure(pickup_scene != null, "Pickup scene must exist at res://scenes/entities/world/pickup.tscn"):
        return

    var pickup: Node = pickup_scene.instantiate()
    if _ensure(pickup is Area2D, "Pickup root must be an Area2D"):
        return
    if _ensure(pickup.name == "Pickup", "Pickup node must be named 'Pickup'"):
        return

    var sprite: Sprite2D = pickup.get_node_or_null("Sprite2D")
    if _ensure(sprite != null, "Pickup must include a Sprite2D child"):
        return
    if _ensure(sprite.texture != null, "Pickup Sprite2D needs a texture"):
        return
    if _ensure(sprite.texture.resource_path.ends_with("assets/sprites/pickups.png"), "Pickup texture must be assets/sprites/pickups.png"):
        return

    var collider: CollisionShape2D = pickup.get_node_or_null("CollisionShape2D")
    if _ensure(collider != null, "Pickup must include a CollisionShape2D"):
        return
    if _ensure(collider.shape is RectangleShape2D, "Pickup collider must be rectangular"):
        return
    if _ensure((collider.shape as RectangleShape2D).size == Vector2(8, 8), "Pickup collider must be 8x8"):
        return

    var audio_player: AudioStreamPlayer = pickup.get_node_or_null("AudioStreamPlayer")
    if _ensure(audio_player != null, "Pickup must include an AudioStreamPlayer"):
        return
    if _ensure(audio_player.stream != null, "Pickup audio player needs a stream"):
        return
    if _ensure(audio_player.stream.resource_path.ends_with("assets/audio/sfx/pickup.wav"), "Pickup audio must use assets/audio/sfx/pickup.wav"):
        return
    if _ensure(audio_player.bus == &"SFX", "Pickup audio bus must be SFX"):
        return

    var callable_ref := Callable(pickup, "_on_body_entered")
    if _ensure(pickup.is_connected("body_entered", callable_ref), "Pickup must connect body_entered to _on_body_entered"):
        return

    var pickup_script: GDScript = load("res://scripts/entities/world/pickup.gd")
    if _ensure(pickup_script != null, "Pickup script missing"):
        return
    var source := pickup_script.source_code
    if _ensure(source.find("if body is Tank") != -1, "Pickup must guard for Tank bodies"):
        return
    if _ensure(source.find("body.collect") != -1, "Pickup must call Tank.collect(self)"):
        return
    if _ensure(source.find("audio_player.play") != -1, "Pickup must play its AudioStreamPlayer"):
        return
    if _ensure(source.find("await audio_player.finished") != -1, "Pickup must await audio completion"):
        return
    if _ensure(source.find("queue_free") != -1, "Pickup must queue_free after playing"):
        return

    var main_scene: PackedScene = load("res://scenes/main.tscn")
    if _ensure(main_scene != null, "Main scene must exist"):
        return
    var main: Node = main_scene.instantiate()
    var pickup_in_main: Node = main.get_node_or_null("Pickup")
    if _ensure(pickup_in_main != null, "Pickup must be instanced in main scene as 'Pickup'"):
        return
    if _ensure(pickup_in_main.position == Vector2(64, 0), "Pickup position must be (64, 0)"):
        return
    if _ensure(pickup_in_main.scale == Vector2(4, 4), "Pickup scale must be (4, 4)"):
        return

    _succeed("Pickup collectible scene and script completed")
