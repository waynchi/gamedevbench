extends Node

const WATER_SHADER_PATH := "res://scenes/WaterShader.tres"
const EXPECTED_CAMERA_POS := Vector3(-4.269, 0.54, -3.258)
const EXPECTED_CAMERA_FOV := 70.9

func _ready():
	run_validation()

func fail(msg: String) -> void:
	print("VALIDATION_FAILED: %s" % msg)
	get_tree().quit(1)

func pass_validation(msg: String) -> void:
	print("VALIDATION_PASSED: %s" % msg)
	get_tree().quit(0)

func approx_vec3(a: Vector3, b: Vector3, tolerance: float = 0.1) -> bool:
	return a.distance_to(b) <= tolerance

func is_greenish(color: Color) -> bool:
	# Green channel should be dominant (higher than red and blue)
	# and reasonably saturated
	return color.g > 0.5 and color.g > color.r and color.g > color.b

func run_validation() -> void:
	var main := get_node_or_null("Main")
	if main == null:
		fail("Main node missing")
		return

	var world_env := main.get_node_or_null("WorldEnvironment")
	if world_env == null or world_env.environment == null or world_env.environment.sky == null:
		fail("WorldEnvironment with procedural sky missing")
		return

	var dir_light := main.get_node_or_null("DirectionalLight3D")
	if dir_light == null or not dir_light.shadow_enabled:
		fail("DirectionalLight3D with shadows must exist")
		return

	var water := main.get_node_or_null("Water")
	if water == null or not (water is MeshInstance3D):
		fail("Water MeshInstance3D not found")
		return

	if water.mesh == null or not (water.mesh is PlaneMesh):
		fail("Water must use a PlaneMesh")
		return

	var plane_mesh: PlaneMesh = water.mesh
	if plane_mesh.size != Vector2(10, 10):
		fail("PlaneMesh must be 10x10 units")
		return

	if plane_mesh.subdivide_width != 20 or plane_mesh.subdivide_depth != 20:
		fail("PlaneMesh subdivisions must be 20x20")
		return

	var override_material = water.material_override
	if override_material == null or not (override_material is ShaderMaterial):
		fail("Water requires a ShaderMaterial override")
		return

	var shader: Shader = override_material.shader
	if shader == null or shader.resource_path != WATER_SHADER_PATH:
		fail("Shader must reference %s" % WATER_SHADER_PATH)
		return

	var background := main.get_node_or_null("Background")
	if background == null:
		fail("Background node missing")
		return

	# Count MeshInstance3D children under Background
	var sphere_count := 0
	for child in background.get_children():
		if child is MeshInstance3D:
			sphere_count += 1
			var sphere := child as MeshInstance3D

			# Check that sphere has a mesh
			if sphere.mesh == null:
				fail("Sphere MeshInstance3D '%s' must have a mesh assigned" % sphere.name)
				return

			# Check that sphere is positioned in a reasonable range (near water surface)
			var pos := sphere.transform.origin
			if pos.y > 2.0 or pos.y < -2.0:
				fail("Sphere '%s' should be positioned near the water surface (y between -2 and 2)" % sphere.name)
				return

			# Check that sphere has a material override
			var mat_override = sphere.material_override
			if mat_override == null or not (mat_override is StandardMaterial3D):
				fail("Sphere '%s' must have a StandardMaterial3D material override" % sphere.name)
				return

			# Check that the material is greenish
			var mat := mat_override as StandardMaterial3D
			if not is_greenish(mat.albedo_color):
				fail("Sphere '%s' material should be green (found: %s)" % [sphere.name, mat.albedo_color])
				return

	if sphere_count != 5:
		fail("Background should contain exactly 5 sphere MeshInstance3Ds (found: %d)" % sphere_count)
		return

	var camera := main.get_node_or_null("Camera3D")
	if camera == null or not (camera is Camera3D):
		fail("Camera3D missing")
		return

	# Check camera position
	if not approx_vec3(camera.transform.origin, EXPECTED_CAMERA_POS, 0.2):
		fail("Camera3D should be positioned at %s (found: %s)" % [EXPECTED_CAMERA_POS, camera.transform.origin])
		return

	# Check camera FOV
	if abs(camera.fov - EXPECTED_CAMERA_FOV) > 0.2:
		fail("Camera FOV must be close to %.1f (found: %.1f)" % [EXPECTED_CAMERA_FOV, camera.fov])
		return

	pass_validation("Depth scene geometry matches tutorial setup")
