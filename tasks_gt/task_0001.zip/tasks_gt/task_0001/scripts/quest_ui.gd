extends CanvasLayer

@export var quest_name := "Shoot Em Up"
@export var quest_resource: Resource

@onready var quest_label: Label = $QuestPanel/VBoxContainer/Quest
@onready var quest_info_label: Label = $QuestPanel/VBoxContainer/Do
@onready var life_label: Label = $QuestPanel/VBoxContainer/HP
@onready var complete_label: Label = $Complete
@onready var game_over_label: Label = $GameOver
@onready var player := %Player

enum State {
	START,
	RUNNING,
	LOSE,
	WIN
}

var state := State.START

func _ready():
	complete_label.hide()
	game_over_label.hide()
	state = State.START
	get_tree().paused = true
	QuestManager.step_updated.connect(update_ui)
	QuestManager.step_complete.connect(update_ui)
	QuestManager.next_step.connect(update_ui)
	QuestManager.quest_completed.connect(quest_complete)
	QuestManager.quest_failed.connect(quest_failed)
	QuestManager.add_quest(quest_name, quest_resource)
	quest_label.text = QuestManager.get_player_quest(quest_name).quest_details
	quest_label.scale.y = 0
	var tween = create_tween().chain()
	tween.tween_property(quest_label, "scale:y", 1.0, 0.4)
	tween.tween_property(quest_label, "scale:y", 0.0, 0.4).set_delay(1.6)
	tween.tween_callback(start)

func start():
	state = State.RUNNING
	get_tree().paused = false
	quest_label.hide()

func quest_complete(quest:Dictionary):
	state = State.WIN
	complete_label.text = "QUEST COMPLETE\nMoney %s" % quest.quest_rewards.money
	complete_label.show()
	get_tree().paused = true

func quest_failed(quest:Dictionary):
	state = State.LOSE
	game_over_label.show()
	get_tree().paused = true

func update_ui(step:Dictionary):
	match step.step_type:
		QuestManager.INCREMENTAL_STEP:
			quest_info_label.text = "%s %02d/%02d" % [step.details, step.collected, step.required]
		QuestManager.TIMER_STEP:
			quest_info_label.text = "%s %02d" % [step.details, step.time]
		_:
			quest_info_label.text = str(step.details)

func _process(delta):
	if player and player.hp <= 0 and state == State.RUNNING:
		QuestManager.fail_quest(quest_name)
	if state == State.RUNNING:
		life_label.text = "LIVES %02d/03" % player.hp

func _on_retry_pressed():
	QuestManager.reset_quest(quest_name)
	get_tree().reload_current_scene()

func _on_exit_pressed():
	get_tree().quit()
