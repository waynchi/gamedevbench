extends CharacterBody2D

@export var speed := 360.0
@export var bounds := Vector2(64.0, 640.0)
var hp: int = 3

func _physics_process(delta):
	var dir = Input.get_axis("ui_left", "ui_right")
	velocity.x = dir * speed
	move_and_slide()
	position.x = clamp(position.x, bounds.x, bounds.y)

func take_damage(amount: int = 1):
	hp = max(hp - amount, 0)
