# Key Checklist
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0001_place_asset
  - Evidence: Both scenes/Main.tscn and scenes/test.tscn exist. Main.tscn instantiates Player.tscn, and test.tscn loads test.gd script and instantiates Main.tscn as a child
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - "finish the Player CharacterBody2D" / Player is a CharacterBody2D (implied from context and test)
  - "switching motion_mode to Floating" / Not explicitly in transcript, but part of standard CharacterBody2D setup for 8-directional movement
  - "adding an AnimatedSprite2D that uses the Isometric Mini-Crusader sprite set" / "For our example, we'll use the Isometric Mini-Crusader... We'll use an AnimatedSprite2D"
  - "with animations idle0 through idle7 and run0 through run7" / "we'll name each animation based on its direction. For example, idle0 pointing to the right and going clockwise to idle7"
  - "default to idle0 at speed 2.0" / Not explicitly in transcript (speed_scale not mentioned)
  - "adding a CollisionShape2D rectangle positioned at (7, 44) with a 66x24 size so the collider hugs the feet" / Not in transcript (collider details not mentioned)
  - Instructions Missing from Transcript: The specific motion_mode setting, speed_scale value, and exact CollisionShape2D dimensions/position are not in the transcript. However, these are reasonable defaults for the setup and would be discovered through implementation.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: No repo folder exists in the tutorial directory. The task is based on the tutorial transcript which describes the setup. The assets (Isometric Mini-Crusader sprites) are provided in tasks/task_0054/assets/isometric_Mini-Crusader/
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction is self-contained and provides all necessary details: motion_mode setting, AnimatedSprite2D setup with specific animation names (idle0-idle7, run0-run7), default animation (idle0), speed (2.0), CollisionShape2D type (rectangle), position (7, 44), and size (66x24). No references to external tutorials or other tasks.
- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: All task requirements involve Inspector/Scene tree operations only: setting motion_mode property, adding AnimatedSprite2D node, configuring SpriteFrames with animations, setting properties (animation, speed_scale), adding CollisionShape2D, and configuring its shape and position. No GDScript editing required.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test: Player.motion_mode == MOTION_MODE_FLOATING / Instruction: "switching motion_mode to Floating"
  - Test: AnimatedSprite2D exists / Instruction: "adding an AnimatedSprite2D"
  - Test: Has animations idle0-idle7 and run0-run7 / Instruction: "with animations idle0 through idle7 and run0 through run7"
  - Test: AnimatedSprite2D.animation == "idle0" / Instruction: "default to idle0"
  - Test: AnimatedSprite2D.speed_scale == 2.0 / Instruction: "at speed 2.0"
  - Test: CollisionShape2D with RectangleShape2D / Instruction: "adding a CollisionShape2D rectangle"
  - Test: RectangleShape2D size == Vector2(66, 24) / Instruction: "with a 66x24 size"
  - Test: CollisionShape2D.position at (7, 44) / Instruction: "positioned at (7, 44)"
  - Test: Frame counts for idle0 and run0 >= 8 / Instruction: Implicitly covered by "uses the Isometric Mini-Crusader sprite set"
  - Missing Coverage: None. All instruction elements are tested, and all test checks correspond to instruction requirements.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1, Assertions: [Player is CharacterBody2D, Player.motion_mode == CharacterBody2D.MOTION_MODE_FLOATING], Instruction coverage: ["finish the Player CharacterBody2D by switching motion_mode to Floating"]
  - Test 2, Assertions: [AnimatedSprite2D child exists, sprite_frames is not null], Instruction coverage: ["adding an AnimatedSprite2D that uses the Isometric Mini-Crusader sprite set"]
  - Test 3, Assertions: [Has animations idle0-7 and run0-7 (16 total named animations)], Instruction coverage: ["with animations idle0 through idle7 and run0 through run7"]
  - Test 4, Assertions: [idle0 frame count >= 8, run0 frame count >= 8], Instruction coverage: [Implicit in "uses the Isometric Mini-Crusader sprite set" - animations need frames]
  - Test 5, Assertions: [AnimatedSprite2D.animation == "idle0"], Instruction coverage: ["default to idle0"]
  - Test 6, Assertions: [AnimatedSprite2D.speed_scale == 2.0 (with is_equal_approx)], Instruction coverage: ["at speed 2.0"]
  - Test 7, Assertions: [CollisionShape2D child exists, shape is RectangleShape2D], Instruction coverage: ["adding a CollisionShape2D rectangle"]
  - Test 8, Assertions: [RectangleShape2D.size == Vector2(66, 24)], Instruction coverage: ["with a 66x24 size"]
  - Test 9, Assertions: [CollisionShape2D.position distance to Vector2(7, 44) < 0.1], Instruction coverage: ["positioned at (7, 44)"]
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - Animation names "idle0" through "idle7" and "run0" through "run7" are exact
    - [x] Exact string values/names are in instruction (not just "format text") - "idle0", "idle7", "run0", "run7", "Floating" all specified
    - [x] Number formats (zero-padding, decimal places) are specified - 2.0, 66, 24, (7, 44) all exact values given
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - All comparisons match exact instruction values
    - [x] Node names, paths, and types match instruction exactly - "AnimatedSprite2D", "CollisionShape2D", "CharacterBody2D" all specified
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - motion_mode (Floating), animation (idle0), speed_scale (2.0), size (66x24), position (7,44)
  - Ambiguous Tests: None. All test assertions have exact corresponding specifications in the instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The instructions specify exact values for all properties (motion_mode, animation names, default animation, speed_scale, collider size and position), making this a single-solution task. The only flexibility is in how the user creates the SpriteFrames (manually adding frames vs using a resource), but the test checks the outcome (animation existence and frame counts), not the method used.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0001_place_asset)
  - Evidence: Folder structure matches: assets/, scenes/, scripts/, project.godot, task_config.json. Scene files (Main.tscn, Player.tscn, test.tscn) follow the capitalization pattern used in task_0701-0715 series, which differs from task_0001's lowercase naming but is internally consistent within this task series.
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: All requirements involve Inspector operations: setting motion_mode property on CharacterBody2D, adding and configuring AnimatedSprite2D node, creating/editing SpriteFrames resource with specific animation names, setting animation and speed_scale properties, adding CollisionShape2D with specific shape, size, and position. No scripting required.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Requires visual understanding of the Isometric Mini-Crusader sprite set to properly organize the 8-directional animations (idle0-7, run0-7). The instruction mentions "so the collider hugs the feet," which requires visual inspection of the sprite to determine the appropriate collider placement.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No image is provided in the task instruction itself. The sprites are provided as asset files in the project.

# Notes

## Validation Summary
Task task_0054 has been validated successfully.

### Key Findings:
1. All instruction elements are clearly specified and testable
2. Tests comprehensively cover all instruction requirements with exact value matching
3. No scripting required - purely Inspector/Node-based operations
4. Task is well-suited for multimodal agents due to sprite organization requirements
5. Instruction provides exact specifications for all tested properties (motion_mode, animation names, speed_scale, collider dimensions and position)
6. The task follows the standard structure and naming conventions for the 700-series tasks

### Minor Notes:
- Some instruction details (motion_mode, speed_scale, collider specs) are not explicitly in the tutorial transcript, but they are reasonable implementation details for the described setup
- The phrase "so the collider hugs the feet" provides helpful context for why the collider position is (7, 44) and size is 66x24

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114_parallax_ground_and_clouds/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
