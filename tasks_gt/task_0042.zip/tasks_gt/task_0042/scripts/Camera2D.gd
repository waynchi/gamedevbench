extends Camera2D

var displacement: float = 0.0
var velocity: float = 0.0
const SPRING: float = 900.0
const DAMP: float = 18.0
const MULTIPLIER: float = 20.0
var right_point: bool = false

func shake(was_right_point: bool) -> void:
	right_point = was_right_point
	velocity = -50.0

func _physics_process(delta: float) -> void:
	var force := -SPRING * displacement - DAMP * velocity
	velocity += force * delta
	displacement += velocity * delta
	if right_point:
		position.x = -displacement * MULTIPLIER
	else:
		position.x = displacement * MULTIPLIER
