extends CharacterBody2D

@export var speed := 100
var av := Vector2.ZERO
var avoid_weight := 0.1
var target_radius := 50
var _selected_state := false
var selected := false:
	get:
		return _selected_state
	set(value):
		set_selected(value)
var _target_state = null
var target = null:
	get:
		return _target_state
	set(value):
		set_target(value)

func _ready() -> void:
	$Sprite2D.material = $Sprite2D.material.duplicate()

func _physics_process(_delta: float) -> void:
	velocity = Vector2.ZERO
	if _target_state:
		velocity = position.direction_to(_target_state)
		if position.distance_to(_target_state) < target_radius:
			_target_state = null
	av = avoid()
	velocity = (velocity + av * avoid_weight).normalized() * speed
	if velocity.length() > 0:
		rotation = velocity.angle()
	move_and_collide(velocity * _delta)

func set_selected(value: bool) -> void:
	_selected_state = value
	if _selected_state:
		$Sprite2D.material.set_shader_parameter("aura_width", 1)
	else:
		$Sprite2D.material.set_shader_parameter("aura_width", 0)

func set_target(value) -> void:
	_target_state = value

func avoid() -> Vector2:
	var result := Vector2.ZERO
	var neighbors = $Detect.get_overlapping_bodies()
	if neighbors:
		for n in neighbors:
			result += n.position.direction_to(position)
		result /= neighbors.size()
	return result.normalized()
