extends CharacterBody2D
class_name Player

var speed := 120.0
var rotation_speed := 2.0

func _physics_process(delta):
	velocity = transform.x * speed * delta
	rotation += rotation_speed * delta * 0.0 # keep idle; logic tests only need a stable type
	move_and_slide()
