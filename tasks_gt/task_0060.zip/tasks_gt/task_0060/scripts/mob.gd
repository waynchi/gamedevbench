extends CharacterBody2D
class_name Mob

signal removed

var minimap_icon := "mob"
var speed := 60.0

func _physics_process(delta):
	velocity = transform.x * speed * delta
	move_and_collide(velocity)
