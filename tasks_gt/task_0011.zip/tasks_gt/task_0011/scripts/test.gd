extends Node

func _ready():
    run_validation()

func fail(msg):
    print("VALIDATION_FAILED: %s" % msg)
    get_tree().quit(1)

func succeed(msg):
    print("VALIDATION_PASSED: %s" % msg)
    get_tree().quit(0)

func ensure(condition, msg):
    if not condition:
        fail(msg)
        return true
    return false

func run_validation():
    var scene: PackedScene = load("res://scenes/entities/tank/weapon/bullet.tscn")
    if ensure(scene != null, "Bullet scene missing at res://scenes/entities/tank/weapon/bullet.tscn"):
        return

    var bullet: Area2D = scene.instantiate()
    add_child(bullet)

    if ensure(bullet is Area2D, "Bullet root must be an Area2D"):
        return
    if ensure(bullet.name == "Bullet", "Bullet root must be named 'Bullet'"):
        return
    if ensure(bullet.collision_layer == 16, "Bullet collision_layer must be 16"):
        return
    if ensure(bullet.collision_mask == 44, "Bullet collision_mask must be 44"):
        return

    var collider: CollisionShape2D = bullet.get_node_or_null("CollisionShape2D")
    if ensure(collider != null and collider.shape is RectangleShape2D, "Add a rectangular CollisionShape2D child"):
        return
    var rect: RectangleShape2D = collider.shape
    if ensure(rect.size == Vector2(3, 3), "CollisionShape2D rectangle must be 3x3"):
        return

    var sprite: Sprite2D = bullet.get_node_or_null("Sprite2D")
    if ensure(sprite != null and sprite.texture != null, "Add a Sprite2D child with a texture"):
        return

    var area_callable := Callable(bullet, "_on_area_entered")
    if ensure(bullet.is_connected("area_entered", area_callable), "Connect area_entered to _on_area_entered"):
        return
    var body_callable := Callable(bullet, "_on_body_entered")
    if ensure(bullet.is_connected("body_entered", body_callable), "Connect body_entered to _on_body_entered"):
        return

    succeed("Bullet scene layers, collider, sprite, and signals configured")
